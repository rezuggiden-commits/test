#include "shield/network_probe.h"
#include "shield/cef_task.h"
#include "include/cef_urlrequest.h"
#include <QApplication>
#include <QTimer>
#include <QUrl>
#include <chrono>
#include <map>
#include <future>
#include <atomic>
namespace shield { namespace {
class Probe;
std::map<unsigned,CefRefPtr<Probe>> active; // CEF UI only
std::atomic<unsigned> nextId{0};
class Probe final:public CefURLRequestClient {
 public:
  explicit Probe(unsigned value,std::function<void(QString)> callback):id(value),callback_(std::move(callback)),start_(std::chrono::steady_clock::now()){}
  unsigned id;
  CefRefPtr<CefURLRequest> request;
  bool finished=false,timedOut=false;
  void finish(QString text){if(finished)return;finished=true;request=nullptr;active.erase(id);auto cb=std::move(callback_);QMetaObject::invokeMethod(qApp,[cb=std::move(cb),text]{cb(text);},Qt::QueuedConnection);}
  void OnRequestComplete(CefRefPtr<CefURLRequest> r) override {
   CefRefPtr<Probe> keep(this);
   auto ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start_).count();
   auto response=r->GetResponse();int status=response?response->GetStatus():0;int error=int(r->GetRequestError());
   finish(QString::fromUtf8("HTTP: %1 · Chromium: %2 · %3 мс\n%4").arg(status).arg(error).arg(ms).arg(timedOut?QString::fromUtf8("Нет ответа за 10 секунд."):status>0?QString::fromUtf8("Сервер ответил. Это не подтверждает загрузку скриптов, вход или воспроизведение видео."):QString::fromUtf8("HTTP-ответ не получен. Проверьте доступность сайта, DNS и прокси. Код Chromium указывает этап сбоя.")));
  }
  void OnUploadProgress(CefRefPtr<CefURLRequest>,int64_t,int64_t) override {}
  void OnDownloadProgress(CefRefPtr<CefURLRequest>,int64_t,int64_t) override {}
  void OnDownloadData(CefRefPtr<CefURLRequest>,const void*,size_t) override {}
  bool GetAuthCredentials(bool,const CefString&,int,const CefString&,const CefString&,CefRefPtr<CefAuthCallback>) override{return false;}
 private:std::function<void(QString)> callback_;std::chrono::steady_clock::time_point start_;
 IMPLEMENT_REFCOUNTING(Probe);
};
}
void cancelNetworkProbes(){
 auto barrier=std::make_shared<std::promise<void>>();auto done=barrier->get_future();
 onCefUi([barrier]{auto pending=std::move(active);active.clear();for(auto& [id,probe]:pending){if(probe->request)probe->request->Cancel();if(!probe->finished)probe->finish(QString::fromUtf8("Проверка отменена при закрытии браузера."));}pending.clear();barrier->set_value();});
 done.wait(); // The task never waits on Qt; releases CEF references before CefShutdown.
}
void probeOrigin(CefRefPtr<CefRequestContext> context,const QString& target,std::function<void(QString)> done){
 QUrl u(target);if(!u.isValid()||(u.scheme()!="https"&&u.scheme()!="http")||u.host().isEmpty()){done(QString::fromUtf8("Введите адрес HTTP или HTTPS."));return;}
 u.setUserInfo(QString{});u.setPath("/");u.setQuery(QString{});u.setFragment(QString{});
 const unsigned id=++nextId;CefRefPtr<Probe> probe=new Probe(id,std::move(done));auto origin=u.toString(QUrl::FullyEncoded).toStdString();
 onCefUi([probe,context,origin]{active[probe->id]=probe;auto req=CefRequest::Create();req->SetURL(origin);req->SetMethod("HEAD");req->SetFlags(UR_FLAG_DISABLE_CACHE|UR_FLAG_NO_DOWNLOAD_DATA|UR_FLAG_STOP_ON_REDIRECT|UR_FLAG_NO_RETRY_ON_5XX);probe->request=CefURLRequest::Create(req,probe,context);if(!probe->request)probe->finish(QString::fromUtf8("Не удалось создать диагностический запрос."));});
 QTimer::singleShot(10000,qApp,[id]{onCefUi([id]{auto it=active.find(id);if(it==active.end())return;auto probe=it->second;if(!probe->finished&&probe->request){probe->timedOut=true;probe->request->Cancel();}});});
}
}
