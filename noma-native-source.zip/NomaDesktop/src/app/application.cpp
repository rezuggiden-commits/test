#include "shield/network_probe.h"
#include <windows.h>
#include <QApplication>
#include <QDir>
#include <QFile>
#include <QLockFile>
#include <QMessageBox>
#include <QStandardPaths>
#include "include/cef_app.h"
#include "include/cef_sandbox_win.h"
#include "include/cef_version.h"
#include "shield/main_window.h"
#include "shield/brand.h"
#include "shield/internal_pages.h"
#include <QIcon>
#include <QFont>
#include <QCryptographicHash>
#include <QLocalServer>
#include <QLocalSocket>
#include <QJsonDocument>
#include <QJsonArray>
#include <QPointer>
#include <QTimer>
#include "include/cef_command_line.h"
#include "shield/core/navigation.h"

// Called only by the CEF-supplied bootstrap executable. It creates sandbox_info
// in the EXE as required by Chromium; this DLL must never fabricate that object.
CEF_BOOTSTRAP_EXPORT int RunWinMain(HINSTANCE instance,LPWSTR,int,void* sandbox_info,cef_version_info_t*) {
  if(!sandbox_info)return 70; // No insecure fallback.
  CefMainArgs args(instance);
  auto cefApp=shield::createApp();
  int subprocess=CefExecuteProcess(args,cefApp,sandbox_info);
  if(subprocess>=0)return subprocess;
  QStringList requestedUrls;auto launch=CefCommandLine::CreateCommandLine();launch->InitFromString(GetCommandLineW());CefCommandLine::ArgumentList launchArgs;launch->GetArguments(launchArgs);
  for(const auto& argument:launchArgs){auto input=QString::fromStdWString(argument.ToWString());if(input.size()>16384)continue;auto target=shield::core::classifyNavigation(input.toUtf8().toStdString());if(target.kind==shield::core::NavigationKind::Web&&requestedUrls.size()<32)requestedUrls<<QString::fromStdString(target.url);}
  int argc=1;char name[]="Noma";char* argv[]={name,nullptr};
  QApplication app(argc,argv);BOOL motion=TRUE;SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION,0,&motion,0);app.setProperty("reduceMotion",!motion);app.setEffectEnabled(Qt::UI_AnimateMenu,motion);app.setEffectEnabled(Qt::UI_FadeMenu,motion);app.setApplicationName(QString::fromUtf8(SHIELD_NAME));
  app.setWindowIcon(QIcon(":/icons/app.svg"));app.setFont(QFont("Segoe UI",10));
  app.setOrganizationName(QString::fromUtf8(SHIELD_ORGANIZATION));app.setApplicationVersion(SHIELD_VERSION);
  // Keep installation read-only. No cookies or history beside the binaries.
  const auto local=qEnvironmentVariable("LOCALAPPDATA");
  if(local.isEmpty())return 71;
  const auto profile=QDir(local).filePath(QString::fromUtf8(SHIELD_PROFILE_FOLDER)+"/User Data");
  if(!QDir().mkpath(profile))return 72;
  QLockFile profileLock(QDir(profile).filePath("noma.lock"));
  profileLock.setStaleLockTime(0);
  const auto serverName="NomaDesktop-"+QString::fromLatin1(QCryptographicHash::hash(profile.toUtf8(),QCryptographicHash::Sha256).toHex().left(24));
  if(!profileLock.tryLock()){
    QLocalSocket socket;socket.connectToServer(serverName);if(socket.waitForConnected(1500)){QJsonArray urls;for(const auto& u:requestedUrls)urls.append(u);socket.write(QJsonDocument(urls).toJson(QJsonDocument::Compact)+"\n");socket.flush();if(socket.waitForBytesWritten(1500)||socket.bytesToWrite()==0)return 0;}
    QMessageBox::warning(nullptr,QString::fromUtf8(SHIELD_NAME),QString::fromUtf8("Профиль уже используется. Не удалось передать ссылку открытому окну."));return 73;
  }
  QLocalServer ipc;ipc.setSocketOptions(QLocalServer::UserAccessOption);QLocalServer::removeServer(serverName);if(!ipc.listen(serverName))return 75;
  const HANDLE instanceMutex=CreateMutexW(nullptr,FALSE,L"NomaDesktopAppMutex");

  CefSettings settings;
  settings.multi_threaded_message_loop=true;
  settings.no_sandbox=false;
  settings.command_line_args_disabled=true;
  settings.persist_session_cookies=false;
  settings.log_severity=LOGSEVERITY_DISABLE; // No browsing URLs or secrets in disk logs.
  CefString(&settings.root_cache_path)=profile.toStdWString();
  CefString(&settings.cache_path)=QDir(profile).filePath("Default").toStdWString();
  // No browser_subprocess_path: sandbox requires the same bootstrap EXE.
  if(!CefInitialize(args,settings,cefApp,sandbox_info))return CefGetExitCode();
  if(!shield::registerInternalPages()){CefShutdown();return 74;}
  QPointer<shield::MainWindow> window=new shield::MainWindow(CefRequestContext::GetGlobalContext(),profile,false,requestedUrls.isEmpty()?QString{}:requestedUrls.takeFirst());
  for(const auto& url:requestedUrls)window->newTab(url);window->show();
  QObject::connect(&ipc,&QLocalServer::newConnection,&app,[&]{while(auto* socket=ipc.nextPendingConnection()){
    auto buffer=std::make_shared<QByteArray>();auto handle=[&,socket,buffer]{*buffer+=socket->readAll();if(buffer->size()>65536){socket->abort();socket->deleteLater();return;}if(!buffer->contains('\n'))return;
      auto doc=QJsonDocument::fromJson(buffer->left(buffer->indexOf('\n')));if(!doc.isArray()){socket->disconnectFromServer();return;}
      if(!window||window->isClosing()){window=new shield::MainWindow(CefRequestContext::GetGlobalContext(),profile);window->show();}
      int opened=0;for(const auto& value:doc.array()){const auto input=value.toString();if(input.size()>16384)continue;auto target=shield::core::classifyNavigation(input.toUtf8().toStdString());if(target.kind==shield::core::NavigationKind::Web&&opened++<32)window->newTab(QString::fromStdString(target.url));}
      window->showNormal();window->raise();window->activateWindow();socket->disconnectFromServer();
    };QObject::connect(socket,&QLocalSocket::readyRead,&app,handle);QObject::connect(socket,&QLocalSocket::disconnected,socket,&QObject::deleteLater);QTimer::singleShot(2500,socket,[socket]{socket->abort();socket->deleteLater();});if(socket->bytesAvailable())handle();
  }});
  const int result=app.exec();
  // A MainWindow accepts close only after every tab received OnBeforeClose.
  // Drain Qt deferred deletes so all CefRefPtrs/contexts die before shutdown.
  QCoreApplication::sendPostedEvents(nullptr,QEvent::DeferredDelete);
  ipc.close();shield::cancelNetworkProbes();CefShutdown();if(instanceMutex)CloseHandle(instanceMutex);
  return result;
}
