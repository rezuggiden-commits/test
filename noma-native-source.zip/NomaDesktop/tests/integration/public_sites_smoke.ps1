[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime/public-sites'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
$results=@()
try{
 foreach($name in @('SHIELD_START_URL','SHIELD_TEST_PROOF','SHIELD_UI_AUTOMATION','SHIELD_DOWNLOAD_TEST_URL','SHIELD_EXPECT_RESTORED_DOWNLOADS')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 foreach($site in @(@{name='google';url='https://www.google.com/search?q=Noma+browser'},@{name='duckduckgo';url='https://duckduckgo.com/?q=Noma+browser'},@{name='wikipedia';url='https://en.wikipedia.org/wiki/Web_browser'},@{name='youtube-home';url='https://www.youtube.com/'},@{name='youtube';url='https://www.youtube.com/results?search_query=Noma+browser'})){
  $dir=Join-Path $runtime $site.name;New-Item -ItemType Directory -Path $dir -Force | Out-Null
  $env:SHIELD_EXTERNAL_TEST=$dir
  $app=Start-Process (Join-Path $Stage 'Noma.exe') -ArgumentList @($site.url) -WorkingDirectory $Stage -PassThru
  try{
   $proof=Join-Path $dir 'external.jsonl';$deadline=(Get-Date).AddSeconds(40)
   while(!(Test-Path $proof)-and(Get-Date)-lt$deadline){$app.Refresh();if($app.HasExited){throw "Browser exited while loading $($site.name)"};Start-Sleep -Milliseconds 200}
   $record=$null;if(Test-Path $proof){$record=(Get-Content $proof | Select-Object -Last 1) | ConvertFrom-Json;Start-Sleep -Milliseconds 500}
   if($record -and !(Test-Path (Join-Path $dir 'native-site.png'))){throw 'Public site DOM observed but screenshot capture failed'}
   $results+=@{site=$site.name;requestedUrl=$site.url;domObserved=($null -ne $record);proof=$record;scope='Public Windows CI network; DOM evidence is not sign-in, playback, regional-access or functional-search certification'}
   if(!$app.CloseMainWindow() -or !$app.WaitForExit(20000) -or $app.ExitCode -ne 0){throw "Browser failed to close cleanly after $($site.name)"}
  }finally{$app.Refresh();if(!$app.HasExited){Stop-Process -Id $app.Id -Force}}
 }
 $results | ConvertTo-Json -Depth 6 | Set-Content "$runtime/summary.json"
}finally{Remove-Item Env:SHIELD_EXTERNAL_TEST -ErrorAction SilentlyContinue}
