import argparse, base64, json, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--proof',required=True);parser.add_argument('--port-file',required=True);args=parser.parse_args()
image=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aO2kAAAAASUVORK5CYII=')
class Handler(BaseHTTPRequestHandler):
 def do_HEAD(self):
  Path(args.proof).with_name('head-proof.json').write_text(json.dumps({'path':self.path,'cookieSent':bool(self.headers.get('Cookie')),'authorizationSent':bool(self.headers.get('Authorization'))}))
  self.send_response(204);self.send_header('Content-Length','0');self.end_headers()
 def do_GET(self):
  parsed=urlparse(self.path)
  if parsed.path=='/document-hang':
   time.sleep(35);return
  if parsed.path=='/stall-resource':
   time.sleep(35);return
  if parsed.path=='/resource-hang':
   body=b'<!doctype html><title>Noma retained document</title><h1>Document received and still visible</h1><p>The image never finishes loading. Noma must preserve this page.</p><img src="/stall-resource">';mime='text/html'
   self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
  if parsed.path=='/slow-download.bin':
   size=2*1024*1024;self.send_response(200);self.send_header('Content-Type','application/octet-stream');self.send_header('Content-Disposition','attachment; filename=slow-download.bin');self.send_header('Content-Length',str(size));self.end_headers()
   try:
    for i in range(size//16384):self.wfile.write(bytes(range(256))*64);self.wfile.flush();time.sleep(.04)
   except (BrokenPipeError,ConnectionResetError):pass
   return
  if parsed.path=='/':
   Path(args.proof).with_name('cookie-proof.json').write_text(json.dumps({'persistent': 'noma_persist_probe=present' in (self.headers.get('Cookie') or '')}))
   body=b'''<!doctype html><title>Noma compatibility fixture</title><button style="position:fixed;left:10px;top:10px;width:180px;height:40px" onclick="window.loginPopup=window.open('/oauth-popup','login','width=560,height=640')">Sign in to test site</button><h1 id="proof">Actual Chromium page</h1><script>
   addEventListener("message",async e=>{if(e.origin===location.origin&&e.source===window.loginPopup&&e.data==='noma-auth-ok')await fetch('/oauth-proof?opener=true&source=true&origin=true&cookie='+document.cookie.includes('noma_auth_probe=present'));});
   setTimeout(async()=>{
    const img=(url)=>new Promise(resolve=>{const image=new Image();image.onload=()=>resolve(true);image.onerror=()=>resolve(false);image.src=url;document.body.append(image);});
    const allowed=await img('/allowed.png');const blocked=!(await img('/blocked-ad.png'));
    await fetch('/proof?allowed='+allowed+'&blocked='+blocked+'&dom='+encodeURIComponent(document.getElementById('proof').textContent));
   },3000);</script>''';mime='text/html'
  elif parsed.path=='/media-request':
   body=b'''<!doctype html><title>Noma media permission fixture</title><h1>Permission lifecycle</h1><script>navigator.mediaDevices.getUserMedia({audio:true}).then(s=>{document.title='UNEXPECTED GRANT';for(const t of s.getTracks())t.stop()}).catch(()=>{document.title='Request denied'});</script>''';mime='text/html'
  elif parsed.path=='/permission-after':
   Path(args.proof).with_name('permission-after.json').write_text(json.dumps({'requested': True}));body=b'<!doctype html><title>Noma after permission navigation</title><h1>Pending permission invalidated</h1>';mime='text/html'
  elif parsed.path=='/recovery':
   body=b'<!doctype html><title>Noma recovery fixture</title><h1>Renderer recovered in the same tab</h1>';mime='text/html'
  elif parsed.path in ('/launch-first','/launch-second'):
   Path(args.proof).with_name(parsed.path[1:]+'.json').write_text(json.dumps({'requested': True}));body=b'<!doctype html><title>Noma URL launch fixture</title><h1>URL opened in Noma</h1>';mime='text/html'
  elif parsed.path=='/proof':
   data={k:v[0] for k,v in parse_qs(parsed.query).items()};data['dnt']=self.headers.get('DNT');data['gpc']=self.headers.get('Sec-GPC');Path(args.proof).write_text(json.dumps(data));body=b'ok';mime='text/plain'
  elif parsed.path=='/oauth-popup':
   body=b'''<!doctype html><meta charset="utf-8"><title>Test sign-in - Noma</title><style>body{font:18px system-ui;background:#161b1a;color:#eef1f0;padding:32px}h1{font-size:26px}</style><h1>Sign-in compatibility test</h1><p>This is a real site popup with its original opener.</p><script>setTimeout(()=>{if(window.opener)window.opener.postMessage('noma-auth-ok',location.origin);setTimeout(()=>window.close(),800);},500);</script>''';mime='text/html'
  elif parsed.path=='/oauth-proof':
   data={k:v[0] for k,v in parse_qs(parsed.query).items()};Path(args.proof).with_name('oauth-proof.json').write_text(json.dumps(data));body=b'ok';mime='text/plain'
  elif parsed.path=='/test-download.txt':body=b'Aster download fixture\n';mime='application/octet-stream'
  elif parsed.path.endswith('.png'):body=image;mime='image/png'
  else:body=b'not found';mime='text/plain'
  self.send_response(200)
  if parsed.path=='/test-download.txt':self.send_header('Content-Disposition','attachment; filename=test-download.txt')
  if parsed.path=='/':self.send_header('Set-Cookie','noma_persist_probe=present; Max-Age=600; Path=/; SameSite=Lax')
  if parsed.path=='/oauth-popup':self.send_header('Set-Cookie','noma_auth_probe=present; Path=/; SameSite=Lax')
  self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,fmt,*args): print(fmt%args,flush=True)
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);Path(args.port_file).write_text(str(server.server_port));server.serve_forever()
