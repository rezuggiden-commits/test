#pragma once
#include <QWidget>
#include <QStringList>
#include <QSet>
#include <QPointer>
#include <atomic>
#include <functional>
#include <memory>
#include "shield/core/load_deadline.h"
#include "include/cef_browser.h"
#include "include/cef_request_context.h"
class QTimer;
namespace shield {
class BrowserClient;
class BrowserPage final : public QWidget {
  Q_OBJECT
 public:
  BrowserPage(CefRefPtr<CefRequestContext> context, QWidget* parent=nullptr,bool adoptedPopup=false);
  ~BrowserPage() override;
  void open(const QString& url);
  void setNativeContent(QWidget* content,const QString& url);
  void setLoadTimeout(int seconds);
  void command(const std::function<void(CefRefPtr<CefBrowser>)>& f);
  void shutdown();
  void cancelDownload(unsigned id);
  void pauseDownload(unsigned id,bool pause);
  bool hasActiveDownloads()const{return !activeDownloads_.empty();}
  void closeWhenDownloadsFinish();
  QString url() const {return url_;}
  bool loading() const{return loading_;}
  bool canGoBack() const{return back_;}
  bool canGoForward() const{return forward_;}
  void showNetworkError(const QString& url,const QString& reason,const QString& kind="network");
  void setDefaultZoom(int percent);
  int zoomPercent() const; void zoomBy(int step); void resetZoom();
  bool isClosing() const {return closing_;}
  bool hasBrowser() const {return bool(browser_);}
  void created(CefRefPtr<CefBrowser> browser);
  void beforeClose();
  void abortPopup();
 signals:
  void findResult(int count,int active);
  void titleChanged(const QString& title);
  void addressChanged(const QString& address);
  void loadingChanged(bool loading, bool back, bool forward);
  void loadFailed(const QString& error);
  void completed(const QString& url,const QString& title);
  void popupRequested(const QString& url);
  void closed();
  void shortcut(int key, int modifiers);
  void downloadChanged(unsigned id,const QString& name,qint64 received,qint64 total,bool complete,bool cancelled,int interruptReason,bool paused);
  void contentFocused();
  void permissionsInvalidated();
  void slowLoading(const QString& url);
 protected:
  void showEvent(QShowEvent*) override;
  void resizeEvent(QResizeEvent*) override;
  void focusInEvent(QFocusEvent*) override;
 private:
  CefRefPtr<CefRequestContext> context_;
  CefRefPtr<CefBrowser> browser_;
  CefRefPtr<CefClient> client_;
  QString url_="https://example.org";
  bool started_=false,closing_=false,loading_=false,back_=false,forward_=false;
  QTimer* loadTimer_;
  QTimer* slowTimer_;
  QPointer<QWidget> nativeContent_;
  int timeoutSeconds_=60;
  bool documentReceived_=false;
  core::LoadDeadline loadDeadline_;
  void armLoadTimers();
  void finishLoadTimers();
  void createBrowser();
  QString attempted_,pendingOpen_;
  double zoom_=0;
  QSet<unsigned> activeDownloads_;bool closeAfterDownloads_=false;
  void fit();
  friend class BrowserClient;
};
}
