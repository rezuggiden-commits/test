#pragma once
#include <QString>
#include <functional>
#include "include/cef_request_context.h"
namespace shield {
// Browser-process request with the same request context/proxy. No stored credentials.
void cancelNetworkProbes();
void probeOrigin(CefRefPtr<CefRequestContext> context,const QString& target,std::function<void(QString)> done);
}
