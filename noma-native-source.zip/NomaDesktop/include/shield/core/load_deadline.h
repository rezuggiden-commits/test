#pragma once
#include <algorithm>
#include <chrono>
namespace shield::core {
// One monotonic budget for a loading episode. Commit/redirect callbacks must
// not extend it. A new top-level navigation explicitly starts a new budget.
class LoadDeadline {
 public:
  using Clock = std::chrono::steady_clock;
  using Time = Clock::time_point;
  using Milliseconds = std::chrono::milliseconds;
  void begin(Time now) { if (!active_) restart(now); }
  void restart(Time now) { started_ = now; active_ = true; }
  void finish() { active_ = false; }
  bool active() const { return active_; }
  Milliseconds remaining(Time now, Milliseconds budget) const {
    if (!active_) return Milliseconds::zero();
    auto elapsed = std::chrono::duration_cast<Milliseconds>(now - started_);
    return std::max(Milliseconds::zero(), budget - std::max(Milliseconds::zero(), elapsed));
  }
 private:
  Time started_{};
  bool active_ = false;
};
}
