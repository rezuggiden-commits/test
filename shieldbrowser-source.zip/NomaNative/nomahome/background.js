// Proxy is changed only after an explicit action in Noma's own settings page.
const own = chrome.runtime.getURL('settings.html');
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || sender.url?.split('?')[0] !== own) return;
  if (message.type !== 'set-proxy') return;
  (async () => {
    const {mode, protocol, host, port, bypass} = message;
    if (!['system', 'direct', 'custom'].includes(mode)) throw Error('Неизвестный режим');
    let value = {mode};
    if (mode === 'custom') {
      if (!['http', 'https', 'socks4', 'socks5'].includes(protocol)) throw Error('Неверный протокол');
      if (typeof host !== 'string' || !host.trim() || /[\s/@?#]/.test(host) || host.length > 253)
        throw Error('Укажите адрес сервера без протокола, пути и пароля');
      const n = Number(port);
      if (!Number.isInteger(n) || n < 1 || n > 65535) throw Error('Порт: от 1 до 65535');
      if (typeof bypass !== 'string' || bypass.length > 2000) throw Error('Слишком длинный список исключений');
      value = {mode:'fixed_servers',rules:{singleProxy:{scheme:protocol,host:host.trim(),port:n},bypassList:bypass.split(/[;,\n]/).map(s=>s.trim()).filter(Boolean)}};
    }
    await chrome.proxy.settings.set({value,scope:'regular'});
    const actual = await chrome.proxy.settings.get({incognito:false});
    if (actual.levelOfControl !== 'controlled_by_this_extension')
      throw Error('Прокси управляется другой настройкой или расширением');
    await chrome.storage.local.set({proxyForm:{mode,protocol,host,port,bypass}});
    return {ok:true, mode:actual.value.mode};
  })().then(reply).catch(e=>reply({ok:false,error:e.message}));
  return true;
});
