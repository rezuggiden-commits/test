document.querySelector('#date').textContent=new Intl.DateTimeFormat('ru',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
document.querySelector('#search').addEventListener('submit',async e=>{e.preventDefault();const text=document.querySelector('#query').value.trim();if(!text)return;try{await chrome.search.query({text,disposition:'CURRENT_TAB'});}catch{document.querySelector('#status').textContent='Не удалось начать поиск. Введите запрос в адресной строке.';}});
document.querySelectorAll('[data-native]').forEach(b=>b.onclick=()=>chrome.tabs.update({url:b.dataset.native}));
document.querySelector('#connection').onclick=()=>chrome.tabs.update({url:chrome.runtime.getURL('settings.html')});
