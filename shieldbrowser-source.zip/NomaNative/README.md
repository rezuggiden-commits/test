# Noma 0.7 native Windows candidate

C++20 host with sandboxed CEF Chrome-style (Chromium 152.0.7977.167), not Electron.
Native tabs, omnibox, incognito, downloads, permissions, history, settings and
extension manager are Chromium features, not hand-drawn HTML replicas.
Noma's own bundled MV3 extension provides its new tab and system/custom proxy UI.
No AI, VPN, Google OAuth client or Google Sync integration is bundled.

Run Noma.exe after extracting the WHOLE folder. Do not launch from inside ZIP.
Requires Windows 10/11 x64. Profile: %LOCALAPPDATA%\Noma\Native.
The Electron profile is left untouched; no cookies/passwords are silently imported.
Export old bookmarks to HTML and import via Chromium's bookmark manager.

Ctrl+Shift+N: private window. Ctrl+H: history. Ctrl+J: downloads.
Menu > Settings: full Chromium settings. New tab > Подключение: Noma proxy UI.
Use Chromium's extension manager for compatible extensions. Compatibility and
Chrome Web Store installation are not guaranteed for every extension.

This is a migration candidate, NOT a signed public stable release.
No signing certificate, automatic updater, Google Sync or DRM/Widevine promise.
Public internet availability depends on your network; ERR_CONNECTION_REFUSED
cannot be fixed by changing UI language or disabling certificate checks.
45s absolute main-navigation budget prevents indefinite initial loading.

Build: CMake 3.21+, VS2022, CEF binary SDK pinned by tools/ci_windows.ps1.
Sandbox remains enabled using CEF's official bootstrap executable + Noma.dll.
Remote debugging has no default port; automated test runs opt in.

## Первый запуск

Распакуйте архив целиком и запустите Noma.exe. Это новая нативная версия:
профиль старой Electron-версии не меняется. Если Chromium спросит, оставить ли
новую вкладку Noma, выберите «Оставить так». Это подтверждение стартовой страницы,
а не просьба войти в Google.

Подключение: кнопка «Подключение» на новой вкладке. Выберите системные настройки,
прямое соединение или собственный HTTP(S)/SOCKS-сервер. SOCKS — без авторизации.
Настройки браузера, расширения, история, очистка данных и локальный профиль
открываются из обычного меню справа сверху. AI и VPN не включены.

Это проверяемый кандидат перехода на C++, не подписанный публичный стабильный
релиз. Автообновлений и синхронизации Chrome/Google нет. Не удаляйте старую версию
и её профиль до проверки важных для вас сайтов и расширений.
