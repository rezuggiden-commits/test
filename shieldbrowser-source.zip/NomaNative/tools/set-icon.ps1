param([string]$Exe,[string]$Icon)
$ErrorActionPreference='Stop'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class NomaResources {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] public static extern IntPtr BeginUpdateResource(string file,bool delete);
 [DllImport("kernel32.dll",SetLastError=true)] public static extern bool UpdateResource(IntPtr h,IntPtr type,IntPtr name,ushort lang,byte[] data,uint size);
 [DllImport("kernel32.dll",SetLastError=true)] public static extern bool EndUpdateResource(IntPtr h,bool discard);
}
'@
$bytes=[IO.File]::ReadAllBytes($Icon)
$count=[BitConverter]::ToUInt16($bytes,4)
$group=New-Object byte[] (6+14*$count)
[Array]::Copy($bytes,0,$group,0,6)
$handle=[NomaResources]::BeginUpdateResource($Exe,$false)
if ($handle -eq [IntPtr]::Zero) { throw 'BeginUpdateResource failed' }
try {
 for ($i=0;$i -lt $count;$i++) {
  $o=6+16*$i; $length=[BitConverter]::ToUInt32($bytes,$o+8); $offset=[BitConverter]::ToUInt32($bytes,$o+12)
  $image=New-Object byte[] $length; [Array]::Copy($bytes,$offset,$image,0,$length)
  if (-not [NomaResources]::UpdateResource($handle,[IntPtr]3,[IntPtr](301+$i),0,$image,$length)) { throw 'Icon image resource update failed' }
  [Array]::Copy($bytes,$o,$group,6+14*$i,12)
  [Array]::Copy([BitConverter]::GetBytes([UInt16](301+$i)),0,$group,6+14*$i+12,2)
 }
 if (-not [NomaResources]::UpdateResource($handle,[IntPtr]14,[IntPtr]101,0,$group,$group.Length)) { throw 'Icon group update failed' }
 if (-not [NomaResources]::EndUpdateResource($handle,$false)) { throw 'Icon resource commit failed' }
 $handle=[IntPtr]::Zero
} finally { if ($handle -ne [IntPtr]::Zero) { [void][NomaResources]::EndUpdateResource($handle,$true) } }
