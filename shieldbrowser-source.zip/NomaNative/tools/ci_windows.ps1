$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$evidence = Join-Path $PWD 'docs/runtime'
New-Item -ItemType Directory -Force $evidence | Out-Null
$archive = Join-Path $env:RUNNER_TEMP 'cef-windows.tar.bz2'
$url = 'https://cef-builds.spotifycdn.com/cef_binary_152.0.14+g8a0b5b9+chromium-152.0.7977.167_windows64.tar.bz2'
Write-Host 'Downloading pinned CEF SDK'
& curl.exe -L --fail --retry 3 $url -o $archive
if ($LASTEXITCODE -ne 0) { throw 'CEF download failed' }
if ((Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '316dd3ac263896e0bed889fbf0da14275e265be73a08aee6c80b8ebccacf8fb6') { throw 'CEF SDK SHA256 mismatch' }
$cefBase = Join-Path $env:RUNNER_TEMP 'cef-sdk'
New-Item -ItemType Directory -Force $cefBase | Out-Null
& tar -xf $archive -C $cefBase
if ($LASTEXITCODE -ne 0) { throw 'CEF extraction failed' }
$cef = (Get-ChildItem $cefBase -Directory | Select-Object -First 1).FullName
& cmake -S . -B build -G 'Visual Studio 17 2022' -A x64 "-DCEF_ROOT=$cef" -DUSE_SANDBOX=ON
if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed' }
& cmake --build build --config Release --target Noma --parallel 4 2>&1 | Tee-Object "$evidence/build.log"
if ($LASTEXITCODE -ne 0) { throw 'C++ build failed' }
& npm install --ignore-scripts --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'Test dependency installation failed' }
$env:NOMA_EXE = Join-Path $PWD 'build/Release/Noma.exe'
& node tests/native.cjs 2>&1 | Tee-Object "$evidence/test-console.log"
if ($LASTEXITCODE -ne 0) { throw 'Native browser tests failed' }
$dist = Join-Path $PWD 'dist'
New-Item -ItemType Directory -Force $dist | Out-Null
$package = Join-Path $dist 'Noma-0.7-Windows-x64'
New-Item -ItemType Directory -Force $package | Out-Null
Copy-Item build/Release/* $package -Recurse -Force
Get-ChildItem $package -File | Where-Object { $_.Extension -in '.lib','.exp','.pdb','.ilk' } | Remove-Item
Copy-Item README.md,CEF-LICENSE.txt $package
$zip = Join-Path $dist 'Noma-0.7-Windows-x64-portable.zip'
& 7z a -tzip -mx=5 $zip "$package\*" | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Package creation failed' }
(Get-FileHash $zip -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + (Split-Path $zip -Leaf) | Set-Content "$dist/SHA256.txt"
Write-Host 'NOMA_NATIVE_CANDIDATE_READY'
