// Noma native host. Browser UI, tabs, permissions and networking belong to Chromium.
#include <windows.h>
#include <filesystem>
#include <fstream>
#include <functional>
#include <list>
#include <map>
#include <string>
#include "include/cef_app.h"
#include "include/cef_browser.h"
#include "include/cef_client.h"
#include "include/cef_command_line.h"
#include "include/cef_parser.h"
#include "include/cef_request_context.h"
#include "include/cef_resource_bundle_handler.h"
#include "include/cef_id_mappers.h"
#include "include/cef_sandbox_win.h"
#include "include/cef_version_info.h"
#include "include/cef_task.h"
#include "include/wrapper/cef_helpers.h"
namespace {
std::filesystem::path AppDirectory() {
  wchar_t buffer[32768]{};
  GetModuleFileNameW(nullptr, buffer, 32768);
  return std::filesystem::path(buffer).parent_path();
}
std::filesystem::path ProfileDirectory(CefRefPtr<CefCommandLine> cmd) {
  if (cmd->HasSwitch("noma-profile"))
    return std::filesystem::absolute(cmd->GetSwitchValue("noma-profile").ToWString());
  wchar_t buffer[32768]{};
  GetEnvironmentVariableW(L"LOCALAPPDATA", buffer, 32768);
  return std::filesystem::path(buffer) / L"Noma" / L"Native";
}
bool IsWeb(const std::string& url) {
  return url.starts_with("https://") || url.starts_with("http://");
}
std::string home_id;
std::filesystem::path profile;
void Record(const std::string& message) {
  // Diagnostic events deliberately omit page URLs, cookies and user content.
  std::ofstream file(profile / L"host-events.log", std::ios::app);
  file << GetTickCount64() << " " << message << "\n";
}
class CallbackTask final : public CefTask {
 public:
  explicit CallbackTask(std::function<void()> callback) : callback_(std::move(callback)) {}
  void Execute() override { callback_(); }
 private:
  std::function<void()> callback_;
  IMPLEMENT_REFCOUNTING(CallbackTask);
};
class BrowserClient final : public CefClient,
                            public CefLifeSpanHandler,
                            public CefRequestHandler,
                            public CefLoadHandler {
 public:
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override { return this; }
  CefRefPtr<CefRequestHandler> GetRequestHandler() override { return this; }
  CefRefPtr<CefLoadHandler> GetLoadHandler() override { return this; }
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    CEF_REQUIRE_UI_THREAD();
    browsers_.push_back(browser);
    Record(browser->GetHost()->GetRuntimeStyle() == CEF_RUNTIME_STYLE_CHROME
               ? "browser-created chrome-style" : "ERROR unexpected-runtime");
  }
  bool DoClose(CefRefPtr<CefBrowser>) override { return false; }
  void OnBeforeClose(CefRefPtr<CefBrowser> browser) override {
    CEF_REQUIRE_UI_THREAD();
    pending_.erase(browser->GetIdentifier());
    browsers_.remove_if([&](const auto& other) { return other->IsSame(browser); });
    if (browsers_.empty()) {
      Record("clean-shutdown");
      CefQuitMessageLoop();
    }
  }
  bool OnBeforeBrowse(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                      CefRefPtr<CefRequest> request, bool, bool redirect) override {
    CEF_REQUIRE_UI_THREAD();
    if (!frame->IsMain()) return false;
    const int id = browser->GetIdentifier();
    auto& item = pending_[id];
    const std::string url = request->GetURL();
    if (!redirect) {
      item.generation = ++sequence_;
      item.url = url;
      if (IsWeb(url)) {
        const auto generation = item.generation;
        CefRefPtr<BrowserClient> self(this);
        CefPostDelayedTask(TID_UI, new CallbackTask(
            [self, browser, generation]() { self->CheckDeadline(browser, generation); }),
            timeout_ms_);
      }
    } else {
      item.url = url;  // Redirects do not extend the absolute navigation budget.
    }
    return false;
  }
  void OnLoadingStateChange(CefRefPtr<CefBrowser> browser, bool loading,
                            bool, bool) override {
    if (!loading) pending_.erase(browser->GetIdentifier());
  }
  void OnLoadError(CefRefPtr<CefBrowser> browser, CefRefPtr<CefFrame> frame,
                   ErrorCode code, const CefString&, const CefString&) override {
    if (frame->IsMain() && code != ERR_ABORTED) {
      pending_.erase(browser->GetIdentifier());
      Record("main-navigation-error " + std::to_string(static_cast<int>(code)));
    }
    // Do not replace Chromium's native network/TLS error page or bypass TLS.
  }
  void set_timeout(int value) { timeout_ms_ = value; }
 private:
  struct Pending { uint64_t generation = 0; std::string url; };
  void CheckDeadline(CefRefPtr<CefBrowser> browser, uint64_t generation) {
    CEF_REQUIRE_UI_THREAD();
    const auto it = pending_.find(browser->GetIdentifier());
    if (it == pending_.end() || it->second.generation != generation ||
        !browser->IsValid() || !browser->IsLoading()) return;
    const auto url = it->second.url;
    pending_.erase(it);
    browser->StopLoad();
    Record("main-navigation-deadline");
    const auto encoded = CefURIEncode(url, true).ToString();
    browser->GetMainFrame()->LoadURL("chrome-extension://" + home_id +
                                    "/network.html?url=" + encoded);
  }
  std::list<CefRefPtr<CefBrowser>> browsers_;
  std::map<int, Pending> pending_;
  uint64_t sequence_ = 0;
  int timeout_ms_ = 45000;
  IMPLEMENT_REFCOUNTING(BrowserClient);
};
class NomaApp final : public CefApp, public CefBrowserProcessHandler,
                      public CefResourceBundleHandler {
 public:
  CefRefPtr<CefResourceBundleHandler> GetResourceBundleHandler() override {
    return this;
  }
  bool GetLocalizedString(int id, CefString& value) override {
    static const int product = cef_id_for_pack_string_name("IDS_PRODUCT_NAME");
    static const int short_product = cef_id_for_pack_string_name("IDS_SHORT_PRODUCT_NAME");
    if (id == product || id == short_product) { value = "Noma"; return true; }
    return false;
  }
  bool GetDataResource(int, void*&, size_t&) override { return false; }
  bool GetDataResourceForScale(int, ScaleFactor, void*&, size_t&) override {
    return false;
  }
 public:
  CefRefPtr<CefBrowserProcessHandler> GetBrowserProcessHandler() override {
    return this;
  }
  void OnBeforeCommandLineProcessing(const CefString& process_type,
                                     CefRefPtr<CefCommandLine> cmd) override {
    if (!process_type.empty()) return;
    const auto extension = (AppDirectory() / L"nomahome").wstring();
    std::wstring extensions = extension;
    // CI fixture extension is allowed only in an explicit isolated test launch.
    if (cmd->HasSwitch("noma-test") && cmd->HasSwitch("noma-test-extension"))
      extensions += L"," + cmd->GetSwitchValue("noma-test-extension").ToWString();
    cmd->AppendSwitchWithValue("load-extension", extensions);
    cmd->AppendSwitch("no-first-run");
    cmd->AppendSwitch("no-default-browser-check");
    // No certificate bypasses, automation disguises, proxy overrides or Node.
  }
  void OnContextInitialized() override {
    CEF_REQUIRE_UI_THREAD();
    client_ = new BrowserClient;
    if (!std::filesystem::exists(profile / L"noma-theme-initialized")) {
      CefRequestContext::GetGlobalContext()->SetChromeColorScheme(
          CEF_COLOR_VARIANT_SYSTEM, CefColorSetARGB(255, 34, 102, 73));
      std::ofstream marker(profile / L"noma-theme-initialized");
      marker << "1";
    }
    auto cmd = CefCommandLine::GetGlobalCommandLine();
    if (cmd->HasSwitch("noma-test")) client_->set_timeout(7000);
    CefWindowInfo window;
    window.SetAsPopup(nullptr, "Noma");
    window.runtime_style = CEF_RUNTIME_STYLE_CHROME;
    window.bounds = CefRect(40, 40, 1366, 900);
    CefBrowserSettings settings;
    std::string url = "chrome://newtab/";
    if (cmd->HasSwitch("url")) url = cmd->GetSwitchValue("url");
    CefBrowserHost::CreateBrowser(window, client_, url, settings, nullptr, nullptr);
  }
  CefRefPtr<CefClient> GetDefaultClient() override { return client_; }
 private:
  CefRefPtr<BrowserClient> client_;
  IMPLEMENT_REFCOUNTING(NomaApp);
};
int Run(HINSTANCE instance, void* sandbox_info) {
  CefMainArgs args(instance);
  CefRefPtr<NomaApp> app(new NomaApp);
  const int subprocess = CefExecuteProcess(args, app, sandbox_info);
  if (subprocess >= 0) return subprocess;
  if (!sandbox_info) {
    MessageBoxW(nullptr, L"Не удалось включить песочницу Chromium. Переустановите Noma.",
                L"Noma", MB_OK | MB_ICONERROR);
    return 1;
  }
  auto cmd = CefCommandLine::CreateCommandLine();
  cmd->InitFromString(GetCommandLineW());
  profile = ProfileDirectory(cmd);
  std::filesystem::create_directories(profile);
  std::ifstream idfile(AppDirectory() / L"nomahome" / L"extension-id.txt");
  std::getline(idfile, home_id);
  if (home_id.size() != 32) return 2;
  CefSettings settings;
  CefString(&settings.root_cache_path) = profile.wstring();
  CefString(&settings.cache_path) = (profile / L"Default").wstring();
  CefString(&settings.log_file) = (profile / L"chromium.log").wstring();
  CefString(&settings.locale) = "ru";
  CefString(&settings.accept_language_list) = "ru-RU,ru,en-US,en";
  settings.persist_session_cookies = true;
  settings.chrome_app_icon_id = 101;
  settings.log_severity = LOGSEVERITY_WARNING;
  // Remote debugging is off for normal users; CI opts in explicitly.
  if (cmd->HasSwitch("noma-test") && cmd->HasSwitch("remote-debugging-port")) {
    const auto value = cmd->GetSwitchValue("remote-debugging-port").ToString();
    settings.remote_debugging_port = std::stoi(value);
  }
  if (!CefInitialize(args, settings, app, sandbox_info)) return CefGetExitCode();
  Record("initialized version=0.7.0 sandbox=required");
  CefRunMessageLoop();
  CefShutdown();
  return 0;
}
} // namespace
CEF_BOOTSTRAP_EXPORT int RunWinMain(HINSTANCE instance, LPWSTR, int,
                                    void* sandbox_info, cef_version_info_t*) {
  try { return Run(instance, sandbox_info); }
  catch (const std::exception&) {
    MessageBoxW(nullptr, L"Noma не удалось запустить. Проверьте права доступа к папке профиля.",
                L"Noma", MB_OK | MB_ICONERROR);
    return 1;
  }
}
