# Third-party notices — development distribution

This inventory is not a legal opinion or a completed license-compliance audit. Review
all transitive dependencies and the actual shipped binary set before redistribution.
No installer or executable is currently signed. No production-readiness claim is made.

| Component | Pin / source | License / distribution notes |
| --- | --- | --- |
| Chromium Embedded Framework / Chromium | CEF 152.0.14+g8a0b5b9, Chromium 152.0.7977.167; https://cef-builds.spotifycdn.com/ | CEF BSD-style license, Chromium and bundled third-party notices. The exact distribution's `LICENSE.txt` is copied to `licenses/CEF-LICENSE.txt`. Preserve all notices in the upstream runtime. |
| Qt | 6.11.2 MSVC2022 x64; https://download.qt.io/official_releases/qt/6.11/6.11.2/ | Qt modules have LGPL/GPL/commercial alternatives and exceptions. Use eligible dynamically linked modules or a valid commercial license; supply relevant license texts, source/relinking instructions and notices as required. Do not assume every Qt module is LGPL. |
| SQLite | Vendored source identifies its exact version; https://sqlite.org/copyright.html | Public domain dedication; jurisdictions and bundled extensions may require separate review. |
| Microsoft Visual C++ runtime | Redistributables selected by `windeployqt --compiler-runtime` | Microsoft redistribution terms apply. Requires licensed Visual Studio/toolchain rights. |
| Inno Setup | Major version 6; https://jrsoftware.org/ | Build-only compiler supplied by the Windows validation runner. The actual compiler version and SHA256 are recorded in the packaging log. Review its licensing, including commercial-use terms. It is not a browser runtime dependency. |

## Distribution checklist

- Ship the project license and every applicable upstream license/notice in `licenses/`.
- Collect Qt license texts for the actual installed kit; pass their directory to deploy.
- Verify the final binary manifest, dynamically linked Qt modules, and required source/relinking offers.
- Review Chromium codecs/patents and any trademark use separately.
- Do not describe legacy SHA1 checks as publisher authentication. HTTPS + pinned SHA256
  provide transport/integrity checks, not a code-signing or supply-chain audit.
- No filter subscription downloaded at runtime is licensed by this document.

## Legacy sources not linked into the current desktop target

The repository retains an earlier `rust/adblock` experiment and its license inventory.
The current C++ desktop CMake target does not compile or link that library and does
not download filter subscriptions. Do not advertise an integrated ad blocker or
filter-list service based on those unused sources.

Original SVG paths in resources/icons are project-authored and covered by LICENSE.
The Google, YouTube, Wikipedia and GitHub shortcut artwork identifies third-party
sites and is not a claim of sponsorship or affiliation. Review applicable trademark
and artwork conditions before a public release.
SQLite's exact vendored version is 3.50.4; see third_party/sqlite/README.md.
