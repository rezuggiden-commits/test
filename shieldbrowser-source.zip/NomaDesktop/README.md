# Noma Desktop — own C++ UI

This source branch replaces the rejected stock Chromium shell. The tab strip,
address bar, navigation, menus, library, download panel, preferences and private
window are native C++/Qt code. CEF Alloy is used only for website rendering.
There is no Electron entry point, AI, VPN or Chrome new-tab override extension.

## Not released

A successful build or local smoke test is not approval for public distribution.
See docs/RELEASE-GATES.md. This branch must not be published as a finished browser.
Existing Noma/Electron and 0.7 profiles are not silently imported or overwritten.

## Build

Windows x64, VS 2022 C++, Qt 6.11.2 and pinned CEF 152.0.14. Use tools/ci_windows.ps1
for the full Windows build and real native UI smoke test. Core logic can be tested
on Linux using CMake with SHIELD_BUILD_BROWSER=OFF. SQLite is vendored.
