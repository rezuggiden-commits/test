[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
$portFile=Join-Path $runtime 'port.txt';$jsProof=Join-Path $runtime 'page-js.json'
$server=Start-Process python -ArgumentList @("$PSScriptRoot/smoke_server.py",'--proof',$jsProof,'--port-file',$portFile) -PassThru -RedirectStandardOutput (Join-Path $runtime 'http.log') -RedirectStandardError (Join-Path $runtime 'http-errors.log')
$app=$null
try{
 $limit=(Get-Date).AddSeconds(20);while(!(Test-Path $portFile)-and(Get-Date)-lt$limit){Start-Sleep -Milliseconds 100}
 if(!(Test-Path $portFile)){throw 'Loopback server did not start'}
 $port=(Get-Content $portFile -Raw).Trim();$env:SHIELD_START_URL="http://127.0.0.1:$port/";$env:SHIELD_TEST_PROOF=Join-Path $runtime 'cef-load.json';$env:SHIELD_UI_AUTOMATION=$runtime;$env:SHIELD_DOWNLOAD_TEST_URL="http://127.0.0.1:$port/test-download.txt"
 $watch=[Diagnostics.Stopwatch]::StartNew();$app=Start-Process (Join-Path $Stage 'Noma.exe') -WorkingDirectory $Stage -PassThru
 if(!$app.WaitForExit(90000)){throw 'Native UI tour or clean close timed out'}
 if($app.ExitCode -ne 0){throw "Native exit code $($app.ExitCode)"}
 $result=Join-Path $runtime 'native-ui-result.json';if(!(Test-Path $result)){throw 'No actual UI evidence'}
 $checks=Get-Content $result -Raw | ConvertFrom-Json
 foreach($item in $checks.PSObject.Properties){if($item.Value -ne $true){throw "Native UI check failed: $($item.Name)"}}
 if((Get-Content (Join-Path $runtime 'fixture-download.txt') -Raw).Trim() -ne 'Aster download fixture'){throw 'Actual download payload mismatch'}
 foreach($file in @('native-home-dark.png','native-home-light.png','native-downloads.png','native-settings.png','native-history-filter.png','native-private.png')){if(!(Test-Path (Join-Path $runtime $file))){throw "Screenshot missing: $file"}}
 @{status='native-ui-smoke-passed';durationMs=$watch.ElapsedMilliseconds;scope='Windows CI, loopback fixture, actual Qt/CEF UI; not a release approval';checks=$checks} | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $runtime 'summary.json')
}finally{
 if($app){$app.Refresh();if(!$app.HasExited){$app.CloseMainWindow()|Out-Null;if(!$app.WaitForExit(10000)){Stop-Process -Id $app.Id -Force}}}
 if(!$server.HasExited){Stop-Process -Id $server.Id -Force}
}
