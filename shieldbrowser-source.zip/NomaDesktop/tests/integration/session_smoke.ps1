[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime/session'
$profile=Join-Path $env:LOCALAPPDATA 'Noma/Desktop/User Data'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
$portFile=Join-Path $runtime 'port.txt'
$server=Start-Process python -WindowStyle Hidden -ArgumentList @("$PSScriptRoot/smoke_server.py",'--proof',"$runtime/page-js.json",'--port-file',$portFile) -PassThru -RedirectStandardOutput "$runtime/http.log" -RedirectStandardError "$runtime/http-errors.log"
$app=$null;$results=@()
try{
 foreach($name in @('SHIELD_START_URL','SHIELD_TEST_PROOF','SHIELD_UI_AUTOMATION','SHIELD_DOWNLOAD_TEST_URL','SHIELD_EXPECT_RESTORED_DOWNLOADS','SHIELD_EXTERNAL_TEST')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 $deadline=(Get-Date).AddSeconds(20);while(!(Test-Path $portFile)-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
 if(!(Test-Path $portFile)){throw 'Session server did not start'}
 $port=(Get-Content $portFile -Raw).Trim()
 foreach($scenario in @('clean','accept','decline')){
  $directory=Join-Path $runtime $scenario;New-Item -ItemType Directory -Path $directory -Force | Out-Null
  Remove-Item "$runtime/launch-first.json","$runtime/launch-second.json" -ErrorAction SilentlyContinue
  & python "$PSScriptRoot/session_seed.py" $profile $port $(if($scenario -eq 'clean'){1}else{0})
  if($LASTEXITCODE -ne 0){throw 'Could not seed session fixture'}
  $env:SHIELD_SESSION_TEST=$directory;$env:SHIELD_SESSION_CHOICE=$scenario
  $app=Start-Process (Join-Path $Stage 'Noma.exe') -WorkingDirectory $Stage -PassThru
  $deadline=(Get-Date).AddSeconds(25);while(!(Test-Path "$directory/session-result.json")-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
  if(!(Test-Path "$directory/session-result.json")){throw "No session proof: $scenario"}
  $proof=Get-Content "$directory/session-result.json" -Raw | ConvertFrom-Json
  if($proof.prompted -ne ($scenario -ne 'clean')){throw "Wrong crash recovery prompt: $scenario"}
  if($proof.restored -ne ($scenario -ne 'decline')){throw "Wrong restoration result: $scenario"}
  if($scenario -eq 'decline'){
   if($proof.tabs.Count -ne 1 -or $proof.activeUrl -ne 'shield://newtab/'){throw 'Declining recovery did not leave a new tab'}
   if(Test-Path "$runtime/launch-second.json"){throw 'Declined session still requested a previous site'}
  }else{
   if($proof.tabs.Count -ne 3 -or $proof.activeIndex -ne 2 -or $proof.activeUrl -ne "http://127.0.0.1:$port/launch-second"){throw 'Restored order or selected tab changed'}
   if($proof.createdBrowsers -ne 1){throw 'Background restored tabs created renderers eagerly'}
   if(!(Test-Path "$runtime/launch-second.json")){throw 'Active restored tab never reached its server'}
  }
  if(Test-Path "$runtime/launch-first.json"){throw 'Inactive restored tab loaded eagerly'}
  $app.Refresh();if($app.HasExited -or !$app.CloseMainWindow()){throw 'Restored browser exited or cannot close'}
  if(!$app.WaitForExit(20000)-or$app.ExitCode -ne 0){throw 'Restored browser did not close cleanly'}
  $results+=@{scenario=$scenario;passed=$true;proof=$proof}
 }
 $results | ConvertTo-Json -Depth 8 | Set-Content "$runtime/summary.json"
}finally{
 foreach($name in @('SHIELD_SESSION_TEST','SHIELD_SESSION_CHOICE')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 if($app){$app.Refresh();if(!$app.HasExited){Stop-Process -Id $app.Id -Force}}
 if(!$server.HasExited){Stop-Process -Id $server.Id -Force}
}
