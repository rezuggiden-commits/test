"""Seed a loopback-only fixture in the stopped CI profile, not a user profile."""
import json, sqlite3, sys
from pathlib import Path
profile, port, clean = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
if clean not in (0, 1) or not 1 <= port <= 65535:
    raise ValueError('Invalid fixture input')
with sqlite3.connect(profile / 'browser.sqlite') as db:
    if db.execute('PRAGMA application_id').fetchone()[0] != 1397247044:
        raise RuntimeError('Not the Noma CI profile schema')
    db.execute('DELETE FROM session_tabs')
    db.executemany('INSERT INTO session_tabs(position,url,title) VALUES(?,?,?)', [
        (0, f'http://127.0.0.1:{port}/launch-first', 'Lazy background'),
        (1, 'shield://newtab/', 'Home'),
        (2, f'http://127.0.0.1:{port}/launch-second', 'Active restored tab'),
    ])
    db.execute('UPDATE session_state SET active_index=2,clean_shutdown=? WHERE singleton=1', (clean,))
