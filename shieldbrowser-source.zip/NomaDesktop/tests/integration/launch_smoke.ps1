[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime/launch'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
$portFile=Join-Path $runtime 'port.txt'
$server=Start-Process python -WindowStyle Hidden -ArgumentList @("$PSScriptRoot/smoke_server.py",'--proof',"$runtime/page-js.json",'--port-file',$portFile) -PassThru -RedirectStandardOutput "$runtime/http.log" -RedirectStandardError "$runtime/http-errors.log"
$app=$null
try{
 foreach($name in @('SHIELD_START_URL','SHIELD_TEST_PROOF','SHIELD_UI_AUTOMATION','SHIELD_DOWNLOAD_TEST_URL','SHIELD_EXPECT_RESTORED_DOWNLOADS')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 $deadline=(Get-Date).AddSeconds(20);while(!(Test-Path $portFile)-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
 if(!(Test-Path $portFile)){throw 'URL launch fixture did not start'}
 $port=(Get-Content $portFile -Raw).Trim();$first="http://127.0.0.1:$port/launch-first";$second="http://127.0.0.1:$port/launch-second"
 $app=Start-Process (Join-Path $Stage 'Noma.exe') -ArgumentList @($first) -WorkingDirectory $Stage -PassThru
 $deadline=(Get-Date).AddSeconds(20);while(!(Test-Path "$runtime/launch-first.json")-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
 if(!(Test-Path "$runtime/launch-first.json")){throw 'Initial command-line URL was not loaded'}
 $client=Start-Process (Join-Path $Stage 'Noma.exe') -ArgumentList @($second) -WorkingDirectory $Stage -PassThru
 if(!$client.WaitForExit(8000) -or $client.ExitCode -ne 0){throw 'Second instance did not hand its URL to the running browser'}
 $deadline=(Get-Date).AddSeconds(20);while(!(Test-Path "$runtime/launch-second.json")-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
 if(!(Test-Path "$runtime/launch-second.json")){throw 'Running browser did not navigate to the delivered URL'}
 $app.Refresh();if($app.HasExited){throw 'Primary browser exited during URL handoff'}
 if(!$app.CloseMainWindow()){throw 'Could not close primary browser'}
 if(!$app.WaitForExit(20000) -or $app.ExitCode -ne 0){throw 'URL launch browser did not close cleanly'}
 @{initialUrl=$true;singleInstanceHandoff=$true;deliveredUrlLoaded=$true;cleanClose=$true} | ConvertTo-Json | Set-Content "$runtime/summary.json"
}finally{
 if($app){$app.Refresh();if(!$app.HasExited){Stop-Process -Id $app.Id -Force}}
 if(!$server.HasExited){Stop-Process -Id $server.Id -Force}
}
