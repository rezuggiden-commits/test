[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime/permission'
New-Item -ItemType Directory -Path $runtime -Force | Out-Null
$portFile=Join-Path $runtime 'port.txt'
$server=Start-Process python -WindowStyle Hidden -ArgumentList @("$PSScriptRoot/smoke_server.py",'--proof',"$runtime/page-js.json",'--port-file',$portFile) -PassThru -RedirectStandardOutput "$runtime/http.log" -RedirectStandardError "$runtime/http-errors.log"
$app=$null
try{
 foreach($name in @('SHIELD_START_URL','SHIELD_TEST_PROOF','SHIELD_UI_AUTOMATION','SHIELD_DOWNLOAD_TEST_URL','SHIELD_EXPECT_RESTORED_DOWNLOADS','SHIELD_EXTERNAL_TEST')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 $deadline=(Get-Date).AddSeconds(20);while(!(Test-Path $portFile)-and(Get-Date)-lt$deadline){Start-Sleep -Milliseconds 100}
 if(!(Test-Path $portFile)){throw 'Permission fixture did not start'}
 $port=(Get-Content $portFile -Raw).Trim();$env:SHIELD_PERMISSION_TEST=$runtime;$env:SHIELD_TEST_PROOF="$runtime/cef-load.json"
 $app=Start-Process (Join-Path $Stage 'Noma.exe') -ArgumentList @("http://127.0.0.1:$port/media-request") -WorkingDirectory $Stage -PassThru
 $deadline=(Get-Date).AddSeconds(25);$events=@()
 while((Get-Date)-lt$deadline){
  $app.Refresh();if($app.HasExited){throw 'Permission test browser exited unexpectedly'}
  if(Test-Path "$runtime/permission-events.jsonl"){$events=@(Get-Content "$runtime/permission-events.jsonl" | ForEach-Object {$_ | ConvertFrom-Json})}
  if(@($events | Where-Object event -eq 'staleApprovalRejected').Count -gt 0){break}
  Start-Sleep -Milliseconds 100
 }
 foreach($event in @('requested','promptShown','cancelledOnNavigationOrClose','staleApprovalRejected','promptDestroyed')){if(@($events | Where-Object event -eq $event).Count -ne 1){throw "Permission lifecycle evidence missing or duplicated: $event"}}
 if(@($events | Where-Object event -eq 'approved').Count -ne 0){throw 'Stale permission request was approved'}
 $ids=@($events | Select-Object -ExpandProperty id -Unique);if($ids.Count -ne 1){throw 'Permission events refer to different requests'}
 if(!(Test-Path "$runtime/native-media-permission.png") -or !(Test-Path "$runtime/permission-after.json")){throw 'Missing real permission UI or post-navigation server proof'}
 $proof=Get-Content "$runtime/cef-load.json" -Raw | ConvertFrom-Json;if($proof.url -ne "http://127.0.0.1:$port/permission-after"){throw 'New document did not finish loading'}
 if(!$app.CloseMainWindow() -or !$app.WaitForExit(20000) -or $app.ExitCode -ne 0){throw 'Permission test browser did not close cleanly'}
 @{actualPrompt=$true;navigationCancelled=$true;lateApprovalRejected=$true;promptDestroyed=$true;cleanClose=$true;scope='Windows CI, fake audio device, real getUserMedia and native prompt; not hardware compatibility certification'} | ConvertTo-Json | Set-Content "$runtime/summary.json"
}finally{
 foreach($name in @('SHIELD_PERMISSION_TEST','SHIELD_TEST_PROOF')){Remove-Item "Env:$name" -ErrorAction SilentlyContinue}
 if($app){$app.Refresh();if(!$app.HasExited){Stop-Process -Id $app.Id -Force}}
 if(!$server.HasExited){Stop-Process -Id $server.Id -Force}
}
