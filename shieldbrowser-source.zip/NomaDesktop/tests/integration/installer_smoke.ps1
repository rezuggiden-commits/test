[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Installer)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$runtime=Join-Path $root 'docs/runtime'
$install=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs/Noma'))
$profile=Join-Path $env:LOCALAPPDATA 'Noma/Desktop/User Data'
function RunInstaller([string]$log){
 $process=Start-Process $Installer -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/SP-',"/LOG=$runtime/$log") -Wait -PassThru
 if($process.ExitCode -ne 0){throw "Installer failed: $($process.ExitCode)"}
 if(!(Test-Path "$install/Noma.exe")){throw 'Installed browser is missing'}
}
RunInstaller 'install.log'
$capability=(Get-ItemProperty 'HKCU:/Software/RegisteredApplications').Noma
if($capability -ne 'Software\Noma\Capabilities'){throw 'Default-browser registration is missing'}
$command=(Get-Item 'HKCU:/Software/Classes/NomaURL/shell/open/command').GetValue('')
if(!$command.Contains("$install\Noma.exe")){throw 'URL association command is invalid'}
& "$PSScriptRoot/native_smoke.ps1" -Stage $install -EvidenceLabel installed -ExpectPersistentCookie
$marker=Join-Path $profile 'installer-preserve.txt';'Noma profile preservation fixture' | Set-Content $marker
RunInstaller 'upgrade.log'
if(!(Test-Path $marker)){throw 'Upgrade removed profile data'}
& "$PSScriptRoot/native_smoke.ps1" -Stage $install -EvidenceLabel upgrade -ExpectPersistentCookie
& "$PSScriptRoot/session_smoke.ps1" -Stage $install
& "$PSScriptRoot/launch_smoke.ps1" -Stage $install
& "$PSScriptRoot/public_sites_smoke.ps1" -Stage $install
$uninstall=Get-ChildItem $install -Filter 'unins*.exe' | Select-Object -First 1
if(!$uninstall){throw 'Uninstaller missing'}
$process=Start-Process $uninstall.FullName -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',"/LOG=$runtime/uninstall.log") -Wait -PassThru
if($process.ExitCode -ne 0){throw "Uninstall failed: $($process.ExitCode)"}
if(Test-Path "$install/Noma.exe"){throw 'Uninstall left browser binaries behind'}
if(!(Test-Path $marker)){throw 'Silent uninstall removed profile data'}
if(Test-Path 'HKCU:/Software/Classes/NomaURL'){throw 'Uninstall left URL registrations behind'}
@{installed=$true;upgrade=$true;uninstalled=$true;profilePreserved=$true;cookiePersisted=$true;downloadsRestored=$true;scope='Windows hosted runner; not Windows 10/11 consumer-device certification'} | ConvertTo-Json | Set-Content "$runtime/installer-result.json"
