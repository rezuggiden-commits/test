#include "shield/core/navigation.h"
#include "shield/core/storage.h"
#include "sqlite3.h"
#include <atomic>
#include <chrono>
#include <filesystem>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

using namespace shield::core;
namespace {
int assertions=0, passed=0, failed=0;
void check(bool condition,const char* expression,int line) {
    ++assertions;if(!condition) throw std::runtime_error(std::string("line ")+std::to_string(line)+": "+expression);
}
#define CHECK(x) check(static_cast<bool>(x),#x,__LINE__)
template<class E=std::invalid_argument,class F> void throws(F&& f) {
    bool caught=false;try{f();}catch(const E&){caught=true;}CHECK(caught);
}
void test(const char* name,const std::function<void()>& run) {
    try{run();++passed;std::cout<<"PASS "<<name<<'\n';}
    catch(const std::exception& e){++failed;std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n';}
}
struct TempDb {
    std::filesystem::path dir,path;
    TempDb(){
        static std::atomic<int> counter=0;
        dir=std::filesystem::temp_directory_path()/("shield-core-tests-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count())+"-"+std::to_string(counter++));
        std::filesystem::create_directory(dir);path=dir/"profile.sqlite";
    }
    ~TempDb(){std::error_code ec;std::filesystem::remove_all(dir,ec);}
    std::string str() const {auto utf8=path.u8string();return {utf8.begin(),utf8.end()};}
};
void raw(const std::string& path,const char* sql) {
    sqlite3* db=nullptr;
    if(sqlite3_open(path.c_str(),&db)!=SQLITE_OK){if(db)sqlite3_close(db);throw std::runtime_error("raw open failed");}
    auto rc=sqlite3_exec(db,sql,nullptr,nullptr,nullptr);
    std::string error=sqlite3_errmsg(db);sqlite3_close(db);
    if(rc!=SQLITE_OK)throw std::runtime_error("raw SQL: "+error);
}
} // namespace
int main() {
    test("pinned SQLite build identity",[]{
        CHECK(std::string(sqlite3_libversion())=="3.50.4");
        CHECK(std::string(sqlite3_sourceid())=="2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3");
        CHECK(sqlite3_threadsafe()==1);
        CHECK(sqlite3_compileoption_used("OMIT_LOAD_EXTENSION")==1);
    });
    test("empty string views remain empty SQL text",[]{
        Storage s(":memory:");
        s.setSetting("empty",std::string_view{});CHECK(s.setting("empty").has_value());CHECK(*s.setting("empty")=="");
        s.recordVisit("https://empty.test",std::string_view{},1);CHECK(s.history()[0].title.empty());
        s.addBookmark("https://empty.test",std::string_view{},1);CHECK(s.bookmarks()[0].title.empty());
    });
    test("web normalization and ports",[]{
        auto r=classifyNavigation("  HTTPS://Example.COM:443/a b?q=One#Two  ");
        CHECK(r.kind==NavigationKind::Web);CHECK(r.url=="https://example.com:443/a%20b?q=One#Two");
        CHECK(classifyNavigation("example.com").url=="https://example.com/");
        CHECK(classifyNavigation("localhost:8080/path").url=="https://localhost:8080/path");
        CHECK(classifyNavigation("http://127.0.0.1").allowed());
        CHECK(classifyNavigation("https://example.com?q=1").url=="https://example.com/?q=1");
        CHECK(!classifyNavigation("http://example.com:0").allowed());
        CHECK(!classifyNavigation("http://example.com:65536").allowed());
        CHECK(!classifyNavigation("http://example.com:").allowed());
        CHECK(!classifyNavigation("http://256.1.1.1").allowed());
        CHECK(!classifyNavigation("http://01.2.3.4").allowed());
        CHECK(!classifyNavigation("http://a..com").allowed());
        CHECK(!classifyNavigation("http://-a.com").allowed());
        CHECK(!classifyNavigation("http://a_.com").allowed());
        CHECK(!classifyNavigation("https://пример.рф").allowed());
        CHECK(classifyNavigation("https://xn--e1afmkfd.xn--p1ai").allowed());
    });
    test("IPv6 grammar",[]{
        for(auto s:{"http://[::1]","https://[2001:db8::1]:8443/a","http://[1:2:3:4:5:6:7:8]","http://[::ffff:192.0.2.1]"}) CHECK(classifyNavigation(s).allowed());
        for(auto s:{"http://[:::]","http://[1::2::3]","http://[1:2:3]","http://[gg::1]","http://[::1]junk","http://[::1]:99999","http://[fe80::1%25eth0]","http://[1:2:3:4:5:6:7:8::]"}) CHECK(!classifyNavigation(s).allowed());
    });
    test("query encoding and provider validation",[]{
        CHECK(encodeQuery("a b&c/é")=="a%20b%26c%2F%C3%A9");
        auto r=classifyNavigation("two words & more");CHECK(r.kind==NavigationKind::Search);
        CHECK(r.url=="https://www.google.com/search?q=two%20words%20%26%20more");
        CHECK(classifyNavigation("hello").kind==NavigationKind::Search);
        NavigationOptions options;options.search_prefix="https://search.example/?q=";
        CHECK(classifyNavigation("a b",options).url=="https://search.example/?q=a%20b");
        options.search_prefix="javascript:alert(1)";CHECK(!classifyNavigation("a b",options).allowed());
        options.search_prefix="http://search.example/?q=";CHECK(!classifyNavigation("a b",options).allowed());
        options.search_prefix="https://user:pw@search.example/?q=";CHECK(!classifyNavigation("a b",options).allowed());
        options.search_prefix="https://search.example/#q=";CHECK(!classifyNavigation("a b",options).allowed());
    });
    test("unsafe input and schemes",[]{
        for(auto s:{"","   ","javascript:alert(1)","data:text/html,hello","vbscript:1","ftp://example.com","https://user:pass@example.com","https://example.com\\evil","shield://unknown","http:///path","https://","https://a.com\nX"}) CHECK(!classifyNavigation(s).allowed());
        CHECK(!classifyNavigation(std::string("https://a.com\0bad",17)).allowed());
        CHECK(!classifyNavigation(std::string(8193,'a')).allowed());
        CHECK(classifyNavigation("about:blank").kind==NavigationKind::Internal);
        CHECK(classifyNavigation("SHIELD://settings").url=="shield://settings");
        CHECK(!classifyNavigation("mailto:a@example.com").allowed());
        NavigationOptions opt;opt.allow_external_protocols=true;opt.allow_local_files=true;
        CHECK(classifyNavigation("mailto:a@example.com",opt).kind==NavigationKind::ExternalProtocol);
        CHECK(classifyNavigation("tel:+15551234567",opt).kind==NavigationKind::ExternalProtocol);
        CHECK(!classifyNavigation("mailto:",opt).allowed());
        CHECK(!classifyNavigation("file:///C:/test.html").allowed());
        CHECK(classifyNavigation("file:///C:/test.html",opt).kind==NavigationKind::LocalFile);
        CHECK(!classifyNavigation("file://server/share",opt).allowed());
        CHECK(!classifyNavigation("file:relative",opt).allowed());
    });
    test("persistence URL allowlist",[]{
        CHECK(isPersistableUrl("https://example.com"));CHECK(isPersistableUrl("about:blank"));
        CHECK(isPersistableUrl("shield://newtab"));CHECK(isPersistableUrl("shield://newtab/"));CHECK(classifyNavigation("shield://newtab/").kind==NavigationKind::Internal);CHECK(!isPersistableUrl("example.com"));
        CHECK(!isPersistableUrl("some query"));CHECK(!isPersistableUrl("file:///C:/a"));
        CHECK(!isPersistableUrl("https://u:p@example.com"));CHECK(!isPersistableUrl("javascript:1"));
    });
    test("history upsert ordering pagination retention",[]{
        Storage s(":memory:");CHECK(s.integrityCheck()=="ok");CHECK(s.history().empty());
        CHECK(s.recordVisit("HTTPS://Example.COM","first",100));
        CHECK(s.recordVisit("https://example.com/","new",200));
        CHECK(s.recordVisit("https://example.com/","old",50));
        s.recordVisit("https://second.test/","second",200);
        auto h=s.history();CHECK(h.size()==2);CHECK(h[0].url=="https://second.test/");
        CHECK(h[1].visit_count==3);CHECK(h[1].title=="new");CHECK(h[1].last_visit_ms==200);
        CHECK(s.history(1,1)[0].url=="https://example.com/");CHECK(s.history(0).empty());
        s.pruneHistoryBefore(200);CHECK(s.history().size()==2);
        s.pruneHistoryBefore(201);CHECK(s.history().empty());
        throws([&]{(void)s.history(10001);});throws([&]{s.pruneHistoryBefore(-1);});
        s.recordVisit("https://a.test","a",1);s.clearHistory();CHECK(s.history().empty());
    });
    test("privacy history suppression and validation",[]{
        Storage s(":memory:");PrivacyFlags p;p.private_mode=true;
        CHECK(!s.recordVisit("https://secret.test","secret",1,p));
        p.private_mode=false;p.record_history=false;CHECK(!s.recordVisit("https://secret.test","secret",1,p));
        CHECK(s.history().empty());CHECK(!s.recordVisit("shield://settings","settings",2));
        throws([&]{s.recordVisit("javascript:1","bad",1);});
        throws([&]{s.recordVisit("https://a.test","bad",-1);});
        throws([&]{s.recordVisit("https://a.test",std::string(4097,'x'),1);});
        throws([&]{s.recordVisit("https://a.test",std::string("a\0b",3),1);});
        CHECK(s.history().empty());
    });
    test("bookmarks idempotence and SQL binding",[]{
        Storage s(":memory:");auto id=s.addBookmark("https://example.com","Robert'); DROP TABLE bookmarks;--",10);
        CHECK(id>0);CHECK(s.bookmarks().size()==1);
        CHECK(s.addBookmark("https://EXAMPLE.com/","renamed",99)==id);
        auto b=s.bookmarks();CHECK(b[0].title=="renamed");CHECK(b[0].created_ms==10);
        CHECK(s.addBookmark("shield://history","History",20)>0);
        CHECK(s.bookmarks()[0].url=="shield://history");
        CHECK(s.removeBookmark(id));CHECK(!s.removeBookmark(id));CHECK(!s.removeBookmark(-1));
        throws([&]{s.addBookmark("file:///x","x",1);});CHECK(s.integrityCheck()=="ok");
    });
    test("settings and bounds",[]{
        Storage s(":memory:");CHECK(!s.setting("ui.theme"));
        s.setSetting("ui.theme","dark");CHECK(s.setting("ui.theme")=="dark");
        s.setSetting("ui.theme","");CHECK(s.setting("ui.theme").has_value());CHECK(*s.setting("ui.theme")=="");
        s.setSetting("sql","'; DROP TABLE history; --");CHECK(s.setting("sql")=="'; DROP TABLE history; --");
        s.setSetting("unicode","Привет 🌍");CHECK(s.setting("unicode")=="Привет 🌍");
        CHECK(s.removeSetting("ui.theme"));CHECK(!s.removeSetting("ui.theme"));
        throws([&]{s.setSetting("", "x");});throws([&]{s.setSetting("bad key", "x");});
        throws([&]{s.setSetting("ok",std::string(65537,'x'));});CHECK(s.integrityCheck()=="ok");
    });
    test("session privacy active remapping and clean state",[]{
        Storage s(":memory:");CHECK(s.loadSession().tabs.empty());CHECK(s.loadSession().clean_shutdown);
        SessionSnapshot snap{{{"https://private.test","secret",true},{"https://one.test","one",false},{"about:blank","blank",false}},2,false};
        CHECK(s.saveSession(snap));auto saved=s.loadSession();CHECK(saved.tabs.size()==2);
        CHECK(saved.active_index==1);CHECK(!saved.clean_shutdown);CHECK(saved.tabs[0].url=="https://one.test/");
        CHECK(!saved.tabs[0].private_mode);s.markSessionClean(true);CHECK(s.loadSession().clean_shutdown);
        PrivacyFlags p;p.private_mode=true;CHECK(!s.saveSession({},p));CHECK(s.loadSession().tabs.size()==2);
        p.private_mode=false;p.persist_session=false;CHECK(!s.saveSession({},p));CHECK(s.loadSession().tabs.size()==2);
        snap.active_index=0;s.saveSession(snap);CHECK(s.loadSession().active_index==0);
        s.clearSession();CHECK(s.loadSession().tabs.empty());CHECK(s.loadSession().clean_shutdown);
        SessionSnapshot allPrivate{{{"javascript:bad","not inspected",true}},0,false};s.saveSession(allPrivate);CHECK(s.loadSession().tabs.empty());
    });
    test("invalid session leaves prior snapshot intact",[]{
        Storage s(":memory:");s.saveSession({{{"https://good.test","good",false}},0,false});
        throws([&]{s.saveSession({{{"https://new.test","new",false},{"javascript:1","bad",false}},0,true});});
        CHECK(s.loadSession().tabs[0].url=="https://good.test/");CHECK(!s.loadSession().clean_shutdown);
        throws([&]{s.saveSession({{{"https://a.test","a",false}},1,true});});
        SessionSnapshot huge;huge.tabs.resize(201);throws([&]{s.saveSession(huge);});
        throws([&]{s.saveSession({{},1,true});});
    });
    test("disk persistence and crash recovery",[]{
        TempDb file;
        {Storage s(file.str());s.recordVisit("https://a.test","a",1);s.addBookmark("https://b.test","b",2);s.setSetting("theme","dark");s.saveSession({{{"https://c.test","c",false}},0,false});}
        {Storage s(file.str());CHECK(s.history().size()==1);CHECK(s.bookmarks().size()==1);CHECK(s.setting("theme")=="dark");CHECK(!s.loadSession().clean_shutdown);CHECK(s.loadSession().tabs[0].url=="https://c.test/");s.markSessionClean(true);}
        {Storage s(file.str());CHECK(s.loadSession().clean_shutdown);CHECK(s.integrityCheck()=="ok");}
    });
    test("session transaction rollback on SQLite failure",[]{
        TempDb file;Storage s(file.str());s.saveSession({{{"https://original.test","original",false}},0,false});
        raw(file.str(),"CREATE TRIGGER reject_tab BEFORE INSERT ON session_tabs WHEN NEW.url='https://fail.test/' BEGIN SELECT RAISE(ABORT,'injected failure'); END;");
        throws<StorageError>([&]{s.saveSession({{{"https://new.test","new",false},{"https://fail.test","fail",false}},0,true});});
        auto snap=s.loadSession();CHECK(snap.tabs.size()==1);CHECK(snap.tabs[0].url=="https://original.test/");CHECK(!snap.clean_shutdown);
        raw(file.str(),"DROP TRIGGER reject_tab;");s.saveSession({{{"https://ok.test","ok",false}},0,true});CHECK(s.loadSession().tabs[0].url=="https://ok.test/");
    });
    test("clear data transactions and bookmark option",[]{
        TempDb file;Storage s(file.str());s.recordVisit("https://a.test","a",1);s.addBookmark("https://b.test","b",1);s.setSetting("a","b");s.saveSession({{{"https://a.test","a",false}},0,false});
        raw(file.str(),"CREATE TRIGGER reject_clear BEFORE DELETE ON bookmarks BEGIN SELECT RAISE(ABORT,'injected failure'); END;");
        throws<StorageError>([&]{s.clearBrowsingData(true);});CHECK(s.history().size()==1);CHECK(s.setting("a")=="b");CHECK(s.loadSession().tabs.size()==1);
        raw(file.str(),"DROP TRIGGER reject_clear;");s.clearBrowsingData();CHECK(s.history().empty());CHECK(!s.setting("a"));CHECK(s.loadSession().tabs.empty());CHECK(s.bookmarks().size()==1);
        s.clearBrowsingData(true);CHECK(s.bookmarks().empty());CHECK(s.integrityCheck()=="ok");
    });
    test("thread safe shared connection",[]{
        Storage s(":memory:");std::atomic<int> errors=0;std::vector<std::thread> workers;
        for(int i=0;i<4;++i) workers.emplace_back([&]{try{for(int j=0;j<25;++j)s.recordVisit("https://thread.test","thread",100);}catch(...){++errors;}});
        for(auto& w:workers) { w.join(); }
        CHECK(errors==0);CHECK(s.history().size()==1);CHECK(s.history()[0].visit_count==100);
    });
    test("schema ownership version and corrupt input",[]{
        {TempDb f;raw(f.str(),"PRAGMA user_version=2;");throws<StorageError>([&]{Storage s(f.str());});}
        {TempDb f;raw(f.str(),"PRAGMA application_id=123;");throws<StorageError>([&]{Storage s(f.str());});}
        {TempDb f;raw(f.str(),"CREATE TABLE unrelated(x);");throws<StorageError>([&]{Storage s(f.str());});}
        {TempDb f;raw(f.str(),"PRAGMA user_version=1;");throws<StorageError>([&]{Storage s(f.str());});}
        throws([&]{Storage s("");});
        TempDb f;Storage s(f.str());s.saveSession({{{"https://safe.test","safe",false}},0,true});
        raw(f.str(),"UPDATE session_tabs SET url='javascript:alert(1)';");throws<StorageError>([&]{(void)s.loadSession();});
        s.clearSession();CHECK(s.loadSession().tabs.empty());
    });
    test("history deletion is scoped by host boundary and inclusive time",[]{
        Storage db(":memory:");
        db.recordVisit("https://youtube.com/a","a",100);
        db.recordVisit("https://m.youtube.com/b","b",200);
        db.recordVisit("https://notyoutube.com/c","c",200);
        db.recordVisit("https://youtube.com.evil.test/d","d",200);
        db.recordVisit("https://youtube.com/old","old",99);
        db.addBookmark("https://youtube.com/a","keep",200);
        db.saveSession({{{"https://youtube.com/a","keep",false}},0,true});
        CHECK(db.countHistory(100,200,"YouTube.COM.")==2);
        CHECK(db.eraseHistory(100,200,"youtube.com")==2);
        CHECK(db.history().size()==3);
        CHECK(db.bookmarks().size()==1);CHECK(db.loadSession().tabs.size()==1);
        CHECK(db.eraseHistory(200,200)==2);CHECK(db.history().size()==1);
        CHECK(db.eraseHistoryEntry(db.history()[0].id));CHECK(!db.eraseHistoryEntry(-1));
        CHECK(db.history().empty());CHECK(db.integrityCheck()=="ok");
    });
    test("invalid history filters never delete records",[]{
        Storage db(":memory:");db.recordVisit("https://safe.test","safe",1);
        for(auto host:{"%","*.test","https://safe.test","safe.test/","a..test","-a.test","a-.test","a' OR 1=1--"})
            throws([&]{db.eraseHistory(0,2,host);});
        throws([&]{db.eraseHistory(2,1);});throws([&]{db.countHistory(-1,2);});
        CHECK(db.history().size()==1);
    });
    std::cout<<"RESULT: "<<passed<<" passed, "<<failed<<" failed, "<<assertions<<" assertions\n";
    return failed?1:0;
}
