#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/../.." && pwd)
cd "$root/rust/adblock"
cargo test --locked
cargo build --locked
# Linux native ABI and C/C++ header/link verification. Windows instructions: docs/ADBLOCK.md.
if [[ $(uname -s) == Linux ]]; then
  target=${CARGO_TARGET_DIR:-target}
  cc -std=c11 -Wall -Wextra -Werror -I"$root/include" "$root/tests/adblock/smoke.c" \
    "$target/debug/libshield_adblock.a" -ldl -lpthread -lm -lrt -lutil -o "$target/debug/adblock-smoke-c"
  "$target/debug/adblock-smoke-c"
  c++ -x c++ -std=c++17 -Wall -Wextra -Werror -I"$root/include" -c \
    "$root/tests/adblock/smoke.c" -o "$target/debug/adblock-smoke-cpp.o"
  c++ "$target/debug/adblock-smoke-cpp.o" "$target/debug/libshield_adblock.a" \
    -ldl -lpthread -lm -lrt -lutil -o "$target/debug/adblock-smoke-cpp"
  "$target/debug/adblock-smoke-cpp"
  echo "C11 and C++17 static-library ABI smoke tests passed"
fi
