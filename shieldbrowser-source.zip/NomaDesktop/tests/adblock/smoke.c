/* SPDX-License-Identifier: MPL-2.0 */
#include "shield/adblock.h"
#include <assert.h>
#include <string.h>
static uint32_t check(ShieldAdblockEngine *e, const char *url) {
  uint32_t flags = 999;
  const char *source = "https://news.example/";
  assert(shield_adblock_check(e, (const uint8_t *)url, strlen(url),
      (const uint8_t *)source, strlen(source), SHIELD_ADBLOCK_SCRIPT,
      &flags) == SHIELD_ADBLOCK_OK);
  return flags;
}
int main(void) {
  const char rules[] = "||ads.example^\n@@||ads.example/allow.js$script\n";
  ShieldAdblockEngine *e = NULL;
  assert(shield_adblock_create((const uint8_t *)rules, strlen(rules), &e) == SHIELD_ADBLOCK_OK);
  assert(check(e, "https://ads.example/ad.js") == SHIELD_ADBLOCK_BLOCK);
  assert(check(e, "https://ads.example/allow.js") == SHIELD_ADBLOCK_EXCEPTION);
  assert(check(e, "https://news.example/main.js") == 0);
  uint32_t flags = 999;
  assert(shield_adblock_check(e, (const uint8_t *)"https://", 8,
      NULL, 0, SHIELD_ADBLOCK_OTHER, &flags) == SHIELD_ADBLOCK_INVALID_URL);
  assert(flags == 0);
  assert(shield_adblock_destroy(e) == SHIELD_ADBLOCK_OK);
  assert(shield_adblock_destroy(NULL) == SHIELD_ADBLOCK_OK);
  return 0;
}
