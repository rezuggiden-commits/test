// SPDX-License-Identifier: MPL-2.0
use shield_adblock::*;
use std::ptr;
const RULES: &str = "! Local deterministic list\n||ads.example^\n@@||ads.example/allowed.js$script\n||tracker.example^$third-party\n||images.example^$image\n||scoped.example^$domain=news.example\n||critical.example^$important\n@@||critical.example^\nexample.com##.ad\nexample.com##+js(set, foo, bar)\n";
struct Handle(*mut ShieldAdblockEngine);
impl Handle {
    fn new(rules: &[u8]) -> Self {
        let mut h = ptr::null_mut();
        assert_eq!(
            unsafe { shield_adblock_create(rules.as_ptr(), rules.len(), &mut h) },
            OK
        );
        assert!(!h.is_null());
        Self(h)
    }
    fn check(&self, url: &[u8], source: &[u8], kind: u32) -> (i32, u32) {
        let mut flags = 99;
        let status = unsafe {
            shield_adblock_check(
                self.0,
                url.as_ptr(),
                url.len(),
                source.as_ptr(),
                source.len(),
                kind,
                &mut flags,
            )
        };
        (status, flags)
    }
}
impl Drop for Handle {
    fn drop(&mut self) {
        assert_eq!(unsafe { shield_adblock_destroy(self.0) }, OK);
    }
}

#[test]
fn blocks_allows_and_honors_exception() {
    let h = Handle::new(RULES.as_bytes());
    assert_eq!(
        h.check(
            b"https://ads.example/banner.js",
            b"https://news.example/",
            3
        ),
        (OK, BLOCK)
    );
    assert_eq!(
        h.check(
            b"https://ads.example/allowed.js",
            b"https://news.example/",
            3
        ),
        (OK, EXCEPTION)
    );
    assert_eq!(
        h.check(
            b"https://ads.example/allowed.js",
            b"https://news.example/",
            4
        ),
        (OK, BLOCK)
    );
    assert_eq!(
        h.check(
            b"https://content.example/main.js",
            b"https://news.example/",
            3
        ),
        (OK, 0)
    );
}
#[test]
fn source_domain_and_resource_type_are_used() {
    let h = Handle::new(RULES.as_bytes());
    assert_eq!(
        h.check(
            b"https://tracker.example/pixel",
            b"https://news.example/",
            4
        ),
        (OK, BLOCK)
    );
    assert_eq!(
        h.check(
            b"https://tracker.example/pixel",
            b"https://tracker.example/",
            4
        ),
        (OK, 0)
    );
    assert_eq!(h.check(b"https://images.example/ad", b"", 4), (OK, BLOCK));
    assert_eq!(h.check(b"https://images.example/ad", b"", 3), (OK, 0));
    assert_eq!(
        h.check(b"https://scoped.example/ad", b"https://news.example/", 3),
        (OK, BLOCK)
    );
    assert_eq!(
        h.check(b"https://scoped.example/ad", b"https://other.example/", 3),
        (OK, 0)
    );
}
#[test]
fn important_keeps_upstream_precedence() {
    let h = Handle::new(RULES.as_bytes());
    assert_eq!(
        h.check(b"https://critical.example/ad", b"https://news.example/", 3),
        (OK, BLOCK)
    );
}
#[test]
fn malformed_inputs_and_outputs() {
    let h = Handle::new(RULES.as_bytes());
    for u in [b"".as_slice(), b"not a URL", b"https://"] {
        assert_eq!(h.check(u, b"", 0), (INVALID_URL, 0));
    }
    assert_eq!(
        h.check(b"https://example.com/", b"not a URL", 0),
        (INVALID_URL, 0)
    );
    assert_eq!(h.check(&[0xff], b"", 0), (INVALID_UTF8, 0));
    assert_eq!(
        h.check(b"https://example.com/\0", b"", 0),
        (INVALID_ARGUMENT, 0)
    );
    assert_eq!(
        h.check(b"https://example.com/", b"", 99),
        (INVALID_ARGUMENT, 0)
    );
    let mut flags = 99;
    unsafe {
        assert_eq!(
            shield_adblock_check(ptr::null(), ptr::null(), 0, ptr::null(), 0, 0, &mut flags),
            INVALID_ARGUMENT
        );
        assert_eq!(flags, 0);
        assert_eq!(
            shield_adblock_check(h.0, ptr::null(), 1, ptr::null(), 0, 0, &mut flags),
            INVALID_ARGUMENT
        );
        assert_eq!(
            shield_adblock_check(h.0, ptr::null(), 65537, ptr::null(), 0, 0, &mut flags),
            INVALID_ARGUMENT
        );
        assert_eq!(
            shield_adblock_check(h.0, ptr::null(), 0, ptr::null(), 0, 0, ptr::null_mut()),
            INVALID_ARGUMENT
        );
        assert_eq!(
            shield_adblock_create(ptr::null(), 0, ptr::null_mut()),
            INVALID_ARGUMENT
        );
        let mut out = h.0;
        assert_eq!(
            shield_adblock_create([0xff].as_ptr(), 1, &mut out),
            INVALID_UTF8
        );
        assert!(out.is_null());
        assert_eq!(
            shield_adblock_create(ptr::null(), 1, &mut out),
            INVALID_ARGUMENT
        );
        assert!(out.is_null());
        assert_eq!(
            shield_adblock_create(ptr::null(), 32 * 1024 * 1024 + 1, &mut out),
            INVALID_ARGUMENT
        );
        assert_eq!(
            shield_adblock_create([b'a', b'b', b'c', 0].as_ptr(), 4, &mut out),
            INVALID_ARGUMENT
        );
        assert_eq!(shield_adblock_destroy(ptr::null_mut()), OK);
    }
}
#[test]
fn empty_list_and_malformed_rules_are_tolerated() {
    let h = Handle::new(
        b"! comment\n||broken.example^$not-a-real-option\nexample.com##+js(alert, x)\n",
    );
    assert_eq!(h.check(b"https://broken.example/", b"", 0), (OK, 0));
    let mut out = ptr::null_mut();
    unsafe {
        assert_eq!(shield_adblock_create(ptr::null(), 0, &mut out), OK);
        assert_eq!(shield_adblock_destroy(out), OK);
    }
}
#[test]
fn concurrent_checks_on_live_engine() {
    let h = Handle::new(RULES.as_bytes());
    // Share a Rust reference to the opaque object, not a concurrently destroyed raw pointer.
    let engine = unsafe { &*h.0 };
    std::thread::scope(|scope| {
        for _ in 0..8 {
            scope.spawn(move || {
                for _ in 0..50 {
                    let mut flags = 0;
                    let u = b"https://ads.example/ad.js";
                    assert_eq!(
                        unsafe {
                            shield_adblock_check(
                                engine,
                                u.as_ptr(),
                                u.len(),
                                ptr::null(),
                                0,
                                3,
                                &mut flags,
                            )
                        },
                        OK
                    );
                    assert_eq!(flags, BLOCK);
                }
            });
        }
    });
}
