# SQLite amalgamation pin

- Version: **3.50.4**, release 2025-07-30 (not an assertion that this is the newest release).
- Official upstream download: https://www.sqlite.org/2025/sqlite-amalgamation-3500400.zip
- Official release/hash source: https://www.sqlite.org/releaselog/3_50_4.html
- `SQLITE_SOURCE_ID`: `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`
- Official **SHA3-256 of sqlite3.c**: `9145255e83da6529e70121ee4d7a4c88fe83ca4511da0c9ed13d10842df36782`
- Downloaded ZIP **SHA-256** (locally measured, not an upstream-published checksum): `1d3049dd0f830a025a53105fc79fd2ab9431aea99e137809d064d8ee8356b032`

`sqlite3.c`, `sqlite3.h`, and `sqlite3ext.h` were extracted unmodified from that official archive. Python `hashlib.sha3_256` matched sqlite3.c against the hash on the official release page before files were written into the project. The unit tests also check the linked library's version, source ID, threadsafety and omitted extension loading.

Recheck the published file hash locally:

```sh
python3 -c "import hashlib,pathlib; p=pathlib.Path('third_party/sqlite/sqlite3.c'); expected='9145255e83da6529e70121ee4d7a4c88fe83ca4511da0c9ed13d10842df36782'; actual=hashlib.sha3_256(p.read_bytes()).hexdigest(); print(actual); assert actual == expected"
```

## License

SQLite is public domain. The source file headers contain its public-domain dedication; see https://www.sqlite.org/copyright.html. This project does not modify the upstream license or source headers.

## Build policy

Compile the amalgamation as **C**, not C++. The core target uses `SQLITE_THREADSAFE=1`, `SQLITE_DQS=0`, and `SQLITE_OMIT_LOAD_EXTENSION=1`. No dynamically loaded SQLite extensions are enabled. No system SQLite dependency or network fetch at configure/build time is required. Reassess upstream security and compatibility fixes when updating this pin; version pinning and checksum verification are provenance controls, not a vulnerability audit.
