; Compile ONLY through tools/package.ps1: tests and stage integrity are checked there.
#ifndef StageDir
  #error StageDir is required; run tools/package.ps1
#endif
#ifndef OutputDir
  #error OutputDir is required
#endif
#ifndef AppVersion
  #error AppVersion is required
#endif
[Setup]
AppId={{98824AA2-5FD4-419E-9F1F-51E9CD38DB4B}
AppName=Noma
AppVersion={#AppVersion}
AppPublisher=Noma Project
DefaultDirName={localappdata}\Programs\Noma
DefaultGroupName=Noma
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
OutputDir={#OutputDir}
OutputBaseFilename=Noma-{#AppVersion}-windows-x64-unsigned
AppMutex=NomaDesktopAppMutex
ChangesAssociations=yes
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\Noma.exe
CloseApplications=yes
RestartApplications=no
SetupLogging=yes
VersionInfoDescription=Noma Browser

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Noma"; Filename: "{app}\Noma.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\Noma"; Filename: "{app}\Noma.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\RegisteredApplications"; ValueType: string; ValueName: "Noma"; ValueData: "Software\Noma\Capabilities"; Flags: uninsdeletevalue
Root: HKCU; Subkey: "Software\Noma\Capabilities"; ValueType: string; ValueName: "ApplicationName"; ValueData: "Noma"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Noma\Capabilities"; ValueType: string; ValueName: "ApplicationDescription"; ValueData: "Noma web browser"
Root: HKCU; Subkey: "Software\Noma\Capabilities\URLAssociations"; ValueType: string; ValueName: "http"; ValueData: "NomaURL"
Root: HKCU; Subkey: "Software\Noma\Capabilities\URLAssociations"; ValueType: string; ValueName: "https"; ValueData: "NomaURL"
Root: HKCU; Subkey: "Software\Classes\NomaURL"; ValueType: string; ValueData: "Noma URL"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\NomaURL"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""
Root: HKCU; Subkey: "Software\Classes\NomaURL\DefaultIcon"; ValueType: string; ValueData: "{app}\Noma.exe,0"
Root: HKCU; Subkey: "Software\Classes\NomaURL\shell\open\command"; ValueType: string; ValueData: """{app}\Noma.exe"" ""%1"""

[Run]
Filename: "{app}\Noma.exe"; Description: "Launch Noma"; Flags: nowait postinstall skipifsilent

[Code]
// Profile data is deliberately NOT in [UninstallDelete]. Normal/silent uninstall
// preserves it. Only an explicit interactive confirmation deletes the fixed leaf.
function GetFileAttributes(const FileName: String): LongWord;
  external 'GetFileAttributesW@kernel32.dll stdcall';

function HasReparsePoint(const Path: String): Boolean;
var
  Attributes: LongWord;
begin
  Attributes := GetFileAttributes(Path);
  Result := (Attributes <> $FFFFFFFF) and ((Attributes and $400) <> 0);
end;

function TreeIsPlain(const Path: String): Boolean;
var
  Entry: TFindRec;
  Child: String;
begin
  Result := False;
  if HasReparsePoint(Path) then exit;
  if FindFirst(Path + '\*', Entry) then begin
    try
      repeat
        if (Entry.Name <> '.') and (Entry.Name <> '..') then begin
          if (Entry.Attributes and $400) <> 0 then exit;
          if (Entry.Attributes and $10) <> 0 then begin
            Child := Path + '\' + Entry.Name;
            if not TreeIsPlain(Child) then exit;
          end;
        end;
      until not FindNext(Entry);
    finally
      FindClose(Entry);
    end;
  end else exit;
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  ParentPath, ProfilePath: String;
begin
  if (CurUninstallStep <> usPostUninstall) or UninstallSilent then exit;
  ParentPath := ExpandConstant('{localappdata}\Noma\Desktop');
  ProfilePath := ParentPath + '\User Data';
  if not DirExists(ProfilePath) then exit;
  if MsgBox('Keep your browsing profile? Select Yes to KEEP it (recommended). Select No to permanently delete Noma history, cookies and settings.', mbConfirmation, MB_YESNO or MB_DEFBUTTON1) = IDYES then exit;
  // Refuse deletion through redirected parent/profile junctions. Never delete
  // localappdata, its Noma parent, another app, or a command-line path.
  if HasReparsePoint(ExpandConstant('{localappdata}')) or
     HasReparsePoint(ExpandConstant('{localappdata}\Noma')) or
     HasReparsePoint(ParentPath) or not TreeIsPlain(ProfilePath) then begin
    MsgBox('Profile deletion refused because the path is redirected. The profile was preserved.', mbInformation, MB_OK);
    exit;
  end;
  if MsgBox('Permanently delete only ' + ProfilePath + '? This cannot be undone.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) <> IDYES then exit;
  if not DelTree(ProfilePath, True, True, True) then
    MsgBox('Some profile files could not be removed. Close Noma and remove them manually if desired.', mbInformation, MB_OK);
end;
