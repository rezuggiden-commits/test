# Stability work after validation run 73

These changes are not a declaration that release gates have passed.

## Session startup

- Read the saved snapshot before allowing the startup page to save over it.
- Preserve the order and selected index of home and web tabs.
- Validate every restored address; never turn a stored text string into a search.
- Background tabs remain uncreated until selected. Restore is bounded.
- An unclean shutdown requires an explicit restore decision, default No. Declining
  starts a new session without sending requests to the previous sites.
- A delayed worker reply must not replace tabs the user already opened or changed.
- A failed snapshot read preserves the previous database session instead of saving
  the empty startup page over it.

## Renderer recovery

- An unexpected renderer termination produces Noma's own error page, with a retry
  link to the original HTTP(S) address. There is no infinite auto-reload loop.
- Failure of the error page's renderer is not retried automatically.
- Navigation requested while the browser child is still being created is retained.
- CI deliberately crashes a loopback renderer through DevTools Page.crash and
  requires the same tab to load the loopback site again. No remote debugging port.

## Media permission lifecycle

- Supported requests explicitly list microphone and/or camera, not an opaque set
  of capabilities. Only HTTPS and HTTP loopback are eligible.
- Screen/audio desktop capture is denied until a real source picker is implemented.
- A navigation of the requesting frame or top-level page cancels pending requests.
  Unrelated iframe navigation does not cancel an otherwise valid request.
- Closure, renderer termination and prompt destruction cancel unresolved requests.
  Late responses cannot approve a request removed from the pending map.
- This is one-request permission handling, not a complete persisted site-permission
  manager, revocation UI, device compatibility certification or screen-sharing UI.

## Evidence

Core session planning has three regression scenarios in tests/unit/core_tests.cpp.
Run 39703391165 passed the induced renderer-crash recovery and three session startup
cases (clean restore, crash restore accepted, crash restore declined). Media-permission
lifecycle changes have a separate real-prompt CI scenario with a fake audio device;
that scenario has not yet been validated at this document revision. Results must
come from the exact corresponding Windows run, not from an earlier build.
