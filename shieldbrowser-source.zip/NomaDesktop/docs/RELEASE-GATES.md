# Release gates (not passed)

- [x] Source implementation of own native C++ tab strip and browser controls.
- [x] Linux core regression suite: 20 scenarios / 206 assertions.
- [x] Windows compilation and own-UI smoke: GitHub Actions run 39691990764,
      native stage passed; that overall run failed at installer compiler detection.
- [x] Loopback managed-popup proof: real user-gesture popup, live opener, origin/source
      validation and shared cookie, run 39691990764. This is not real Google sign-in.
- [ ] Extension architecture: CEF Alloy does not provide Chrome's complete extension platform.
      Do not claim Web Store compatibility. Do not solve this by showing stock Chrome UI.
- [ ] End-to-end Google sign-in with an authorized human, persistence across restart.
- [ ] Windows 10 / 11 installation, uninstall, upgrade, profile migration, crash recovery.
- [ ] Sustained performance / memory / page-load measurements, user-network reproduction.
- [ ] Permission lifecycle and capability coverage beyond camera/microphone request prompts.
- [x] Windows loopback download pause/resume and completion after closing its tab,
      with payload checksum, run 39691990764.
- [ ] Download persistence across restart, interrupted-transfer recovery and complete
      dangerous-download protection (an explicit open warning is not malware scanning).
- [ ] Release signing, an authenticated update channel, rollback and a browser security patch policy.
- [ ] Dependency/license audit for the shipped distribution and secure packaging.

No VPN/AI. No certificate bypass, anti-CAPTCHA bypass, stolen browser credentials,
Chrome Sync impersonation, or automatic fallback to an unknown public proxy.
History is aggregated per URL; time filtering applies to the last visit, and UI
must say so. A site network refusal is not asserted to be fixed by a C++ migration.

CI stores validation evidence. An unsigned installer is retained only when the
whole validation job succeeds; it is not an approval for public release.
