# Release gates (not passed)

- [x] Source implementation of own native C++ tab strip and browser controls.
- [x] Linux core regression suite: 20 scenarios / 206 assertions.
- [x] Baseline Windows compilation and own-UI smoke: GitHub Actions run 39683772618.
      Later visual/isolated-theme changes require their own successful CI run.
- [ ] Correct managed OAuth popups with a live opener (current user links become tabs).
- [ ] Extension architecture: CEF Alloy does not provide Chrome's complete extension platform.
      Do not claim Web Store compatibility. Do not solve this by showing stock Chrome UI.
- [ ] End-to-end Google sign-in with an authorized human, persistence across restart.
- [ ] Windows 10 / 11 installation, uninstall, upgrade, profile migration, crash recovery.
- [ ] Sustained performance / memory / page-load measurements, user-network reproduction.
- [ ] Permission lifecycle and capability coverage beyond camera/microphone request prompts.
- [ ] Download pause/resume/recovery, metadata persistence and dangerous download handling.
- [ ] Release signing, an authenticated update channel, rollback and a browser security patch policy.
- [ ] Dependency/license audit for the shipped distribution and secure packaging.

No VPN/AI. No certificate bypass, anti-CAPTCHA bypass, stolen browser credentials,
Chrome Sync impersonation, or automatic fallback to an unknown public proxy.
History is aggregated per URL; time filtering applies to the last visit, and UI
must say so. A site network refusal is not asserted to be fixed by a C++ migration.

CI stores test evidence only, never an automatic public release/candidate ZIP.
