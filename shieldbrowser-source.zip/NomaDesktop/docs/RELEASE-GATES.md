# Release gates (not passed)

- [x] Source implementation of own native C++ tab strip and browser controls.
- [x] Linux core regression suite: 23 scenarios / 222 assertions (local current source).
- [x] Windows compilation and own-UI smoke: GitHub Actions run 39703391165, all validation stages passed. This is not public release approval.
- [x] Loopback managed-popup proof: real user-gesture popup, live opener, origin/source
      validation and shared cookie, run 39703391165. This is not real Google sign-in.
- [ ] Extension architecture: CEF Alloy does not provide Chrome's complete extension platform.
      Do not claim Web Store compatibility. Do not solve this by showing stock Chrome UI.
- [ ] End-to-end Google sign-in with an authorized human, persistence across restart.
- [x] Windows hosted-runner installation/uninstall, same-version reinstall, profile/cookie
      preservation, clean/unclean session restore and induced renderer-crash recovery, run 39703391165.
- [ ] Consumer Windows 10 / 11 qualification and historical-version profile migration.
- [ ] Sustained performance / memory / page-load measurements, user-network reproduction.
- [ ] Permission lifecycle and capability coverage beyond camera/microphone request prompts.
- [x] Windows loopback download pause/resume and completion after closing its tab,
      with payload checksum, run 39703391165.
- [x] Completed-download history across restart, run 39703391165.
- [ ] Interrupted-transfer recovery and complete dangerous-download protection
      (an explicit open warning is not malware scanning).
- [ ] Release signing, an authenticated update channel, rollback and a browser security patch policy.
- [ ] Dependency/license audit for the shipped distribution and secure packaging.

No VPN/AI. No certificate bypass, anti-CAPTCHA bypass, stolen browser credentials,
Chrome Sync impersonation, or automatic fallback to an unknown public proxy.
History is aggregated per URL; time filtering applies to the last visit, and UI
must say so. A site network refusal is not asserted to be fixed by a C++ migration.

CI stores validation evidence. An unsigned installer is retained only when the
whole validation job succeeds; it is not an approval for public release.
