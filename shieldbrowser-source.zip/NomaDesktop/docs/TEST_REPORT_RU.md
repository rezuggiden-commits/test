# Фактические проверки

Платформа: Linux x86_64, G++ 11.5.0, CMake 4.4.4, Rust 1.90.0.
Это не Windows runtime и не согласованная тестовая машина производительности.

| Проверка | Фактический результат |
| --- | --- |
| CMake/Ninja Debug core | Скомпилировано; CTest 1/1; внутри 18 сценариев, 182 assertions, 0 failures |
| CMake/Ninja Release core | См. core-release-ctest.log; отдельный оптимизированный прогон |
| Core strict warnings и ASan/UBSan | PASS; команды и границы покрытия в CORE_TEST_RESULTS.md |
| Rust debug/release | 4 unit + 6 integration = 10 PASS; cargo-tests.log |
| C11/C++17 ABI | Линковка и запуск PASS; adblock-abi-smoke.log |
| Rust MSVC x64 cross-build | shield_adblock.lib создан; Windows-исполнение НЕ проверялось |
| PowerShell parser/helper guards | PASS в Linux PowerShell; не Windows build/install |
| CEF archive | 359239395 bytes; SHA1/SHA256 совпадают с зафиксированными значениями |
| Windows configure на Linux | Ожидаемый явный отказ; windows-build-blocker.log |
| Qt/CEF GUI compile, tabs, сайты | НЕ ЗАПУСКАЛОСЬ |
| Cookie/cache completion, private disk footprint | НЕ ПРОВЕРЯЛОСЬ |
| CEF shutdown, native tab teardown, permissions, downloads | НЕ ПРОВЕРЯЛОСЬ в runtime |
| HTTP filter-update success/error against CEF | НЕ ПРОВЕРЯЛОСЬ; ABI rules отдельно проверены |
| Signed updater, checksum/signature rejection | НЕ РЕАЛИЗОВАНО; тестов нет |
| Installer, clean Windows, portable launch | НЕ СОЗДАНО / НЕ ПРОВЕРЕНО |
| Startup/tab latency, memory/resource leaks | НЕ ИЗМЕРЯЛОСЬ |

Нельзя трактовать CTest PASS как выполнение всех 15 интеграционных пунктов ТЗ.
Архив содержит исходники и фактические логи, а не готовый коммерческий продукт.
