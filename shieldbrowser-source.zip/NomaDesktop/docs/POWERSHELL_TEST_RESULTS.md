# PowerShell source/helper test results

Executed on Linux at **2026-10-21T00:57:17Z**, after the CMake minimum-version
check was raised to 3.25 and deployment license-copy changes were present.

## Environment and actual commands

The locally downloaded PowerShell binary is **`/data/pwsh/pwsh`**. This is a
sandbox validation tool, not a project dependency or Windows release artifact.
It was obtained from the official PowerShell GitHub release asset
`powershell-7.4.6-linux-x64.tar.gz` and extracted to `/data/pwsh`.

```sh
/data/pwsh/pwsh -NoProfile -Command '$PSVersionTable.PSVersion.ToString()'
/data/pwsh/pwsh -NoProfile -File /data/ShieldBrowser/tools/tests/guards.ps1
```

Actual output:

```text
7.4.6
PASS syntax, missing/empty/stale test-evidence guards, and manifest coverage.
```

Both commands completed successfully with exit code **0**.

## What passed

- PowerShell parser inspection of every `.ps1` file under `tools/`, recursively.
- Missing test evidence is rejected.
- An empty test suite is rejected.
- Matching nonempty Release test evidence is accepted against a synthetic fixture.
- A DLL fixture modified after test evidence was recorded is rejected.
- Root `stage-manifest.json` is excluded from its own file inventory, while a
  nested file with that same name is included.

The helper checks use temporary fake fixture files. They do **not** execute or
validate a real Windows application DLL.

## Read-only confirmation of latest application changes

The latest `src/ui/main_window.cpp` was inspected without modification:

- The `completed` connection consumes its `pageTitle` parameter for history.
- `compileRules` checks `compilingRules_` before starting another compilation.

These observations are static review, not GUI or concurrency test results.

## Explicit limitations

This run does **not** establish Windows PowerShell 5.1 compatibility, Windows
prerequisite detection, successful dependency installation, Windows compilation or
linking, runtime deployment completeness, Inno installer compilation/execution,
Qt/CEF GUI behavior, sandbox enforcement, or native-window shutdown correctness.
`check.ps1`, `configure.ps1`, `build.ps1`, `test.ps1`, `deploy.ps1` and `package.ps1`
were syntax-parsed, not run through their real Windows workflows. In particular,
the revised license-copy commands and CMake version check were not functionally
executed on Windows. No application files were edited during this final check.
