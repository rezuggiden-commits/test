# Shield network adblocking bridge

This is an actual native integration of Brave's **adblock-rust 0.13.3**, not a handwritten substring blocker. The Rust crate builds `shield_adblock` as a static library and exposes three C ABI entry points in `include/shield/adblock.h`.

## Verified upstream API and provenance

The implementation was checked against the published crate source, fetched directly from the official Rust crate CDN:

- Repository: https://github.com/brave/adblock-rust
- Published source archive: https://static.crates.io/crates/adblock/adblock-0.13.3.crate
- Version-specific reference: https://docs.rs/adblock/0.13.3/adblock/
- Engine: https://docs.rs/adblock/0.13.3/adblock/engine/struct.Engine.html
- Request: https://docs.rs/adblock/0.13.3/adblock/request/struct.Request.html
- FilterSet: https://docs.rs/adblock/0.13.3/adblock/lists/struct.FilterSet.html
- Matching result: https://docs.rs/adblock/0.13.3/adblock/blocker/struct.BlockerResult.html

Archive SHA-256: `f44b96a666a23c12acad7c688bfe8638a7094e7eabe765b09a6864ab991c676d` (also recorded by Cargo.lock). The crates.io website/API was inaccessible in this environment; the official static CDN, sparse Cargo registry, docs.rs, and Brave GitHub source were reachable.

The precise APIs used are `FilterSet::new(false)`, `FilterSet::add_filter_list(String, ParseOptions)`, `RuleTypes::NetworkOnly`, `Engine::new_with_filter_set`, `Request::new(url, source_url, resource_type, method)`, and `Engine::check_network_request`. Final blocking uses **`BlockerResult::should_block()`**, not merely presence of a filter: this preserves exceptions and `$important` precedence. Exception indication comes from `result.exception.is_some()`.

`single-thread` defaults are disabled. Only `embedded-domain-resolver` and `full-regex-handling` are enabled. No external domain resolver is needed. Compile-time tests enforce `Send + Sync` for the wrapper, and a wrapper mutex serializes checks.

## ABI v1

```c
int32_t shield_adblock_create(const uint8_t *rules, size_t rules_len,
                             ShieldAdblockEngine **out_engine);
int32_t shield_adblock_check(const ShieldAdblockEngine *engine,
                            const uint8_t *url, size_t url_len,
                            const uint8_t *source, size_t source_len,
                            uint32_t resource_type, uint32_t *out_flags);
int32_t shield_adblock_destroy(ShieldAdblockEngine *engine);
```

All entry points use the platform C calling convention (`extern "C"`; default cdecl for Windows). Parameter/result integer widths are explicit; `size_t` matches Rust `usize` and the host architecture. The resource parameter is `uint32_t`, **not** a compiler-dependent C enum argument. No Rust types, allocator-owned strings, Rust `bool`, or Rust enum representations cross the ABI. The opaque object is only freed by `destroy`; never use C/C++ `free`/`delete` on it.

| Status | Value | Meaning |
| --- | --- | --- |
| `SHIELD_ADBLOCK_OK` | 0 | Output valid |
| `SHIELD_ADBLOCK_INVALID_ARGUMENT` | 1 | Null required pointer, invalid span, excessive length, embedded NUL, unknown resource type |
| `SHIELD_ADBLOCK_INVALID_UTF8` | 2 | Rules or URL/source not valid UTF-8 |
| `SHIELD_ADBLOCK_INVALID_URL` | 3 | Target or nonempty source rejected by upstream request parser |
| `SHIELD_ADBLOCK_PANIC` | 4 | Caught Rust unwind panic or poisoned engine |

Flags on success: `SHIELD_ADBLOCK_BLOCK=1`, `SHIELD_ADBLOCK_EXCEPTION=2`; zero means no blocking decision. Always test the BLOCK **bit**, not equality. EXCEPTION is diagnostic, never an independent instruction overriding BLOCK. On error a non-null output is initialized to NULL/zero. **Status must be checked before interpreting flags.** Error flags of zero do not mean evaluation succeeded.

Resource mapping: OTHER=0, DOCUMENT=1, SUBDOCUMENT=2, SCRIPT=3, IMAGE=4, STYLESHEET=5, XHR=6, FONT=7, MEDIA=8, WEBSOCKET=9, PING=10, OBJECT=11, CSP=12. The bridge maps these to upstream's documented request-type strings. The caller maps CEF resource constants to these ABI constants; do not cast a CEF enum directly.

Input spans are raw UTF-8 bytes, without a terminating NUL. NULL with zero length is valid for rules and source; an empty target returns INVALID_URL. Limits: 32 MiB rules and 64 KiB for each URL/source. Invalid individual rule lines are deliberately ignored by upstream; success does not certify all rules were syntactically accepted. Empty rules produce a valid allow-all engine. The source should be the **initiating document URL**, not necessarily the HTTP Referer, so third-party/domain options are meaningful. Empty source means unknown (upstream treats it as third party). URL syntax/normalization follows upstream, not a new standards-compliance validator.

### Ownership, concurrency and errors

- Output locations must be aligned, writable, and non-aliasing with inputs/engine memory. Inputs remain readable and unchanged for the whole call. The bridge copies the rules; input storage may be released after return.
- Engine contents are immutable after creation. Concurrent calls to check on one live handle are supported but serialized by a mutex. Different engines can be checked independently. No callbacks or JavaScript are invoked.
- Destroy **must be exclusive**: stop new calls and wait for existing checks/pending users before destruction. Destroy NULL is OK; double destruction, invalid pointers, races with destroy, and use-after-free are undefined behavior. Use a C++ owner/shared lifetime mechanism or shutdown barrier.
- Every exported operation contains `catch_unwind` and release builds explicitly retain `panic="unwind"`. A panic while evaluating poisons the wrapper lock, making subsequent checks return PANIC. Retire and replace that engine. No Rust unwind propagates over the ABI.
- This is not process isolation: OOM aborts, explicit aborts, invalid pointers/hardware faults, or caller-built `panic=abort` cannot be caught. Do not override the panic profile to abort. Rust's panic hook may log a contained panic to stderr. A caught panic payload is deliberately forgotten, avoiding a second panic from its destructor at the cost of a leak only on the panic path.
- The browser decides fail-open/fail-closed behavior on nonzero status. Log errors rather than silently treating them as successful allow decisions.
- For list replacement, build a new handle first, swap it under the caller's lifetime lock, and retire the old one only after its last reader exits. No in-place rule mutations are exposed.

## Build and integration

Rust 1.90.0 is pinned in `rust-toolchain.toml`; all dependency versions/checksums are pinned in Cargo.lock. Do not omit `--locked` in CI. No root CMake files are changed by this component.

```sh
# Install user-local Rust from the official installer if not already present:
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o rustup-init.sh
sh rustup-init.sh -y --profile minimal --default-toolchain 1.90.0
export PATH="$HOME/.cargo/bin:$PATH"

cd rust/adblock
cargo build --locked --release
# Linux: target/release/libshield_adblock.a
```

Windows x64 (run from a VS Developer Command Prompt with the C++ toolset/Windows SDK):

```powershell
cd rust/adblock
rustup target add x86_64-pc-windows-msvc
cargo build --locked --release --target x86_64-pc-windows-msvc
# target/x86_64-pc-windows-msvc/release/shield_adblock.lib
# Print the toolchain's exact native library requirements:
cargo rustc --locked --release --target x86_64-pc-windows-msvc -- --print=native-static-libs
```

Include `include/shield/adblock.h` and link the `.lib` plus Rust's reported Windows system import libraries. The verified 1.90.0 x64 MSVC build reported `kernel32.lib ntdll.lib userenv.lib ws2_32.lib dbghelp.lib /defaultlib:msvcrt`. Match x64 MSVC CEF/application architecture; do not mix GNU and MSVC libraries. Rust's default MSVC CRT configuration is dynamic; match the application/toolchain CRT choice rather than globally forcing static CRT. Windows runtime/link validation with the actual CEF executable remains the caller's responsibility; a Linux cross-build alone cannot validate it.

CEF request interception should cancel only when status is OK and `flags & SHIELD_ADBLOCK_BLOCK` is nonzero. Pass request URL, actual initiating document URL when known, and mapped resource type. This library does not implement the CEF interception lifecycle.

## Reproducible tests

From the repository root:

```sh
export PATH="$HOME/.cargo/bin:$PATH"
tests/adblock/run.sh
```

The script runs locked Cargo tests/build, then on Linux compiles and links both C11 and C++17 clients against the actual static archive and runs them. All lists and URLs are deterministic local test fixtures; tests fetch no live filter lists. The initial dependency fetch/build requires registry access; after fetching, Cargo can also run with `--offline --locked`.

Coverage:

- Ordinary network block, unrelated allow, `@@` exception, resource-specific exception.
- Third-party vs same-site requests; `$domain` source scoping; image vs script type.
- `$important` precedence over an exception.
- Invalid URL/source, UTF-8, embedded NUL, unknown type, null handle/input/output, oversized spans; outputs reset on errors.
- Empty list, invalid filter options ignored safely, cosmetic/scriptlet rules not used.
- 400 checks across eight concurrent threads sharing one live engine.
- Injected unwind panic containment, including a panic payload with a panicking destructor; poison behavior; compile-time Send + Sync.
- C and C++ ABI smoke clients: block/allow/exception/malformed URL and destruction.

### Observed verification results (2026-10-21)

On Linux x86_64 with official Rust 1.90.0:

| Check | Result |
| --- | --- |
| `cargo test --locked` | PASS: 4 unit + 6 integration tests |
| `cargo test --locked --release` | PASS: same 10 tests with optimization/unwind profile |
| `cargo clippy --locked --all-targets -- -D warnings` | PASS |
| `cargo fmt --all -- --check` | PASS |
| Linux C11 and C++17 debug static-archive link/run | PASS, both clients |
| Linux C11 release static-archive link/run | PASS |
| `cargo rustc --locked --release --target x86_64-pc-windows-msvc -- --print=native-static-libs` | PASS: actual MSVC `.lib` emitted |
| Windows/CEF final executable link and runtime | NOT RUN: Windows toolchain/runtime and CEF process unavailable on this Linux host |

The Windows archive is `rust/adblock/target/x86_64-pc-windows-msvc/release/shield_adblock.lib`. Build artifacts under `target/` are ignored; rebuild using the locked commands above rather than treating local artifacts as source deliverables.

## Deliberate limitations and security boundaries

Only **network allow/block** is implemented. No cosmetic hiding, DOM selectors, scriptlets, injected/untrusted JavaScript, resource assets, JS callbacks, HTML/CSP mutation, URL rewriting/removeparam application, or redirect replacement bodies are exposed. Cosmetic/scriptlet rules are excluded with `RuleTypes::NetworkOnly`. No resource bundle is loaded. Redirect rules can still yield a network blocking decision, but replacement content is not served. No filter-list downloading, scheduling, signature validation, automatic updates, cache, serialization, or persistent settings are implemented.

The minimal ABI does not receive an HTTP method; upstream is called with an unspecified method (`""`), so `$method` rules are unsupported. Page-level allowlisting state is not tracked across requests; a document exception does not create a persistent tab allowlist in this wrapper. Browser policy for top-level navigations, privileged schemes, downloads, popup handling, service workers and protocol-specific interception is outside this library. Match behavior on non-HTTP(S)/WebSocket schemes follows upstream; the caller should bypass privileged/internal browser schemes explicitly.

Filter text is data, not JavaScript. Nevertheless, parsing/matching untrusted large or pathological regex lists can consume CPU and memory; the size cap is not a time or memory budget. Load trusted curated lists off the browser UI thread, restrict list sources and lifecycle, and consider worker/process isolation for adversarial lists. No claim of full Brave Browser feature parity is made.

## Licensing and redistribution

Brave adblock-rust 0.13.3 declares **MPL-2.0**; its license text is included at `rust/adblock/LICENSE-MPL-2.0`. The bridge/header/tests are also marked MPL-2.0. Preserve MPL notices, include the license in distributed packages, and make the MPL-covered source (including modifications) available to recipients as required by the MPL. MPL is file-level copyleft; static linking is not a substitute for satisfying covered-source obligations. This is implementation guidance, not legal advice.

Transitive Cargo dependencies have their own licenses: audit the **locked** dependency graph and ship required notices before redistribution. Cargo.lock pins versions but is not a complete license/notice bundle or a vulnerability audit. Downloaded filter lists are not included here and have separate licenses/attribution requirements that must be reviewed independently.
