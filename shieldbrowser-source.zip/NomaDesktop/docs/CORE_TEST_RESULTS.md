# Portable core: implementation and actual test results

Verified on **2026-10-21**, Linux x86_64 (kernel 6.18.49), GCC/G++ 11.5.0, CMake 4.4.4. **No Windows build, Qt/CEF integration run, MSVC verification, browser sandbox verification or UI test was performed.** These results cover the portable C++20 core only.

## Delivered interfaces

- `include/shield/core/navigation.h`, `src/core/navigation.cpp`: `shield::core::classifyNavigation`, `NavigationOptions`, `NavigationResult`, `isPersistableUrl`, `encodeQuery`.
- `include/shield/core/storage.h`, `src/core/storage.cpp`: `Storage`, `StorageError`, history, bookmarks, settings, session snapshots and privacy flags.
- `tests/unit/core_tests.cpp`: self-contained deterministic test runner, no third-party test framework; returns nonzero on any failure.
- `cmake/Core.cmake`: `shield_sqlite`, `shield_core` (alias `shield::core`), `shield_core_tests`, and CTest registration.
- `third_party/sqlite/`: official unmodified SQLite 3.50.4 amalgamation and provenance README. sqlite3.c's SHA3-256 was checked against the hash published in the official release notes before vendoring.

No main application, UI, root CMake, or Notion page changes were made by the core implementation task.

## Actual results

| Check | Result |
| --- | --- |
| Direct G++ release build, `-Wall -Wextra -Wpedantic -Werror` | Passed, no diagnostics |
| Direct test executable | **18 passed, 0 failed, 182 assertions**, exit 0 |
| Standalone CMake harness using `cmake/Core.cmake` | Configured and built successfully |
| CTest | **1/1 test passed**, exit 0; executable contains the 18 cases above |
| AddressSanitizer + UndefinedBehaviorSanitizer on the C++ sources/tests | **18 passed, 0 failed, 182 assertions**, exit 0, no sanitizer reports |
| SQLite `PRAGMA integrity_check` | `ok` in tested databases |
| Pinned dependency identity | Runtime version, source ID, thread safety and omitted extension loading verified |

The sanitizer build links the normal, uninstrumented SQLite C object. It instruments our C++ code and tests, **not SQLite's internal implementation**. This is not a complete fuzzing, penetration-testing or security-audit result.

Early strict compilation exposed misleading-indentation warnings and a GCC 11 string-view optimization warning; those were corrected before the passing builds. The first sanitizer launch failed because the environment lacks the expected sanitizer SONAME symlinks. Local build-directory symlinks to the compiler's installed runtime files resolved it; no system libraries were modified.

## Exact direct build and test commands

Run from `/data/ShieldBrowser`:

```sh
mkdir -p build-core
cc -std=c11 -O2 -DSQLITE_THREADSAFE=1 -DSQLITE_DQS=0 \
  -DSQLITE_OMIT_LOAD_EXTENSION=1 -c third_party/sqlite/sqlite3.c \
  -o build-core/sqlite3.o
g++ -std=c++20 -Wall -Wextra -Wpedantic -Werror -O2 \
  -Iinclude -Ithird_party/sqlite src/core/navigation.cpp src/core/storage.cpp \
  tests/unit/core_tests.cpp build-core/sqlite3.o -pthread -ldl -lm \
  -o build-core/shield_core_tests
./build-core/shield_core_tests
```

Actual summary: `RESULT: 18 passed, 0 failed, 182 assertions`.

## Exact CMake/CTest harness

The harness was created **outside the project**, so it does not alter the application's root CMakeLists.txt:

```sh
mkdir -p /data/shield-core-harness
cat > /data/shield-core-harness/CMakeLists.txt <<'CMAKE'
cmake_minimum_required(VERSION 3.20)
project(ShieldCoreHarness LANGUAGES C CXX)
include(CTest)
include(/data/ShieldBrowser/cmake/Core.cmake)
CMAKE
cmake -S /data/shield-core-harness -B /data/ShieldBrowser/build-core/cmake \
  -DCMAKE_BUILD_TYPE=Release
cmake --build /data/ShieldBrowser/build-core/cmake --parallel 2
ctest --test-dir /data/ShieldBrowser/build-core/cmake --output-on-failure
```

Actual result: `100% tests passed, 0 tests failed out of 1`.

Application integration: root CMake should call `include(CTest)` (or `enable_testing()`), then `include(cmake/Core.cmake)`, and link the application to `shield_core`. The module enables C if needed, compiles the vendored amalgamation as C, and finds `Threads`. It does not find Qt, CEF, or download dependencies.

## Exact sanitizer commands used

```sh
g++ -std=c++20 -O1 -g -fsanitize=address,undefined \
  -fno-omit-frame-pointer -Wall -Wextra -Wpedantic -Werror \
  -Iinclude -Ithird_party/sqlite src/core/navigation.cpp src/core/storage.cpp \
  tests/unit/core_tests.cpp build-core/sqlite3.o -pthread -ldl -lm \
  -o build-core/shield_core_tests_asan
mkdir -p build-core/sanitizer-runtime
ln -sf /usr/lib/gcc/x86_64-amazon-linux/11/libasan.so.6.0.0 \
  build-core/sanitizer-runtime/libasan.so.6
ln -sf /usr/lib/gcc/x86_64-amazon-linux/11/libubsan.so.1.0.0 \
  build-core/sanitizer-runtime/libubsan.so.1
LD_LIBRARY_PATH="$PWD/build-core/sanitizer-runtime" ASAN_OPTIONS=detect_leaks=1 \
  ./build-core/shield_core_tests_asan
```

Actual summary: `RESULT: 18 passed, 0 failed, 182 assertions`; no sanitizer diagnostic. Runtime paths are specific to this Linux environment.

## Test coverage

1. SQLite version/source-ID/build policy.
2. Empty default string views bind as empty SQL TEXT, never accidental NULL.
3. HTTP(S) normalization, case, paths, query/fragment, ports, IPv4 and host validation.
4. IPv6 compressed/uncompressed grammar, IPv4 tails, bad ports and zone rejection.
5. UTF-8 bytewise query percent encoding and HTTPS search-provider validation.
6. Credentials, script/data/unknown schemes, control characters, oversize/empty input, file/external opt-in and known internal pages.
7. Persistence URL allowlist (explicit HTTP(S) or supported internal pages only).
8. History deduplication/counts, deterministic ordering/pagination, retention boundary and stale timestamp handling.
9. History privacy suppression, title/time bounds and unsafe URL rejection.
10. Bookmark upsert identity, original creation time, removal and SQL-injection-shaped text.
11. Settings upsert, optional missing values, empty values, Unicode and bounds.
12. Session private-tab omission, active-index remapping, clean/unclean status and persistence opt-out.
13. Invalid session input leaves the prior snapshot untouched.
14. Real on-disk close/reopen persistence and crash-recovery flag round trip.
15. SQLite trigger-injected failure during session replacement proves transactional rollback after deletion/partial insertion.
16. Trigger-injected failure during full clear proves atomic rollback; bookmark-preserving and full-clear options.
17. Four threads sharing one connection produce exactly 100 visits, with no exceptions or lost increments.
18. Newer schema, foreign application ID, unrecognized existing database and tampered stored session URL rejection.

Tests use fixed timestamps, no network and no sleeps. Temporary directory names are unique to isolate parallel runs; assertions do not depend on names or wall-clock timing. Temporary database/WAL files are cleaned up by RAII.

## Integration and privacy contract

- `Storage` is synchronous and mutex protected. Use a worker thread to avoid blocking Qt's UI thread. The constructor accepts UTF-8 filenames; create/protect the profile directory before opening it. `:memory:` creates a non-persistent profile.
- SQLite uses prepared bound statements, a 3-second busy timeout, WAL, FULL synchronous commits, defensive mode, trusted schema off, secure-delete on and schema version/application identity checks. Multi-statement session/clear operations use transactions; single-row upserts are atomic.
- History requires `PrivacyFlags.private_mode == false` and `record_history == true`. Private/session opt-out operations are no-ops and never overwrite an existing normal-session snapshot. Private tabs are never stored. Explicit bookmark/settings calls intentionally persist: do not call them for transient incognito state unless the user explicitly requested persistence.
- Timestamps are caller-provided nonnegative Unix milliseconds. History retains the newest title/time when older events arrive, while still incrementing visit count. Bookmark upsert preserves original creation time.
- Save an unclean snapshot during browsing (`clean_shutdown=false`); mark clean only on orderly shutdown. Inspect `loadSession().clean_shutdown` to offer recovery after a crash. Recovered URLs are revalidated. Do not automatically restore private tabs.
- Navigation classification is an omnibox policy, not a full browser engine URL parser. It intentionally rejects raw non-ASCII hostnames; callers must perform IDNA conversion first. Query text supports UTF-8 bytewise encoding. Navigation alone does not enforce CEF redirects, subresource protocols, origin isolation, download policy, certificate policy, sandboxing or safe-browsing checks: the application must enforce those separately.
- File access and mailto/tel handoff are disabled by default. External opt-in still requires an explicit confirmation dialog and safe OS URI APIs, never shell concatenation. Known internal URLs must be mapped by the application rather than blindly passed to remote servers.
- Storage is **not encrypted**. Full URLs and titles can contain sensitive data. The caller must choose history/session retention policy and avoid storing secrets as settings. `clearBrowsingData` performs logical deletion; WAL pages, backups and OS/storage behavior mean it is **not a forensic-erasure guarantee**. `secure_delete` does not erase copies outside the active database.
