# Windows build, deployment and packaging

**Status: unsigned development preview.** The scripts do not establish production
readiness. Windows compilation, GUI/CEF sandbox checks and clean-machine installer
checks must be performed on Windows; a Linux source check is not a Windows build.

## Supported baseline and prerequisites

Target Windows 10 1809 (build 17763) or newer / Windows 11, x64, using Visual Studio
2022 Desktop development with C++, an installed Windows SDK and an x64 developer
PowerShell. Install CMake 3.25+, Git, tar (Windows bsdtar), Rust with the
`x86_64-pc-windows-msvc` host and the repository-pinned toolchain, and Qt **6.11.2**
**MSVC 2022 64-bit** kit. No MinGW, 32-bit kit, system WebView or substitute CEF pin.
Qt official archive: https://download.qt.io/official_releases/qt/6.11/6.11.2/ .
Qt Windows toolchain support: https://doc.qt.io/qt-6/windows.html .

Do not disable script execution policy globally. Review scripts and use your
organization's approved execution policy. They stop on errors and check native exit
codes. They do not install VS/Qt/Rust or accept any commercial license for you.

```powershell
# From the repository root, in VS2022 x64 developer PowerShell:
.\tools\setup.ps1 -DownloadInno
# Copy the CEF_ROOT assignment printed by setup into any later/new shell.
$env:CEF_ROOT = "$PWD\.deps\cef_binary_152.0.14+g8a0b5b9+chromium-152.0.7977.167_windows64"
$env:Qt6_DIR = 'C:\Qt\6.11.2\msvc2022_64\lib\cmake\Qt6'
# Alternatively set CMAKE_PREFIX_PATH to C:\Qt\6.11.2\msvc2022_64.
.\tools\check.ps1
.\tools\configure.ps1
.\tools\build.ps1
.\tools\test.ps1
.\tools\deploy.ps1 -QtLicenseDirectory 'C:\Qt\Licenses'
# Install the verified Inno installer manually; use pinned 6.7.3 compiler:
.\tools\package.ps1 -Iscc 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe'
```

Qt license location varies; provide a directory containing the actual Qt license
texts applicable to the kit, not an empty placeholder. Build runs the CMake targets,
including the Cargo staticlib integration. CTest must discover at least one test;
empty test suites are an error. Successful test evidence is invalidated on every
scripted build and tied to the DLL SHA256. Packaging verifies the full stage
manifest and test evidence and refuses missing, changed or untested artifacts.
Do not bypass the wrapper by directly compiling the `.iss` file.

## Dependency integrity

`dependencies.lock.json` pins the exact official CEF Windows64 archive URL, byte
size, official-index SHA1 and SHA256 computed from the downloaded archive after
matching the official size/SHA1. Setup downloads over HTTPS into a partial file,
validates SHA256 before renaming or extraction, and fails closed on mismatch.
The SHA256 is a project pin, not an independently signed upstream attestation;
SHA1 is legacy integrity, **not authentication**. Existing external `CEF_ROOT`
installations are version checked, not retroactively authenticated; obtain them
through setup and retain the verified archive. Delete a partially extracted SDK
folder and rerun setup after an extraction failure. Do not edit the dependency lock
to bypass a mismatch. Inno 6.7.3 is pinned using the official GitHub asset SHA256;
setup also requires a valid Authenticode signature from Pyrsys B.V.

## CEF 138+ sandbox bootstrap — mandatory

Read https://chromiumembedded.github.io/cef/sandbox_setup . The app is
`ShieldBrowser.dll`, exporting `RunWinMain`; the **prebuilt** CEF
`Release/bootstrap.exe` is copied byte-for-byte as `ShieldBrowser.exe`. The same
bootstrap and DLL serve the browser and every CEF subprocess. `sandbox_info` from
the bootstrap must be forwarded to both `CefExecuteProcess` and `CefInitialize`.
There is no static `cef_sandbox.lib` in this architecture. Never replace the
bootstrap with a custom app executable, set a different `browser_subprocess_path`,
or pass `--no-sandbox`. Never claim the sandbox was verified just because staging
found the files.

## Deployment contents and artifacts

`dist/stage` is recreated from **all** CEF `Release` and `Resources` files,
including runtime DLLs, pak files, locales, ICU data, V8 snapshot and Vulkan files.
The bootstrap is renamed as above and the app DLL is copied from
`build/bin/Release`. Qt `windeployqt --release --compiler-runtime` examines the DLL
and copies its Qt dependencies and platform plugins. The VS2022 developer environment
must also provide `VCToolsRedistDir`; deploy copies the full licensed
`x64/Microsoft.VC143.CRT` DLL set app-locally (not from System32), avoiding an
elevated VC redistributable install for this per-user package. Deployment explicitly checks
`platforms/qwindows.dll`, Qt Core/Gui/Widgets, CEF resources, exports and the exact
bootstrap hash. CEF import libraries/bootstrap originals may remain because the
whole runtime directories are intentionally copied. Do not hand-prune them without
revalidating deployment. No automatic internet connection is needed at first run
for these runtimes.

`licenses/` receives the project license, CEF license, Qt license directory, root
third-party notices and Cargo lock/MPL notice when present. This is not a completed
transitive-license audit. Review `THIRD_PARTY_NOTICES.md` before redistribution.
Output is `dist/installers/ShieldBrowser-<version>-windows-x64-unsigned.exe` with a
SHA256SUMS file. Both app and installer are unsigned; there is no certificate,
notarization, automatic updater or SmartScreen reputation infrastructure.

The installer is **per user**, needs no elevation, and defaults to
`%LOCALAPPDATA%\Programs\ShieldBrowser`. Updates and normal/silent uninstall preserve
`%LOCALAPPDATA%\ShieldBrowser\User Data`. Interactive uninstall defaults to keeping
the profile and only offers deletion with two confirmations. Redirected paths are
refused; deletion is restricted to that exact profile leaf, never its parent.

## Mandatory Windows validation before any release

1. Configure/build in a clean x64 VS2022 shell; run all CTest and Rust tests.
2. Launch the staged bootstrap without `--no-sandbox`; check navigation, certificate
   error handling, popup policy, downloads, history/profile persistence and shutdown.
3. Observe renderer/network/GPU child processes using the same bootstrap. Inspect
   tokens/job restrictions with appropriate Windows tooling; reject a sandbox-disabled
   command line. Confirm no unapproved subprocess executable or sandbox bypass.
4. Install on a clean supported Windows VM without Qt/VS on PATH, launch with a
   Unicode/space-containing user path, verify resources/locales and TLS navigation.
5. Upgrade over an existing install, verify data persistence, uninstall keeping data,
   reinstall, then test explicit profile deletion and redirected-profile refusal.
6. Audit all licenses, vulnerability advisories and source obligations; sign all
   binaries after modifications and sign the installer using controlled credentials.
   Re-test after signing. Never publish this preview as production-ready.

For cross-platform syntax and fail-closed helper checks only (not Windows runtime
validation), run `pwsh -NoProfile -File tools/tests/guards.ps1`. These checks cover
missing/empty/stale test evidence and manifest coverage.

The included CI is a manually triggered **self-hosted Windows build recipe**, not
proof it ran. The runner must be provisioned with these exact prerequisites and
Qt/Inno licenses; no credentials or signing secrets are embedded.
