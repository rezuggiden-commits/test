#pragma once
#include <QMainWindow>
#include "include/cef_request_context.h"
namespace shield {
class BrowserPage;
// Native Noma host for a real CEF popup. CEF retains window.opener/session semantics.
class PopupWindow final : public QMainWindow {
 public:
  PopupWindow(CefRefPtr<CefRequestContext> context,const QString& target,const QString& style,int width,int height);
  BrowserPage* page()const{return page_;}
 protected:
  void closeEvent(QCloseEvent*) override;
 private:
  BrowserPage* page_;bool browserClosed_=false;
};
}
