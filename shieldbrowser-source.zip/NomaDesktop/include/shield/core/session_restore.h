#pragma once
#include "shield/core/navigation.h"
#include "shield/core/storage.h"
#include <algorithm>
#include <cstddef>
#include <vector>

namespace shield::core {
struct SessionRestorePlan {
    std::vector<SessionTab> tabs;
    std::size_t active_index = 0;
    bool requires_confirmation = false;
};
// Build a bounded, validated plan without opening network connections. Keep home
// tabs so removing internal pages cannot silently select the wrong restored tab.
inline SessionRestorePlan planSessionRestore(const SessionSnapshot& snapshot,
                                             std::size_t limit = 100) {
    SessionRestorePlan plan;
    limit = std::min<std::size_t>(limit, 200);
    for (std::size_t i = 0; i < snapshot.tabs.size() && plan.tabs.size() < limit; ++i) {
        const auto& tab = snapshot.tabs[i];
        if (tab.private_mode || tab.url.size() > 16384) continue;
        std::string url;
        if (tab.url == "shield://newtab" || tab.url == "shield://newtab/" || tab.url == "about:blank")
            url = "shield://newtab/";
        else if (isPersistableUrl(tab.url)) {
            auto result = classifyNavigation(tab.url);
            if (result.kind == NavigationKind::Web) url = std::move(result.url);
        }
        if (url.empty()) continue;
        if (i <= snapshot.active_index) plan.active_index = plan.tabs.size();
        plan.tabs.push_back({std::move(url), tab.title.substr(0, 4096), false});
    }
    plan.requires_confirmation = !snapshot.clean_shutdown && !plan.tabs.empty();
    return plan;
}
} // namespace shield::core
