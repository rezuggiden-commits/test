#pragma once
#include <string>
#include <string_view>

namespace shield::core {
enum class NavigationKind { Web, Search, Internal, LocalFile, ExternalProtocol, Blocked };
struct NavigationOptions {
    bool allow_local_files = false;
    bool allow_external_protocols = false; // Caller must still obtain user confirmation.
    std::string search_prefix = "https://www.google.com/search?q=";
};
struct NavigationResult {
    NavigationKind kind = NavigationKind::Blocked;
    std::string url;
    std::string reason;
    [[nodiscard]] bool allowed() const noexcept { return kind != NavigationKind::Blocked; }
};
// Classifies omnibox input without network access. Deliberately rejects credentials,
// unsupported schemes and non-ASCII hosts (perform IDNA conversion before calling).
[[nodiscard]] NavigationResult classifyNavigation(std::string_view input,
                                                const NavigationOptions& options = {});
// Only explicitly addressed HTTP(S) and known internal pages are persistent.
// Never persists a search *input*, file, data, script or external-protocol URI.
[[nodiscard]] bool isPersistableUrl(std::string_view url);
[[nodiscard]] std::string encodeQuery(std::string_view text);
} // namespace shield::core
