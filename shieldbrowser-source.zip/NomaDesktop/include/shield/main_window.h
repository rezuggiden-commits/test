#pragma once
#include <QMainWindow>
#include <QThread>
#include <QPointer>
#include <memory>
#include <set>
#include "shield/browser_page.h"
#include "shield/core/storage.h"
class QIcon;class QVBoxLayout;class QNetworkAccessManager;class QTimer;class QNetworkReply;class QLineEdit;class QLabel;class QToolButton;class QListWidget;class QDialog;class QMenu;class QStringListModel;
namespace shield {
class BrowserTabs;
class MainWindow final:public QMainWindow {
 Q_OBJECT
 public:
  MainWindow(CefRefPtr<CefRequestContext>,QString profile,bool privateMode=false,QString initialUrl={});
  ~MainWindow() override;
  bool isClosing()const{return closing_;}
  void newTab(const QString& url="shield://newtab/",bool activate=true);
 protected:
  void closeEvent(QCloseEvent*) override;
  bool nativeEvent(const QByteArray&,void*,qintptr*) override;
  bool eventFilter(QObject*,QEvent*) override;
 private:
  BrowserTabs* tabs_;QLineEdit* address_;QLabel* status_;QToolButton *back_,*forward_,*reload_,*shield_,*bookmark_,*menuButton_;
  QMenu* menu_;QWidget* downloadsDialog_;QListWidget* downloadsList_;QLabel* downloadsEmpty_;
  QWidget* findBar_;QLineEdit* find_;QLabel* findCount_;QStringListModel* suggestions_;
  CefRefPtr<CefRequestContext> context_;
  bool editingAddress_=false;
  bool privateMode_,closing_=false;QString profile_;QStringList closedTabs_;
  std::set<BrowserPage*> pages_;
  QThread storageThread_;QObject* storageWorker_;std::shared_ptr<std::unique_ptr<core::Storage>> storage_;
  QIcon uiIcon(const QString&)const;
  BrowserPage* current()const;void navigate();void closeTab(int);void key(int,int);void refreshChrome();void showFind();void findNext(bool forward=true);
  void store(std::function<void(core::Storage&)>);void saveSession(bool clean=false);void refreshSuggestions();
  QWidget* panel(const QString&,const QString&,QVBoxLayout*&);
  void clearHistoryPanel();void showHistory();void showBookmarks();void showLibrary(bool bookmarks);void addBookmark();
  void loadSearchSuggestions();
  QNetworkAccessManager* suggestNetwork_;QTimer* suggestTimer_;QPointer<QNetworkReply> suggestReply_;quint64 suggestionGeneration_=0;QStringList localSuggestions_;
  void updateDownload(BrowserPage*,unsigned,const QString&,qint64,qint64,bool,bool,int,bool);
  void saveDownloadHistory();void loadDownloadHistory();
  void showDownloads();void privacy();void showSettings();void applyTheme(const QString&);void runUiChecks();void showProxy();
  void withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>&);
};
}
