#pragma once
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include "shield/adblock.h"
namespace shield {
class AdBlockService {
 public:
  bool replace(const std::string& rules);
  bool block(const std::string& url, const std::string& source, unsigned type) const;
  void setEnabled(const std::string& host, bool enabled);
  bool enabled(const std::string& host) const;
  bool ready() const;
 private:
  mutable std::mutex mutex_;
  std::shared_ptr<ShieldAdblockEngine> engine_;
  std::set<std::string> disabled_;
};
}
