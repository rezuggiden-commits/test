#pragma once
#include "include/cef_app.h"
#include "include/cef_request_context.h"
namespace shield {
CefRefPtr<CefApp> createApp();
bool registerInternalPages(CefRefPtr<CefRequestContext> context = nullptr);
void setInternalTheme(bool light);
void setInternalSearch(const std::string& provider);
}
