/* SPDX-License-Identifier: MPL-2.0 */
#ifndef SHIELD_ADBLOCK_H
#define SHIELD_ADBLOCK_H
#include <stddef.h>
#include <stdint.h>
#define SHIELD_ADBLOCK_ABI_VERSION 1
#ifdef __cplusplus
extern "C" {
#endif

typedef struct ShieldAdblockEngine ShieldAdblockEngine;
enum ShieldAdblockStatus {
  SHIELD_ADBLOCK_OK = 0,
  SHIELD_ADBLOCK_INVALID_ARGUMENT = 1,
  SHIELD_ADBLOCK_INVALID_UTF8 = 2,
  SHIELD_ADBLOCK_INVALID_URL = 3,
  SHIELD_ADBLOCK_PANIC = 4
};
enum ShieldAdblockFlags {
  SHIELD_ADBLOCK_BLOCK = 1,
  SHIELD_ADBLOCK_EXCEPTION = 2
};
enum ShieldAdblockResourceType {
  SHIELD_ADBLOCK_OTHER = 0,
  SHIELD_ADBLOCK_DOCUMENT = 1,
  SHIELD_ADBLOCK_SUBDOCUMENT = 2,
  SHIELD_ADBLOCK_SCRIPT = 3,
  SHIELD_ADBLOCK_IMAGE = 4,
  SHIELD_ADBLOCK_STYLESHEET = 5,
  SHIELD_ADBLOCK_XHR = 6,
  SHIELD_ADBLOCK_FONT = 7,
  SHIELD_ADBLOCK_MEDIA = 8,
  SHIELD_ADBLOCK_WEBSOCKET = 9,
  SHIELD_ADBLOCK_PING = 10,
  SHIELD_ADBLOCK_OBJECT = 11,
  SHIELD_ADBLOCK_CSP = 12
};

/* UTF-8 byte spans, NOT NUL-terminated strings. NULL is allowed only for length 0.
 * Limits: 32 MiB rules, 64 KiB per URL. Embedded NUL is rejected.
 * Invalid individual rules are ignored by upstream; an empty list is valid.
 * Outputs must be aligned, writable, and not alias any input or engine storage.
 * On error create sets *out_engine=NULL and check sets *out_flags=0, provided
 * the output pointer is non-NULL. Callers MUST inspect status before flags.
 * Pointer validity cannot be checked: stale/fabricated handles, invalid memory,
 * double destroy, and data races are undefined behavior, not recoverable errors.
 * Engines are immutable. Concurrent checks on one live handle are supported
 * (internally serialized). Destroy must be exclusive: no concurrent users or
 * pending calls. After destroy, discard all copies of the handle.
 * Rust unwind panics are contained and return PANIC; a poisoned engine must be
 * replaced. Process abort, OOM abort, and hardware faults cannot be contained.
 */
int32_t shield_adblock_create(const uint8_t *rules, size_t rules_len,
                             ShieldAdblockEngine **out_engine);
int32_t shield_adblock_check(const ShieldAdblockEngine *engine,
                            const uint8_t *url, size_t url_len,
                            const uint8_t *source, size_t source_len,
                            uint32_t resource_type, uint32_t *out_flags);
/* Destroy NULL is a successful no-op. */
int32_t shield_adblock_destroy(ShieldAdblockEngine *engine);

#ifdef __cplusplus
}
#endif
#endif
