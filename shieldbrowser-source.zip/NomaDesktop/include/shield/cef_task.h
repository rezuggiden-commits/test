#pragma once
#include <functional>
#include "include/cef_task.h"
namespace shield {
class FunctionTask final : public CefTask {
 public:
  explicit FunctionTask(std::function<void()> f) : f_(std::move(f)) {}
  void Execute() override { f_(); }
 private:
  std::function<void()> f_;
  IMPLEMENT_REFCOUNTING(FunctionTask);
};
inline bool onCefUi(std::function<void()> f) {
  return CefPostTask(TID_UI, new FunctionTask(std::move(f)));
}
}
