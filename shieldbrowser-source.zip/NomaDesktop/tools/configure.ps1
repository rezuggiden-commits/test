[CmdletBinding()]
param()
. "$PSScriptRoot/common.ps1"
& "$PSScriptRoot/check.ps1"
$argsList = @('-S',$Root,'-B',(Build-Dir),'-G','Visual Studio 17 2022','-A','x64',"-DCEF_ROOT=$env:CEF_ROOT",'-DBUILD_TESTING=ON')
if ($env:Qt6_DIR) { $argsList += "-DQt6_DIR=$env:Qt6_DIR" } else { $argsList += "-DCMAKE_PREFIX_PATH=$env:CMAKE_PREFIX_PATH" }
Run 'cmake.exe' $argsList
