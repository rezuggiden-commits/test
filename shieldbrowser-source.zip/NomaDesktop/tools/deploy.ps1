[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$QtLicenseDirectory)
. "$PSScriptRoot/common.ps1"
& "$PSScriptRoot/check.ps1"
$evidence = Test-Evidence
$stage = Stage-Dir
if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
New-Item -ItemType Directory -Force $stage | Out-Null
# Copy ALL files, preserving directory hierarchy. No hand-selected CEF subset.
Copy-Item -Path (Join-Path $env:CEF_ROOT 'Release/*') -Destination $stage -Recurse -Force
Copy-Item -Path (Join-Path $env:CEF_ROOT 'Resources/*') -Destination $stage -Recurse -Force
Copy-Item -LiteralPath (Join-Path $env:CEF_ROOT 'Release/bootstrap.exe') -Destination (Join-Path $stage 'Noma.exe')
Copy-Item -LiteralPath (Join-Path (Build-Dir) 'bin/Release/Noma.dll') -Destination $stage
$qt = Get-QtRoot
Run (Join-Path $qt 'bin/windeployqt.exe') @('--release','--compiler-runtime','--dir',$stage,(Join-Path $stage 'Noma.dll'))
# Per-user installation must work without elevated vc_redist installation.
# Ship the licensed VS redistributable CRT app-locally; never copy System32 DLLs.
if (-not $env:VCToolsRedistDir) { throw 'VCToolsRedistDir is missing; app-local VC runtime is required.' }
$crt = Join-Path $env:VCToolsRedistDir 'x64/Microsoft.VC143.CRT'
if (-not (Test-Path -LiteralPath $crt -PathType Container)) { throw "VC143 x64 CRT redistributables missing: $crt" }
Copy-Item -Path (Join-Path $crt '*.dll') -Destination $stage -Force
foreach ($file in @('msvcp140.dll','vcruntime140.dll','vcruntime140_1.dll')) { Require-File (Join-Path $stage $file) }
$licenses = Join-Path $stage 'licenses'
New-Item -ItemType Directory -Force $licenses | Out-Null
Copy-Item -LiteralPath (Join-Path $env:CEF_ROOT 'LICENSE.txt') -Destination (Join-Path $licenses 'CEF-LICENSE.txt')
foreach ($file in @('LICENSE','THIRD_PARTY_NOTICES.md','dependencies.lock.json')) { Require-File (Join-Path $Root $file); Copy-Item -LiteralPath (Join-Path $Root $file) -Destination $licenses }
if (-not (Test-Path -LiteralPath $QtLicenseDirectory -PathType Container) -or @(Get-ChildItem -LiteralPath $QtLicenseDirectory -File -Recurse).Count -eq 0) { throw 'A nonempty Qt license directory is required.' }
Copy-Item -LiteralPath $QtLicenseDirectory -Destination (Join-Path $licenses 'Qt') -Recurse
foreach ($file in @('Noma.exe','Noma.dll','libcef.dll','chrome_elf.dll','icudtl.dat','resources.pak','chrome_100_percent.pak','chrome_200_percent.pak','v8_context_snapshot.bin','locales/en-US.pak','Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','platforms/qwindows.dll','licenses/CEF-LICENSE.txt')) { Require-File (Join-Path $stage $file) }
if ((Hash (Join-Path $stage 'Noma.exe')) -ne (Hash (Join-Path $env:CEF_ROOT 'Release/bootstrap.exe'))) { throw 'Bootstrap must be the exact prebuilt CEF executable.' }
$exports = (& dumpbin.exe /exports (Join-Path $stage 'Noma.dll')) -join "`n"
if ($LASTEXITCODE -ne 0 -or $exports -notmatch '\bRunWinMain\b') { throw 'Noma.dll must export RunWinMain.' }
@{schemaVersion=1; utc=[DateTime]::UtcNow.ToString('o'); testEvidence=$evidence; files=@(Get-TreeManifest $stage)} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'stage-manifest.json') -Encoding UTF8
Write-Host "Staged unsigned development build: $stage. GUI/sandbox/install smoke tests remain mandatory on Windows."
