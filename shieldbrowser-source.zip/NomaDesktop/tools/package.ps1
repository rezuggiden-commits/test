[CmdletBinding()]
param([string]$Iscc)
. "$PSScriptRoot/common.ps1"
Assert-Windows
$e = Test-Evidence
$stage = Stage-Dir
Require-File (Join-Path $stage 'stage-manifest.json')
$m = Get-Content (Join-Path $stage 'stage-manifest.json') -Raw | ConvertFrom-Json
if ($m.testEvidence.dllSha256 -ne $e.dllSha256 -or (Hash (Join-Path $stage 'Noma.dll')) -ne $e.dllSha256) { throw 'Stage/test mismatch; run tests and deploy again.' }
$actual = @(Get-TreeManifest $stage)
if ($actual.Count -ne @($m.files).Count) { throw 'Stage file set changed.' }
foreach ($f in $m.files) { if ((Hash (Join-Path $stage $f.path)) -ne $f.sha256) { throw "Stage file changed: $($f.path)" } }
if (-not $Iscc) { $cmd = Get-Command ISCC.exe -ErrorAction SilentlyContinue; if ($cmd) { $Iscc=$cmd.Source } else { $Iscc=Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe' } }
Require-File $Iscc
# ISCC's PE ProductVersion may be 0.0.0.0; query the compiler engine itself.
$start=New-Object Diagnostics.ProcessStartInfo
$start.FileName=$Iscc;$start.Arguments='/?';$start.UseShellExecute=$false;$start.CreateNoWindow=$true
$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
$compiler=[Diagnostics.Process]::Start($start)
$toolInfo=$compiler.StandardOutput.ReadToEnd()+$compiler.StandardError.ReadToEnd();$compiler.WaitForExit()
if($toolInfo -notmatch 'Inno Setup 6 Command-Line Compiler'){throw "Inno Setup 6 compiler engine is required. Banner: $toolInfo"}
$v='Inno Setup 6 (verified compiler banner; exact binary identified by SHA256)'
Write-Host "Packaging tool: $v; SHA256 $(Hash $Iscc)"
$brand = Get-Content (Join-Path $Root 'config/brand.json') -Raw | ConvertFrom-Json
$output = Join-Path $Root 'dist/installers'
New-Item -ItemType Directory -Force $output | Out-Null
Run $Iscc @("/DStageDir=$stage", "/DOutputDir=$output", "/DAppVersion=$($brand.version)", (Join-Path $Root 'packaging/inno/ShieldBrowser.iss'))
Get-ChildItem -LiteralPath $output -Filter '*.exe' | ForEach-Object { "$(Hash $_.FullName)  $($_.Name)" } | Set-Content -LiteralPath (Join-Path $output 'SHA256SUMS.txt') -Encoding ASCII
Write-Warning 'Unsigned development installer. Signing, clean-VM installation and sandbox/security validation have NOT been performed by this script.'
