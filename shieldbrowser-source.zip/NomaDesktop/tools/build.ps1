[CmdletBinding()]
param()
. "$PSScriptRoot/common.ps1"
Assert-Windows
Remove-Item -LiteralPath (Join-Path (Build-Dir) 'tests-passed.json') -ErrorAction SilentlyContinue
Run 'cmake.exe' @('--build',(Build-Dir),'--config','Release','--parallel')
Require-File (Join-Path (Build-Dir) 'bin/Release/Noma.dll')
