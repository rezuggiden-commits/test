[CmdletBinding()]
param()
. "$PSScriptRoot/common.ps1"
Assert-Windows
foreach ($tool in @('cmake.exe','ctest.exe','cl.exe','dumpbin.exe','tar.exe')) { if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "$tool unavailable; use a VS2022 x64 developer PowerShell." } }
if ($env:VSCMD_ARG_TGT_ARCH -ne 'x64' -or $env:VisualStudioVersion -notlike '17.*') { throw 'Use a Visual Studio 2022 x64 developer shell (target x64).' }
$cmake = & cmake.exe --version
if ($LASTEXITCODE -ne 0 -or $cmake[0] -notmatch '([0-9]+\.[0-9]+\.[0-9]+)' -or [version]$Matches[1] -lt [version]'3.25.0') { throw 'CMake >=3.25 required.' }
if (-not $env:CEF_ROOT) { throw 'Set CEF_ROOT to the exact extracted pinned CEF distribution.' }
foreach ($file in @('include/cef_version.h','Release/bootstrap.exe','Release/libcef.dll','Resources/icudtl.dat','Resources/resources.pak','LICENSE.txt')) { Require-File (Join-Path $env:CEF_ROOT $file) }
$version = Get-Content (Join-Path $env:CEF_ROOT 'include/cef_version.h') -Raw
if (-not $version.Contains($Lock.cef.version)) { throw "CEF version must be $($Lock.cef.version)." }
$qt = Get-QtRoot
$qv = (& (Join-Path $qt 'bin/qmake.exe') -query QT_VERSION | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $qv -ne $Lock.qt.version) { throw "Qt $($Lock.qt.version) required; got $qv." }
Require-File (Join-Path $qt 'bin/windeployqt.exe')
Write-Host "Prerequisites detected. Qt=$qt CEF=$env:CEF_ROOT. This is not a successful build or sandbox verification."
