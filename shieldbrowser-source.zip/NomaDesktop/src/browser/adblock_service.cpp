#include "shield/adblock_service.h"
#include <QUrl>
namespace shield {
bool AdBlockService::replace(const std::string& rules) {
  ShieldAdblockEngine* raw = nullptr;
  if (shield_adblock_create(reinterpret_cast<const uint8_t*>(rules.data()),rules.size(),&raw) != 0) return false;
  auto engine = std::shared_ptr<ShieldAdblockEngine>(raw, [](auto* p){ shield_adblock_destroy(p); });
  std::lock_guard lock(mutex_); engine_.swap(engine); return true;
}
bool AdBlockService::block(const std::string& url, const std::string& source, unsigned type) const {
  const auto host = QUrl(QString::fromStdString(source)).host().toLower().toStdString();
  std::shared_ptr<ShieldAdblockEngine> engine;
  { std::lock_guard lock(mutex_); if(disabled_.contains(host)) return false; engine=engine_; }
  if(!engine) return false;
  uint32_t flags=0;
  const int result=shield_adblock_check(engine.get(),reinterpret_cast<const uint8_t*>(url.data()),url.size(),
    reinterpret_cast<const uint8_t*>(source.data()),source.size(),type,&flags);
  return result==0 && (flags & 1u)!=0;
}
void AdBlockService::setEnabled(const std::string& host,bool value) {
  std::lock_guard lock(mutex_); if(value) disabled_.erase(host); else disabled_.insert(host);
}
bool AdBlockService::enabled(const std::string& host) const {std::lock_guard lock(mutex_);return !disabled_.contains(host);}
bool AdBlockService::ready() const {std::lock_guard lock(mutex_);return bool(engine_);}
}
