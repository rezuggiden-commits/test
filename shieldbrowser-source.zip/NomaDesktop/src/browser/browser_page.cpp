#include "shield/browser_page.h"
#include "shield/cef_task.h"
#include <QCoreApplication>
#include <QPointer>
#include <QResizeEvent>
#include <QShowEvent>
#include <QTimer>
#include <QMessageBox>
#include <QDialog>
#include <QSaveFile>
#include <QDir>
#include <windows.h>
#include <map>
#include <mutex>
#include <QMap>
#include <cctype>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <cmath>
#include <algorithm>
#include "include/cef_client.h"
#include "include/cef_parser.h"
#include "include/cef_download_handler.h"
#include "include/cef_permission_handler.h"
namespace shield {
class BrowserClient final : public CefClient,public CefLifeSpanHandler,public CefDisplayHandler,
 public CefLoadHandler,public CefRequestHandler,public CefResourceRequestHandler,
 public CefFocusHandler,public CefPermissionHandler,public CefKeyboardHandler,public CefDownloadHandler,public CefFindHandler {
 public:
  BrowserClient(BrowserPage* page): page_(page) {}
  CefRefPtr<CefFocusHandler> GetFocusHandler() override{return this;}
  void OnGotFocus(CefRefPtr<CefBrowser>) override {deliver([](BrowserPage& p){emit p.contentFocused();});}
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override{return this;}
  CefRefPtr<CefDisplayHandler> GetDisplayHandler() override{return this;}
  CefRefPtr<CefLoadHandler> GetLoadHandler() override{return this;}
  CefRefPtr<CefRequestHandler> GetRequestHandler() override{return this;}
  CefRefPtr<CefPermissionHandler> GetPermissionHandler() override{return this;}
  CefRefPtr<CefKeyboardHandler> GetKeyboardHandler() override{return this;}
  CefRefPtr<CefFindHandler> GetFindHandler() override{return this;}
  void OnFindResult(CefRefPtr<CefBrowser>,int,int count,const CefRect&,int active,bool) override {deliver([count,active](BrowserPage& p){emit p.findResult(count,active);});}
  CefRefPtr<CefDownloadHandler> GetDownloadHandler() override{return this;}
  template<class F> void deliver(F f) {
    auto page=page_;
    QMetaObject::invokeMethod(QCoreApplication::instance(), [page,f=std::move(f)] {if(page) f(*page);},Qt::QueuedConnection);
  }
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    deliver([browser](BrowserPage& p){p.created(browser);});
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {
    closed_.store(true);downloads_.clear(); deliver([](BrowserPage& p){p.beforeClose();});
  }
  bool DoClose(CefRefPtr<CefBrowser> browser) override {
    // Windowed Alloy's default WM_CLOSE targets the Qt TOP-LEVEL window, not
    // this tab. Tear down only CEF's child HWND on its owning CEF UI thread.
    // Defer teardown until after this callback returns to avoid reentrancy.
    auto self=CefRefPtr<BrowserClient>(this);
    const bool posted=onCefUi([self,browser]{if(!browser->IsValid())return;
      auto hwnd=browser->GetHost()->GetWindowHandle();
      if(hwnd && IsWindow(hwnd) && !DestroyWindow(hwnd))
        self->deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("Ошибка уничтожения окна CEF; завершение приостановлено"));});
    });
    if(!posted)deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("CEF не принял задачу закрытия; завершение приостановлено"));});
    return true;
  }
  void OnTitleChange(CefRefPtr<CefBrowser>,const CefString& title) override {
    title_=QString::fromStdWString(title.ToWString());
    deliver([s=QString::fromStdWString(title.ToWString())](BrowserPage& p){emit p.titleChanged(s);});
  }
  bool OnConsoleMessage(CefRefPtr<CefBrowser> browser,cef_log_severity_t,const CefString& message,const CefString&,int) override {
    const auto dir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");const auto text=message.ToString();
    const auto external=qEnvironmentVariable("SHIELD_EXTERNAL_TEST");
    if(!external.isEmpty()&&text.rfind("ASTER_WEB_PROOF ",0)==0&&text.size()<4096&&browser->IsValid()){
      auto f=browser->GetMainFrame();if(f){auto u=QUrl(QString::fromStdWString(f->GetURL().ToWString()));auto h=u.host();if(u.scheme()=="https"&&(h=="youtube.com"||h.endsWith(".youtube.com")||h=="google.com"||h.endsWith(".google.com")||h=="example.org")){auto j=QByteArray::fromStdString(text.substr(16));deliver([external,j](BrowserPage&){QFile f(QDir(external).filePath("external.jsonl"));if(f.open(QIODevice::Append)){f.write(j);f.write("\n");}});}}return true;
    }
    constexpr char prefix[]="SHIELD_START_PROOF ";
    if(dir.isEmpty()||text.size()>4096||text.rfind(prefix,0)!=0||!browser->IsValid())return false;
    auto frame=browser->GetMainFrame();if(!frame||frame->GetURL().ToString().rfind("shield://newtab",0)!=0)return false;
    auto json=QByteArray::fromStdString(text.substr(sizeof(prefix)-1));
    deliver([dir,json](BrowserPage&){QSaveFile f(QDir(dir).filePath("home-dom-proof.json"));if(f.open(QIODevice::WriteOnly)){f.write(json);f.commit();}});return true;
  }
  void OnAddressChange(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,const CefString& url) override {
    if(!frame->IsMain())return;
    deliver([s=QString::fromStdWString(url.ToWString())](BrowserPage& p){p.url_=s;emit p.addressChanged(s);});
  }
  void OnLoadingStateChange(CefRefPtr<CefBrowser>,bool loading,bool back,bool forward) override {
    deliver([=](BrowserPage& p){p.loading_=loading;if(loading){if(!p.loadTimer_->isActive())p.loadTimer_->start(30000);}else p.loadTimer_->stop();p.back_=back;p.forward_=forward;emit p.loadingChanged(loading,back,forward);});
  }
  void OnLoadEnd(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,int status) override {
    if(frame->IsMain() && status>=200 && status<400) {
      const auto loadedUrl=QString::fromStdWString(frame->GetURL().ToWString());
      const auto loadedTitle=title_;
      deliver([loadedUrl,loadedTitle](BrowserPage& p){p.loadTimer_->stop();p.loading_=false;emit p.loadingChanged(false,p.back_,p.forward_);emit p.completed(loadedUrl,loadedTitle);});
      if(!qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST")&&loadedUrl.startsWith("https://"))frame->ExecuteJavaScript("setTimeout(()=>console.log('ASTER_WEB_PROOF '+JSON.stringify({url:location.href,title:document.title,text:document.body?.innerText.length||0})),700)",loadedUrl.toStdWString(),0);
      if(loadedUrl.startsWith("shield://newtab")&&!qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")) {
        frame->ExecuteJavaScript("setTimeout(()=>console.log('SHIELD_START_PROOF '+JSON.stringify({title:document.title,formAction:document.getElementById('search')?.action,shortcutCount:document.querySelectorAll('.tile>a').length,addButton:!!document.querySelector('.add')})),250)",loadedUrl.toStdWString(),0);
      }
    }
  }
  void OnLoadError(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,ErrorCode error,const CefString& text,const CefString& failedUrl) override {
    if(frame->IsMain() && error!=ERR_ABORTED){auto failed=QString::fromStdWString(failedUrl.ToWString());if(!failed.startsWith("http"))failed=QString{};
      deliver([failed,s=QString::fromStdWString(text.ToWString()),error](BrowserPage& p){p.showNetworkError(failed.isEmpty()?p.attempted_:failed,QString::number(int(error))+" · "+s);});}
  }
  bool OnBeforePopup(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,int,const CefString& target,const CefString&,
    CefLifeSpanHandler::WindowOpenDisposition,bool userGesture,const CefPopupFeatures&,CefWindowInfo&,CefRefPtr<CefClient>&,
    CefBrowserSettings&,CefRefPtr<CefDictionaryValue>&,bool*) override {
    if(userGesture) deliver([s=QString::fromStdWString(target.ToWString())](BrowserPage& p){emit p.popupRequested(s);});
    return true; // Never create an unmanaged browser; user-initiated links become tabs.
  }
  bool OnBeforeBrowse(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,CefRefPtr<CefRequest> request,bool,bool) override {
    CefURLParts parts;
    if(!CefParseURL(request->GetURL(),parts)) return true;
    const auto scheme=CefString(&parts.scheme).ToString();
    if(scheme=="shield")return CefString(&parts.host).ToString()!="newtab"&&CefString(&parts.host).ToString()!="error";
    return scheme!="http" && scheme!="https" && scheme!="about" && scheme!="blob";
  }
  CefRefPtr<CefResourceRequestHandler> GetResourceRequestHandler(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,CefRefPtr<CefRequest>,bool,bool,const CefString&,bool&) override {
    return nullptr; // No per-resource callback / filtering on the network hot path.
  }
  bool OnCertificateError(CefRefPtr<CefBrowser>,cef_errorcode_t,const CefString&,CefRefPtr<CefSSLInfo>,CefRefPtr<CefCallback>) override {
    return false; // Engine cancels certificate errors. No insecure bypass.
  }
  bool OnRequestMediaAccessPermission(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,const CefString& origin,uint32_t requested,
    CefRefPtr<CefMediaAccessCallback> callback) override {
    const auto source=QString::fromStdWString(origin.ToWString());QUrl url(source);
    if(url.scheme()!="https"&&url.host()!="127.0.0.1"&&url.host()!="localhost"){callback->Cancel();return true;}
    auto page=page_;QMetaObject::invokeMethod(QCoreApplication::instance(),[page,source,requested,callback]{
      if(!page){onCefUi([callback]{callback->Cancel();});return;}
      auto* prompt=new QMessageBox(QMessageBox::Question,QString::fromUtf8("Разрешение сайта"),source+QString::fromUtf8("\n\nРазрешить запрошенный доступ к микрофону, камере или захвату экрана? Разрешение действует для этого запроса."),QMessageBox::Yes|QMessageBox::No,page);
      prompt->setDefaultButton(QMessageBox::No);prompt->setAttribute(Qt::WA_DeleteOnClose);QObject::connect(prompt,&QDialog::finished,prompt,[callback,requested](int result){onCefUi([callback,requested,result]{if(result==QMessageBox::Yes)callback->Continue(requested);else callback->Cancel();});});prompt->open();
    },Qt::QueuedConnection);return true;
  }
  bool OnShowPermissionPrompt(CefRefPtr<CefBrowser>,uint64_t,const CefString& origin,uint32_t requested,
    CefRefPtr<CefPermissionPromptCallback> callback) override {
    // Unknown/unsupported capabilities fail closed; do not ask for opaque bitmasks.
    (void)requested;(void)origin;callback->Continue(CEF_PERMISSION_RESULT_DENY);return true;
  }
  bool OnPreKeyEvent(CefRefPtr<CefBrowser>,const CefKeyEvent& event,CefEventHandle,bool* shortcut) override {
    if(event.type!=KEYEVENT_RAWKEYDOWN)return false;
    const bool ctrl=event.modifiers & EVENTFLAG_CONTROL_DOWN;
    const bool alt=event.modifiers & EVENTFLAG_ALT_DOWN;
    const int key=event.windows_key_code;
    if((ctrl && (key=='T'||key=='W'||key=='L'||key=='R'||key=='D'||key=='H'||key=='J'||key=='N'||key=='F'||key==VK_OEM_PLUS||key==VK_OEM_MINUS||key=='0')) ||
       (alt && (key==VK_LEFT||key==VK_RIGHT)) || key==VK_F11 || (ctrl&&(key==VK_TAB||(key>='1'&&key<='9')))) {
      int mods=(ctrl?int(Qt::ControlModifier):0)|(alt?int(Qt::AltModifier):0)|((event.modifiers&EVENTFLAG_SHIFT_DOWN)?int(Qt::ShiftModifier):0);
      deliver([key,mods](BrowserPage& p){emit p.shortcut(key,mods);});*shortcut=true;return true;
    }
    return false;
  }
  bool OnBeforeDownload(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,const CefString&,
    CefRefPtr<CefBeforeDownloadCallback> callback) override {
    // Only a fixed loopback fixture may bypass the save dialog in the CI tour.
    const auto testDir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");const auto url=QUrl(QString::fromStdWString(item->GetURL().ToWString()));
    if(!testDir.isEmpty()&&url.scheme()=="http"&&url.host()=="127.0.0.1"&&url.path()=="/test-download.txt") {
      auto path=QDir::toNativeSeparators(QDir(testDir).absoluteFilePath("fixture-download.txt"));QFile trace(QDir(testDir).filePath("download-events.jsonl"));if(trace.open(QIODevice::Append)){trace.write(QJsonDocument(QJsonObject{{"beforeDownload",true},{"id",int(item->GetId())},{"destination",path},{"directoryExists",QDir(testDir).exists()}}).toJson(QJsonDocument::Compact));trace.write("\n");}callback->Continue(path.toStdWString(),false);return true;}
    callback->Continue(CefString(),true);return true;}
  void OnDownloadUpdated(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,CefRefPtr<CefDownloadItemCallback> callback) override {
    auto id=item->GetId();
    if(item->IsInProgress())downloads_[id]=callback;else downloads_.erase(id);
    auto name=QString::fromStdWString(item->GetFullPath().ToWString());
    if(name.isEmpty())name=QString::fromStdWString(item->GetURL().ToWString());
    auto received=item->GetReceivedBytes(), total=item->GetTotalBytes();bool done=item->IsComplete(),cancelled=item->IsCanceled();int interrupt=item->IsInterrupted()?int(item->GetInterruptReason()):0;
    const auto testDir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");if(!testDir.isEmpty()){QFile trace(QDir(testDir).filePath("download-events.jsonl"));if(trace.open(QIODevice::Append)){trace.write(QJsonDocument(QJsonObject{{"name",name},{"complete",done},{"cancelled",cancelled},{"interruptReason",interrupt},{"received",double(received)},{"total",double(total)}}).toJson(QJsonDocument::Compact));trace.write("\n");}}
    deliver([=](BrowserPage& p){emit p.downloadChanged(id,name,received,total,done,cancelled,interrupt);});
  }
  void cancel(unsigned id) {auto it=downloads_.find(id);if(it!=downloads_.end())it->second->Cancel();}
 private:
  QPointer<BrowserPage> page_;
  QString title_; // CEF UI thread only; copied with completed-document events.
  std::atomic<bool> closed_{false};
  std::map<unsigned,CefRefPtr<CefDownloadItemCallback>> downloads_; // CEF UI only
  IMPLEMENT_REFCOUNTING(BrowserClient);
};
BrowserPage::BrowserPage(CefRefPtr<CefRequestContext> context,QWidget* parent)
 :QWidget(parent),context_(context) {
  loadTimer_=new QTimer(this);loadTimer_->setSingleShot(true);connect(loadTimer_,&QTimer::timeout,this,[this]{if(loading_&&!closing_){command([](auto b){b->StopLoad();});showNetworkError(url_,tr("Время ожидания истекло. Сервер не ответил за 30 секунд."));}});
  setAttribute(Qt::WA_NativeWindow);setFocusPolicy(Qt::StrongFocus);
  auto* client=new BrowserClient(this);client_=client;

}
BrowserPage::~BrowserPage() = default;
void BrowserPage::setDefaultZoom(int percent){zoom_=std::log(percent/100.0)/std::log(1.2);}
int BrowserPage::zoomPercent()const{return int(std::lround(100*std::pow(1.2,zoom_)));}
void BrowserPage::zoomBy(int step){zoom_=std::clamp(zoom_+step*0.5,-6.0,8.0);command([level=zoom_](auto b){b->GetHost()->SetZoomLevel(level);});}
void BrowserPage::resetZoom(){zoom_=0;command([](auto b){b->GetHost()->SetZoomLevel(0);});}
void BrowserPage::showEvent(QShowEvent* e) {
  QWidget::showEvent(e);
  if(started_)return; started_=true;
  CefWindowInfo info;
  info.SetAsChild(reinterpret_cast<HWND>(winId()),CefRect(0,0,int(width()*devicePixelRatioF()),int(height()*devicePixelRatioF())));
  info.runtime_style=CEF_RUNTIME_STYLE_ALLOY;
  CefBrowserSettings settings;
  if(!CefBrowserHost::CreateBrowser(info,client_,url_.toStdWString(),settings,nullptr,context_)) {
    started_=false;loading_=false;emit loadingChanged(false,false,false);emit loadFailed(tr("CEF не создал окно браузера"));
  }
}
void BrowserPage::created(CefRefPtr<CefBrowser> browser) {browser_=browser;if(closing_)shutdown();else{fit();command([level=zoom_](auto b){b->GetHost()->SetZoomLevel(level);});}}
void BrowserPage::beforeClose() {browser_=nullptr;emit closed();}
void BrowserPage::showNetworkError(const QString& failed,const QString& reason){if(closing_||failed.startsWith("shield:"))return;loadTimer_->stop();loading_=false;emit loadingChanged(false,back_,forward_);emit loadFailed(reason);QUrl u("shield://error/");QUrlQuery q;q.addQueryItem("url",failed);q.addQueryItem("reason",reason);u.setQuery(q);open(u.toString());}
void BrowserPage::open(const QString& url) {attempted_=url;url_=url;emit addressChanged(url);command([u=url.toStdWString()](auto browser){browser->GetMainFrame()->LoadURL(u);});}
void BrowserPage::command(const std::function<void(CefRefPtr<CefBrowser>)>& f) {
  if(browser_) {auto b=browser_;onCefUi([b,f]{if(b->IsValid())f(b);});}
}
void BrowserPage::shutdown() {
  closing_=true;
  if(browser_)command([](auto b){b->GetHost()->CloseBrowser(true);});
  else if(!started_)QTimer::singleShot(0,this,[this]{emit closed();});
}
void BrowserPage::cancelDownload(unsigned id) {auto client=CefRefPtr<BrowserClient>(static_cast<BrowserClient*>(client_.get()));onCefUi([client,id]{client->cancel(id);});}
void BrowserPage::fit() {
  command([w=int(width()*devicePixelRatioF()),h=int(height()*devicePixelRatioF())](auto b){
    SetWindowPos(b->GetHost()->GetWindowHandle(),nullptr,0,0,w,h,SWP_NOZORDER|SWP_NOACTIVATE);
  });
}
void BrowserPage::resizeEvent(QResizeEvent* e){QWidget::resizeEvent(e);fit();}
void BrowserPage::focusInEvent(QFocusEvent* e){QWidget::focusInEvent(e);command([](auto b){b->GetHost()->SetFocus(true);});}
}
