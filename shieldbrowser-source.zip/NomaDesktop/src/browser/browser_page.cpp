#include "shield/browser_page.h"
#include "shield/cef_task.h"
#include "shield/popup_window.h"
#include "shield/main_window.h"
#include <QApplication>
#include <QVariant>
#include <QCoreApplication>
#include <QPointer>
#include <QResizeEvent>
#include <QShowEvent>
#include <QTimer>
#include <QMessageBox>
#include <QDialog>
#include <QSaveFile>
#include <QDir>
#include <QScreen>
#include <QPixmap>
#include <windows.h>
#include <map>
#include <vector>
#include <mutex>
#include <QMap>
#include <cctype>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <cmath>
#include <algorithm>
#include "include/cef_client.h"
#include "include/cef_parser.h"
#include "include/cef_download_handler.h"
#include "include/cef_permission_handler.h"
namespace shield {
class BrowserClient final : public CefClient,public CefLifeSpanHandler,public CefDisplayHandler,
 public CefLoadHandler,public CefRequestHandler,public CefResourceRequestHandler,
 public CefFocusHandler,public CefPermissionHandler,public CefKeyboardHandler,public CefDownloadHandler,public CefFindHandler {
 public:
  BrowserClient(BrowserPage* page): page_(page) {}
  CefRefPtr<CefFocusHandler> GetFocusHandler() override{return this;}
  void OnGotFocus(CefRefPtr<CefBrowser>) override {deliver([](BrowserPage& p){emit p.contentFocused();});}
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override{return this;}
  CefRefPtr<CefDisplayHandler> GetDisplayHandler() override{return this;}
  CefRefPtr<CefLoadHandler> GetLoadHandler() override{return this;}
  CefRefPtr<CefRequestHandler> GetRequestHandler() override{return this;}
  CefRefPtr<CefPermissionHandler> GetPermissionHandler() override{return this;}
  CefRefPtr<CefKeyboardHandler> GetKeyboardHandler() override{return this;}
  CefRefPtr<CefFindHandler> GetFindHandler() override{return this;}
  void OnFindResult(CefRefPtr<CefBrowser>,int,int count,const CefRect&,int active,bool) override {deliver([count,active](BrowserPage& p){emit p.findResult(count,active);});}
  CefRefPtr<CefDownloadHandler> GetDownloadHandler() override{return this;}
  template<class F> void deliver(F f) {
    auto page=page_;
    QMetaObject::invokeMethod(QCoreApplication::instance(), [page,f=std::move(f)] {if(page) f(*page);},Qt::QueuedConnection);
  }
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    const bool popup=bool(opener_);if(opener_){opener_->pendingPopups_.erase(openerPopupId_);opener_=nullptr;}
    deliver([browser,popup](BrowserPage& p){p.created(browser);if(popup&&!p.isClosing()){p.window()->show();p.window()->raise();p.window()->activateWindow();}});
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {
    closed_.store(true);cancelMediaRequests();downloads_.clear(); deliver([](BrowserPage& p){p.beforeClose();});
  }
  bool DoClose(CefRefPtr<CefBrowser> browser) override {
    // Windowed Alloy's default WM_CLOSE targets the Qt TOP-LEVEL window, not
    // this tab. Tear down only CEF's child HWND on its owning CEF UI thread.
    // Defer teardown until after this callback returns to avoid reentrancy.
    auto self=CefRefPtr<BrowserClient>(this);
    const bool posted=onCefUi([self,browser]{if(!browser->IsValid())return;
      auto hwnd=browser->GetHost()->GetWindowHandle();
      if(hwnd && IsWindow(hwnd) && !DestroyWindow(hwnd))
        self->deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("Ошибка уничтожения окна CEF; завершение приостановлено"));});
    });
    if(!posted)deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("CEF не принял задачу закрытия; завершение приостановлено"));});
    return true;
  }
  void OnTitleChange(CefRefPtr<CefBrowser>,const CefString& title) override {
    title_=QString::fromStdWString(title.ToWString());
    deliver([s=QString::fromStdWString(title.ToWString())](BrowserPage& p){emit p.titleChanged(s);});
  }
  bool OnConsoleMessage(CefRefPtr<CefBrowser> browser,cef_log_severity_t,const CefString& message,const CefString&,int) override {
    const auto dir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");const auto text=message.ToString();
    const auto external=qEnvironmentVariable("SHIELD_EXTERNAL_TEST");
    if(!external.isEmpty()&&text.rfind("ASTER_WEB_PROOF ",0)==0&&text.size()<4096&&browser->IsValid()){
      auto f=browser->GetMainFrame();if(f){auto u=QUrl(QString::fromStdWString(f->GetURL().ToWString()));auto h=u.host();if(u.scheme()=="https"&&(h=="youtube.com"||h.endsWith(".youtube.com")||h=="google.com"||h.endsWith(".google.com")||h=="example.org"||h=="duckduckgo.com"||h.endsWith(".duckduckgo.com")||h=="wikipedia.org"||h.endsWith(".wikipedia.org"))){auto j=QByteArray::fromStdString(text.substr(16));deliver([external,j](BrowserPage& p){QFile f(QDir(external).filePath("external.jsonl"));if(f.open(QIODevice::Append)){f.write(j);f.write("\n");}QTimer::singleShot(200,&p,[external,page=QPointer<BrowserPage>(&p)]{if(page&&page->window()->screen()){auto* w=page->window();w->screen()->grabWindow(0,w->frameGeometry().x(),w->frameGeometry().y(),w->width(),w->height()).save(QDir(external).filePath("native-site.png"));}});});}}return true;
    }
    constexpr char prefix[]="SHIELD_START_PROOF ";
    if(dir.isEmpty()||text.size()>4096||text.rfind(prefix,0)!=0||!browser->IsValid())return false;
    auto frame=browser->GetMainFrame();if(!frame||frame->GetURL().ToString().rfind("shield://newtab",0)!=0)return false;
    auto json=QByteArray::fromStdString(text.substr(sizeof(prefix)-1));
    deliver([dir,json](BrowserPage& p){auto proof=QJsonDocument::fromJson(json).object();p.setProperty("homeDomVerified",proof.value("shortcutCount").toInt()==4&&proof.value("addButton").toBool()&&proof.value("formAction").toString().startsWith("https://"));QSaveFile f(QDir(dir).filePath("home-dom-proof.json"));if(f.open(QIODevice::WriteOnly)){f.write(json);f.commit();}});return true;
  }
  void OnAddressChange(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,const CefString& url) override {
    if(!frame->IsMain())return;
    deliver([s=QString::fromStdWString(url.ToWString())](BrowserPage& p){p.url_=s;emit p.addressChanged(s);});
  }
  void OnLoadingStateChange(CefRefPtr<CefBrowser>,bool loading,bool back,bool forward) override {
    deliver([=](BrowserPage& p){p.loading_=loading;if(loading){if(!p.loadTimer_->isActive())p.loadTimer_->start(30000);}else p.loadTimer_->stop();p.back_=back;p.forward_=forward;emit p.loadingChanged(loading,back,forward);});
  }
  void OnLoadEnd(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,int status) override {
    if(frame->IsMain() && status>=200 && status<400) {
      const auto loadedUrl=QString::fromStdWString(frame->GetURL().ToWString());
      const auto loadedTitle=title_;
      deliver([loadedUrl,loadedTitle](BrowserPage& p){p.loadTimer_->stop();p.loading_=false;emit p.loadingChanged(false,p.back_,p.forward_);emit p.completed(loadedUrl,loadedTitle);});
      if(!qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST")&&loadedUrl.startsWith("https://"))frame->ExecuteJavaScript("setTimeout(()=>console.log('ASTER_WEB_PROOF '+JSON.stringify({url:location.href,title:document.title,text:document.body?.innerText.length||0})),700)",loadedUrl.toStdWString(),0);
      if(loadedUrl.startsWith("shield://newtab")&&!qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")) {
        frame->ExecuteJavaScript("setTimeout(()=>console.log('SHIELD_START_PROOF '+JSON.stringify({title:document.title,formAction:document.getElementById('search')?.action,shortcutCount:document.querySelectorAll('.tile>a').length,addButton:!!document.querySelector('.add')})),250)",loadedUrl.toStdWString(),0);
      }
    }
  }
  void OnLoadError(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,ErrorCode error,const CefString& text,const CefString& failedUrl) override {
    if(frame->IsMain() && error!=ERR_ABORTED){auto failed=QString::fromStdWString(failedUrl.ToWString());if(!failed.startsWith("http"))failed=QString{};
      deliver([failed,s=QString::fromStdWString(text.ToWString()),error](BrowserPage& p){p.showNetworkError(failed.isEmpty()?p.attempted_:failed,QString::number(int(error))+" · "+s);});}
  }
  void OnRenderProcessTerminated(CefRefPtr<CefBrowser>,TerminationStatus,int error,const CefString&) override {
    cancelMediaRequests();deliver([error](BrowserPage& p){if(p.closing_)return;p.setProperty("rendererCrashHandled",true);
      if(p.url_.startsWith("shield://error")){p.loadTimer_->stop();p.loading_=false;emit p.loadingChanged(false,p.back_,p.forward_);emit p.loadFailed(QString::fromUtf8("Не удалось восстановить процесс страницы. Попробуйте открыть новую вкладку."));return;}
      const auto failed=p.url_.startsWith("shield:")?p.attempted_:p.url_;
      p.showNetworkError(failed,QString::fromUtf8("Процесс страницы завершился неожиданно. Код: ")+QString::number(error),"renderer");});
  }
  bool OnBeforePopup(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,int popupId,const CefString& target,const CefString&,
    CefLifeSpanHandler::WindowOpenDisposition,bool userGesture,const CefPopupFeatures& features,CefWindowInfo& info,CefRefPtr<CefClient>& client,
    CefBrowserSettings&,CefRefPtr<CefDictionaryValue>&,bool* noJavascriptAccess) override {
    const auto targetText=QString::fromStdWString(target.ToWString());QUrl url(targetText);
    if(!userGesture||pendingPopups_.size()>=16||(!targetText.isEmpty()&&url.scheme()!="http"&&url.scheme()!="https"&&targetText!="about:blank"))return true;
    QPointer<BrowserPage> popup;CefRefPtr<BrowserClient> popupClient;auto openerPage=page_;
    const int width=features.widthSet?features.width:560,height=features.heightSet?features.height:720;
    // CEF's synchronous popup contract requires the child HWND before returning.
    // No CEF waits/calls are performed by this Qt host constructor.
    const bool invoked=QMetaObject::invokeMethod(QCoreApplication::instance(),[openerPage,&popup,&popupClient,&info,targetText,width,height]{
      if(!openerPage||openerPage->closing_)return;
      auto* owner=qobject_cast<MainWindow*>(openerPage->property("nomaOwner").value<QObject*>());if(!owner||owner->isClosing())return;
      auto* host=new PopupWindow(openerPage->context_,targetText,openerPage->window()->styleSheet(),width,height);
      // Keep the host hidden until OnAfterCreated. Activating it here can
      // send synchronous Win32 focus messages to the blocked CEF UI thread.
      popup=host->page();owner->adoptPopup(popup);
      info.SetAsChild(reinterpret_cast<HWND>(popup->winId()),CefRect(0,0,int(popup->width()*popup->devicePixelRatioF()),int(popup->height()*popup->devicePixelRatioF())));
      popupClient=static_cast<BrowserClient*>(popup->client_.get());
    },Qt::BlockingQueuedConnection);
    if(!invoked||!popup)return true;
    info.runtime_style=CEF_RUNTIME_STYLE_ALLOY;
    popupClient->opener_=this;popupClient->openerPopupId_=popupId;
    client=popupClient;pendingPopups_[popupId]=popup;if(noJavascriptAccess)*noJavascriptAccess=false;
    return false;
  }
  void OnBeforePopupAborted(CefRefPtr<CefBrowser>,int popupId) override {
    auto it=pendingPopups_.find(popupId);if(it==pendingPopups_.end())return;auto popup=it->second;pendingPopups_.erase(it);
    QMetaObject::invokeMethod(QCoreApplication::instance(),[popup]{if(popup)popup->abortPopup();},Qt::QueuedConnection);
  }
  bool OnBeforeBrowse(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,CefRefPtr<CefRequest> request,bool,bool) override {
    if(frame)cancelMediaRequests(frame->IsMain()?std::string{}:frame->GetIdentifier().ToString());
    CefURLParts parts;
    if(!CefParseURL(request->GetURL(),parts)) return true;
    const auto scheme=CefString(&parts.scheme).ToString();
    if(scheme=="shield")return CefString(&parts.host).ToString()!="newtab"&&CefString(&parts.host).ToString()!="error";
    return scheme!="http" && scheme!="https" && scheme!="about" && scheme!="blob";
  }
  CefRefPtr<CefResourceRequestHandler> GetResourceRequestHandler(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,CefRefPtr<CefRequest>,bool,bool,const CefString&,bool&) override {
    return nullptr; // No per-resource callback / filtering on the network hot path.
  }
  bool OnCertificateError(CefRefPtr<CefBrowser>,cef_errorcode_t,const CefString&,CefRefPtr<CefSSLInfo>,CefRefPtr<CefCallback>) override {
    return false; // Engine cancels certificate errors. No insecure bypass.
  }
  void permissionTestEvent(const char* event,uint64_t id){
    const auto directory=qEnvironmentVariable("SHIELD_PERMISSION_TEST");if(directory.isEmpty())return;
    QFile file(QDir(directory).filePath("permission-events.jsonl"));if(file.open(QIODevice::Append)){file.write(QJsonDocument(QJsonObject{{"event",QString::fromLatin1(event)},{"id",double(id)}}).toJson(QJsonDocument::Compact));file.write("\n");}
  }
  void cancelMediaRequests(const std::string& frameId={}){
    std::vector<CefRefPtr<CefMediaAccessCallback>> cancelled;
    for(auto it=mediaRequests_.begin();it!=mediaRequests_.end();){
      if(frameId.empty()||it->second.identifier==frameId){permissionTestEvent("cancelledOnNavigationOrClose",it->first);cancelled.push_back(it->second.callback);it=mediaRequests_.erase(it);}else ++it;
    }
    if(cancelled.empty())return;
    for(auto callback:cancelled)callback->Cancel();
    deliver([](BrowserPage& p){emit p.permissionsInvalidated();});
  }
  void resolveMedia(uint64_t id,bool allow){
    auto it=mediaRequests_.find(id);if(it==mediaRequests_.end()){if(allow)permissionTestEvent("staleApprovalRejected",id);return;}
    auto request=it->second;mediaRequests_.erase(it);
    if(allow&&!closed_.load()&&request.frame->IsValid()&&request.frame->GetURL().ToString()==request.document){
      permissionTestEvent("approved",id);request.callback->Continue(request.permissions);
    }else{permissionTestEvent("denied",id);request.callback->Cancel();}
  }
  bool OnRequestMediaAccessPermission(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,const CefString& origin,uint32_t requested,
    CefRefPtr<CefMediaAccessCallback> callback) override {
    const auto source=QString::fromStdWString(origin.ToWString());QUrl url(source);
    constexpr uint32_t supported=CEF_MEDIA_PERMISSION_DEVICE_AUDIO_CAPTURE|CEF_MEDIA_PERMISSION_DEVICE_VIDEO_CAPTURE;
    const bool secure=url.scheme()=="https"||(url.scheme()=="http"&&(url.host()=="127.0.0.1"||url.host()=="localhost"||url.host()=="::1"));
    // Desktop capture needs an actual screen/window picker, not a blanket grant.
    if(!secure||!url.userInfo().isEmpty()||!frame||!frame->IsValid()||!requested||(requested&~supported)||!mediaRequests_.empty()){callback->Cancel();return true;}
    const auto id=++mediaRequestId_;permissionTestEvent("requested",id);mediaRequests_[id]={callback,frame,frame->GetURL().ToString(),frame->GetIdentifier().ToString(),requested};
    auto self=CefRefPtr<BrowserClient>(this);auto page=page_;
    QMetaObject::invokeMethod(QCoreApplication::instance(),[self,page,source,requested,id]{
      if(!page||page->isClosing()){onCefUi([self,id]{self->resolveMedia(id,false);});return;}
      QStringList capabilities;if(requested&CEF_MEDIA_PERMISSION_DEVICE_AUDIO_CAPTURE)capabilities<<QString::fromUtf8("микрофон");if(requested&CEF_MEDIA_PERMISSION_DEVICE_VIDEO_CAPTURE)capabilities<<QString::fromUtf8("камера");
      auto* prompt=new QMessageBox(QMessageBox::Question,QString::fromUtf8("Разрешение сайта"),source+QString::fromUtf8("\n\nРазрешить: ")+capabilities.join(", ")+QString::fromUtf8("?\nТолько для этого запроса. При переходе на другую страницу запрос отменяется."),QMessageBox::Yes|QMessageBox::No,page);
      prompt->setTextFormat(Qt::PlainText);prompt->setDefaultButton(QMessageBox::No);prompt->setAttribute(Qt::WA_DeleteOnClose);
      QObject::connect(page,&BrowserPage::permissionsInvalidated,prompt,&QDialog::reject);
      QObject::connect(page,&BrowserPage::closed,prompt,&QDialog::reject);
      QObject::connect(prompt,&QDialog::finished,prompt,[self,id](int result){onCefUi([self,id,result]{self->resolveMedia(id,result==QMessageBox::Yes);});});
      QObject::connect(prompt,&QObject::destroyed,[self,id]{onCefUi([self,id]{self->permissionTestEvent("promptDestroyed",id);self->resolveMedia(id,false);});});prompt->open();
      const auto test=qEnvironmentVariable("SHIELD_PERMISSION_TEST");const auto current=QUrl(page->url());
      if(!test.isEmpty()&&current.scheme()=="http"&&current.host()=="127.0.0.1"&&current.path()=="/media-request"){
        onCefUi([self,id]{self->permissionTestEvent("promptShown",id);});
        QTimer::singleShot(250,page,[page,test,current]{if(!page)return;if(page->window()->screen()){auto* w=page->window();w->screen()->grabWindow(0,w->frameGeometry().x(),w->frameGeometry().y(),w->width(),w->height()).save(QDir(test).filePath("native-media-permission.png"));}QUrl next=current;next.setPath("/permission-after");page->open(next.toString());});
        // Exercise a late Yes after the real navigation has cancelled the request.
        // Fake hardware is enabled only for this separate loopback CI process.
        QTimer::singleShot(900,QCoreApplication::instance(),[self,id]{onCefUi([self,id]{self->resolveMedia(id,true);});});
      }
    },Qt::QueuedConnection);return true;
  }
  bool OnShowPermissionPrompt(CefRefPtr<CefBrowser>,uint64_t,const CefString& origin,uint32_t requested,
    CefRefPtr<CefPermissionPromptCallback> callback) override {
    // Unknown/unsupported capabilities fail closed; do not ask for opaque bitmasks.
    (void)requested;(void)origin;callback->Continue(CEF_PERMISSION_RESULT_DENY);return true;
  }
  bool OnPreKeyEvent(CefRefPtr<CefBrowser>,const CefKeyEvent& event,CefEventHandle,bool* shortcut) override {
    if(event.type!=KEYEVENT_RAWKEYDOWN)return false;
    const bool ctrl=event.modifiers & EVENTFLAG_CONTROL_DOWN;
    const bool alt=event.modifiers & EVENTFLAG_ALT_DOWN;
    const int key=event.windows_key_code;
    if((ctrl && (key=='T'||key=='W'||key=='L'||key=='R'||key=='D'||key=='H'||key=='J'||key=='N'||key=='F'||key==VK_OEM_PLUS||key==VK_OEM_MINUS||key=='0')) ||
       (alt && (key==VK_LEFT||key==VK_RIGHT)) || key==VK_F11 || (ctrl&&(key==VK_TAB||(key>='1'&&key<='9')))) {
      int mods=(ctrl?int(Qt::ControlModifier):0)|(alt?int(Qt::AltModifier):0)|((event.modifiers&EVENTFLAG_SHIFT_DOWN)?int(Qt::ShiftModifier):0);
      deliver([key,mods](BrowserPage& p){emit p.shortcut(key,mods);});*shortcut=true;return true;
    }
    return false;
  }
  bool OnBeforeDownload(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,const CefString&,
    CefRefPtr<CefBeforeDownloadCallback> callback) override {
    // Only a fixed loopback fixture may bypass the save dialog in the CI tour.
    const auto testDir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");const auto url=QUrl(QString::fromStdWString(item->GetURL().ToWString()));
    if(!testDir.isEmpty()&&url.scheme()=="http"&&url.host()=="127.0.0.1"&&(url.path()=="/test-download.txt"||url.path()=="/slow-download.bin")) {
      auto path=QDir::toNativeSeparators(QDir(testDir).absoluteFilePath(url.path()=="/slow-download.bin"?"fixture-slow.bin":"fixture-download.txt"));QFile trace(QDir(testDir).filePath("download-events.jsonl"));if(trace.open(QIODevice::Append)){trace.write(QJsonDocument(QJsonObject{{"beforeDownload",true},{"id",int(item->GetId())},{"destination",path},{"directoryExists",QDir(testDir).exists()}}).toJson(QJsonDocument::Compact));trace.write("\n");}callback->Continue(path.toStdWString(),false);return true;}
    callback->Continue(CefString(),true);return true;}
  void OnDownloadUpdated(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,CefRefPtr<CefDownloadItemCallback> callback) override {
    auto id=item->GetId();
    if(item->IsInProgress())downloads_[id]=callback;else downloads_.erase(id);
    auto name=QString::fromStdWString(item->GetFullPath().ToWString());
    if(name.isEmpty())name=QString::fromStdWString(item->GetURL().ToWString());
    auto received=item->GetReceivedBytes(), total=item->GetTotalBytes();bool done=item->IsComplete(),cancelled=item->IsCanceled(),paused=item->IsPaused();const bool active=item->IsInProgress();int interrupt=item->IsInterrupted()?int(item->GetInterruptReason()):0;
    const auto testDir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");if(!testDir.isEmpty()){QFile trace(QDir(testDir).filePath("download-events.jsonl"));if(trace.open(QIODevice::Append)){trace.write(QJsonDocument(QJsonObject{{"name",name},{"complete",done},{"cancelled",cancelled},{"interruptReason",interrupt},{"received",double(received)},{"total",double(total)}}).toJson(QJsonDocument::Compact));trace.write("\n");}}
    deliver([=](BrowserPage& p){if(active)p.activeDownloads_.insert(id);else p.activeDownloads_.remove(id);emit p.downloadChanged(id,name,received,total,done,cancelled,interrupt,paused);if(p.closeAfterDownloads_&&p.activeDownloads_.empty())p.shutdown();});
  }
  void pause(unsigned id,bool pause) {auto it=downloads_.find(id);if(it!=downloads_.end()){if(pause)it->second->Pause();else it->second->Resume();}}
  void cancel(unsigned id) {auto it=downloads_.find(id);if(it!=downloads_.end())it->second->Cancel();}
 private:
  QPointer<BrowserPage> page_;
  struct MediaRequest {CefRefPtr<CefMediaAccessCallback> callback;CefRefPtr<CefFrame> frame;std::string document,identifier;uint32_t permissions;};
  uint64_t mediaRequestId_=0;std::map<uint64_t,MediaRequest> mediaRequests_; // CEF UI only
  QString title_; // CEF UI thread only; copied with completed-document events.
  std::atomic<bool> closed_{false};
  CefRefPtr<BrowserClient> opener_;int openerPopupId_=-1;
  std::map<int,QPointer<BrowserPage>> pendingPopups_;
  std::map<unsigned,CefRefPtr<CefDownloadItemCallback>> downloads_; // CEF UI only
  IMPLEMENT_REFCOUNTING(BrowserClient);
};
BrowserPage::BrowserPage(CefRefPtr<CefRequestContext> context,QWidget* parent,bool adoptedPopup)
 :QWidget(parent),context_(context) {
  started_=adoptedPopup;
  loadTimer_=new QTimer(this);loadTimer_->setSingleShot(true);connect(loadTimer_,&QTimer::timeout,this,[this]{if(loading_&&!closing_){command([](auto b){b->StopLoad();});showNetworkError(url_,tr("Время ожидания истекло. Сервер не ответил за 30 секунд."));}});
  setAttribute(Qt::WA_NativeWindow);setFocusPolicy(Qt::StrongFocus);
  auto* client=new BrowserClient(this);client_=client;

}
BrowserPage::~BrowserPage() = default;
void BrowserPage::setDefaultZoom(int percent){zoom_=std::log(percent/100.0)/std::log(1.2);}
int BrowserPage::zoomPercent()const{return int(std::lround(100*std::pow(1.2,zoom_)));}
void BrowserPage::zoomBy(int step){zoom_=std::clamp(zoom_+step*0.5,-6.0,8.0);command([level=zoom_](auto b){b->GetHost()->SetZoomLevel(level);});}
void BrowserPage::resetZoom(){zoom_=0;command([](auto b){b->GetHost()->SetZoomLevel(0);});}
void BrowserPage::showEvent(QShowEvent* e) {
  QWidget::showEvent(e);
  if(started_)return; started_=true;
  CefWindowInfo info;
  info.SetAsChild(reinterpret_cast<HWND>(winId()),CefRect(0,0,int(width()*devicePixelRatioF()),int(height()*devicePixelRatioF())));
  info.runtime_style=CEF_RUNTIME_STYLE_ALLOY;
  CefBrowserSettings settings;
  if(!CefBrowserHost::CreateBrowser(info,client_,url_.toStdWString(),settings,nullptr,context_)) {
    started_=false;loading_=false;emit loadingChanged(false,false,false);emit loadFailed(tr("CEF не создал окно браузера"));
  }
}
void BrowserPage::created(CefRefPtr<CefBrowser> browser) {browser_=browser;if(closing_)shutdown();else{fit();command([level=zoom_](auto b){b->GetHost()->SetZoomLevel(level);});if(!pendingOpen_.isEmpty()){auto next=pendingOpen_;pendingOpen_.clear();open(next);}}}
void BrowserPage::beforeClose() {browser_=nullptr;emit closed();}
void BrowserPage::abortPopup(){if(browser_)return;started_=false;closing_=true;emit closed();}
void BrowserPage::showNetworkError(const QString& failed,const QString& reason,const QString& kind){if(closing_||(failed.startsWith("shield:")&&kind!="renderer"))return;loadTimer_->stop();loading_=false;emit loadingChanged(false,back_,forward_);emit loadFailed(reason);QUrl u("shield://error/");QUrlQuery q;q.addQueryItem("url",failed);q.addQueryItem("reason",reason);q.addQueryItem("kind",kind);u.setQuery(q);open(u.toString());}
void BrowserPage::open(const QString& url) {if(closing_)return;if(started_&&!browser_)pendingOpen_=url;attempted_=url;url_=url;emit addressChanged(url);command([u=url.toStdWString()](auto browser){browser->GetMainFrame()->LoadURL(u);});}
void BrowserPage::command(const std::function<void(CefRefPtr<CefBrowser>)>& f) {
  if(browser_) {auto b=browser_;onCefUi([b,f]{if(b->IsValid())f(b);});}
}
void BrowserPage::shutdown() {
  closing_=true;
  if(browser_)command([](auto b){b->GetHost()->CloseBrowser(true);});
  else if(!started_)QTimer::singleShot(0,this,[this]{emit closed();});
}
void BrowserPage::closeWhenDownloadsFinish(){closeAfterDownloads_=true;if(activeDownloads_.empty())shutdown();}
void BrowserPage::pauseDownload(unsigned id,bool pause){auto client=CefRefPtr<BrowserClient>(static_cast<BrowserClient*>(client_.get()));onCefUi([client,id,pause]{client->pause(id,pause);});}
void BrowserPage::cancelDownload(unsigned id) {auto client=CefRefPtr<BrowserClient>(static_cast<BrowserClient*>(client_.get()));onCefUi([client,id]{client->cancel(id);});}
void BrowserPage::fit() {
  command([w=int(width()*devicePixelRatioF()),h=int(height()*devicePixelRatioF())](auto b){
    SetWindowPos(b->GetHost()->GetWindowHandle(),nullptr,0,0,w,h,SWP_NOZORDER|SWP_NOACTIVATE);
  });
}
void BrowserPage::resizeEvent(QResizeEvent* e){QWidget::resizeEvent(e);fit();}
void BrowserPage::focusInEvent(QFocusEvent* e){QWidget::focusInEvent(e);command([](auto b){b->GetHost()->SetFocus(true);});}
}
