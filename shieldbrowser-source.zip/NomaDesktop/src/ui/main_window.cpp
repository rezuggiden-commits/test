#include <windows.h>
#include <algorithm>
#include <QApplication>
#include <QCloseEvent>
#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenu>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPushButton>
#include <QSaveFile>
#include <QShortcut>
#include <QStatusBar>
#include <QToolBar>
#include <QToolButton>
#include <QUrl>
#include <QVBoxLayout>
#include <QTimer>
#include <QPointer>
#include <QSettings>
#include <QCompleter>
#include <QStringListModel>
#include <QCheckBox>
#include <QComboBox>
#include <QSpinBox>
#include <QScrollArea>
#include <QNetworkProxy>
#include <QNetworkProxyFactory>
#include <limits>
#include <QScreen>
#include <QWindow>
#include <QKeyEvent>
#include <QStyle>
#include <QProgressBar>
#include <QJsonArray>
#include <QUrlQuery>
#include <QMouseEvent>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include "include/cef_cookie.h"
#include "include/cef_request_context_handler.h"
#include "shield/main_window.h"
#include "shield/browser_tabs.h"
#include "include/cef_values.h"
#include "shield/core/navigation.h"
#include "shield/core/session_restore.h"
#include "shield/brand.h"
#include "shield/cef_task.h"
#include "shield/internal_pages.h"
namespace shield {
namespace {
const QString homeUrl="shield://newtab/";
bool home(const QString& url){return url.startsWith("shield://newtab")||url=="about:blank";}
QIcon icon(const QString& name){return QIcon(":/icons/"+name+(qApp->property("lightTheme").toBool()?"-dark":"")+".svg");}
QToolButton* tool(QToolBar* bar,const QString& label,const QString& name){
 auto* b=new QToolButton;b->setProperty("iconName",name);b->setIcon(icon(name));b->setIconSize(QSize(19,19));b->setToolTip(label);b->setAccessibleName(label);b->setFixedHeight(36);bar->addWidget(b);return b;
}
class PanelDialog final:public QDialog {
 public:explicit PanelDialog(QWidget* p):QDialog(p,Qt::Dialog|Qt::FramelessWindowHint){setWindowModality(Qt::WindowModal);}
 protected:void showEvent(QShowEvent* e) override {QDialog::showEvent(e);if(!qApp->property("reduceMotion").toBool()){setWindowOpacity(0);auto* fade=new QPropertyAnimation(this,"windowOpacity",this);fade->setDuration(140);fade->setStartValue(0.);fade->setEndValue(1.);fade->start(QAbstractAnimation::DeleteWhenStopped);}}
 void mousePressEvent(QMouseEvent* e) override {if(e->button()==Qt::LeftButton&&e->position().y()<72&&windowHandle())windowHandle()->startSystemMove();else QDialog::mousePressEvent(e);}
};
QDialog* dialog(QWidget* parent,const QString& title,const QString& subtitle,QVBoxLayout*& layout){
 auto* d=new PanelDialog(parent);d->setAttribute(Qt::WA_DeleteOnClose);d->setWindowTitle(title+" — Noma");d->resize(680,520);
 layout=new QVBoxLayout(d);layout->setContentsMargins(28,22,28,24);layout->setSpacing(16);
 auto* row=new QHBoxLayout;auto* h=new QLabel(title);h->setObjectName("dialogTitle");h->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);row->addWidget(h,1);auto* close=makeCloseButton(d);close->setToolTip(QString::fromUtf8("Закрыть"));row->addWidget(close);QObject::connect(close,&QToolButton::clicked,d,&QDialog::close);layout->addLayout(row);
 if(!subtitle.isEmpty()){auto* p=new QLabel(subtitle);p->setObjectName("dialogSubtitle");p->setWordWrap(true);p->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);layout->addWidget(p);}
 return d;
}
void darkTitle(QWidget* w){
 auto lib=LoadLibraryW(L"dwmapi.dll");if(!lib)return;
 using SetAttribute=HRESULT(WINAPI*)(HWND,DWORD,LPCVOID,DWORD);
 auto fn=reinterpret_cast<SetAttribute>(GetProcAddress(lib,"DwmSetWindowAttribute"));
 if(fn){BOOL dark=!qApp->property("lightTheme").toBool();fn(reinterpret_cast<HWND>(w->winId()),20,&dark,sizeof(dark));}
 FreeLibrary(lib);
}
QString displayAddress(const QString& u){if(QUrl(u).scheme()=="shield"&&QUrl(u).host()=="error")return QUrlQuery(QUrl(u)).queryItemValue("url");return home(u)?QString{}:u;}
}
MainWindow::MainWindow(CefRefPtr<CefRequestContext> context,QString profile,bool privateMode,QString initialUrl)
 :context_(context),privateMode_(privateMode),profile_(std::move(profile)),
 storageWorker_(new QObject),storage_(std::make_shared<std::unique_ptr<core::Storage>>()) {
 setWindowFlags(Qt::Window|Qt::FramelessWindowHint|Qt::WindowMinMaxButtonsHint);
 setAttribute(Qt::WA_DeleteOnClose);resize(1280,850);setMinimumSize(760,480);
 if(!(qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST"))&&screen()){auto a=screen()->availableGeometry();resize(std::min(1280,a.width()),std::min(850,a.height()));move(a.topLeft());}setWindowTitle("Noma");
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);
 const QString theme=prefs.value("theme","dark").toString();
 if(!registerInternalPages(context_))qFatal("Noma internal pages registration failed");
 setInternalSearch(prefs.value("searchProvider","Google").toString().toStdString());
 const auto proxy=prefs.value("proxy").toString();const auto proxyMode=prefs.value("proxyMode","system").toString();auto ctx=context_;onCefUi([ctx,proxy,proxyMode]{auto d=CefDictionaryValue::Create();d->SetString("mode",proxyMode.toStdString());if(proxyMode=="fixed_servers")d->SetString("server",proxy.toStdString());auto v=CefValue::Create();v->SetDictionary(d);CefString error;ctx->SetPreference("proxy",v,error);});
 storageWorker_->moveToThread(&storageThread_);connect(&storageThread_,&QThread::finished,storageWorker_,&QObject::deleteLater);storageThread_.start();
 auto holder=storage_;const auto path=privateMode_?QString(":memory:"):QDir(profile_).filePath("browser.sqlite");
 QMetaObject::invokeMethod(storageWorker_,[holder,path]{try{*holder=std::make_unique<core::Storage>(path.toUtf8().toStdString());}catch(...){}},Qt::QueuedConnection);
 tabs_=new BrowserTabs(this,privateMode_);setCentralWidget(tabs_);
 auto* bar=new QToolBar;bar->setObjectName("navigation");bar->setMovable(false);tabs_->setNavigation(bar);
 back_=tool(bar,tr("Назад · Alt+←"),"back");forward_=tool(bar,tr("Вперёд · Alt+→"),"forward");reload_=tool(bar,tr("Обновить · Ctrl+R"),"reload");auto* homeButton=tool(bar,tr("Стартовая страница"),"home");
 address_=new QLineEdit;address_->setObjectName("address");address_->setAccessibleName(tr("Адрес или поисковый запрос"));address_->setPlaceholderText(tr("Поиск или адрес сайта"));address_->setMinimumWidth(200);address_->installEventFilter(this);bar->addWidget(address_);
 suggestions_=new QStringListModel(this);auto* completer=new QCompleter(suggestions_,this);completer->setCaseSensitivity(Qt::CaseInsensitive);completer->setFilterMode(Qt::MatchContains);completer->setMaxVisibleItems(7);address_->setCompleter(completer);connect(completer,qOverload<const QString&>(&QCompleter::activated),this,[this](const QString& value){address_->setText(value);navigate();});
 shield_=tool(bar,tr("Подключение и прокси"),"shield");shield_->setObjectName("shieldButton");shield_->setToolButtonStyle(Qt::ToolButtonIconOnly);
 bookmark_=tool(bar,tr("Сохранить в закладки · Ctrl+D"),"bookmark");auto* downloads=tool(bar,tr("Загрузки · Ctrl+J"),"download");
 menuButton_=tool(bar,tr("Меню браузера"),"menu");menu_=new QMenu(this);menuButton_->setMenu(menu_);menuButton_->setPopupMode(QToolButton::InstantPopup);
 auto action=[this](const QString& label,const std::function<void()>& f){return menu_->addAction(label,this,f);};
 action(tr("Новая вкладка"),[this]{newTab();});action(tr("Приватное окно"),[this]{key('N',int(Qt::ControlModifier|Qt::ShiftModifier));});action(tr("Вернуть закрытую вкладку"),[this]{key('T',int(Qt::ControlModifier|Qt::ShiftModifier));});menu_->addSeparator();
 action(tr("История"),[this]{showHistory();});action(tr("Закладки"),[this]{showBookmarks();});action(tr("Загрузки"),[this]{showDownloads();});menu_->addSeparator();
 action(tr("Найти на странице"),[this]{showFind();});auto* zoom=menu_->addMenu(tr("Масштаб"));zoom->addAction(tr("Увеличить"),this,[this]{key(VK_OEM_PLUS,int(Qt::ControlModifier));});zoom->addAction(tr("Уменьшить"),this,[this]{key(VK_OEM_MINUS,int(Qt::ControlModifier));});zoom->addAction(tr("Сбросить до 100%"),this,[this]{key('0',int(Qt::ControlModifier));});
 action(tr("На весь экран"),[this]{key(VK_F11,0);});menu_->addSeparator();
 action(tr("Настройки"),[this]{showSettings();}); menu_->addSeparator();action(tr("О браузере"),[this]{QMessageBox::about(this,tr("О Noma"),tr("Noma %1\nСобственный интерфейс C++ / Qt · Chromium / CEF 152\n\nЭта ветка ещё не выпущена. Проверки совместимости, обновления и установщика не завершены.").arg(SHIELD_VERSION));});action(tr("Закрыть окно"),[this]{close();});
 status_=new QLabel(tr("Новая вкладка"));statusBar()->setSizeGripEnabled(false);statusBar()->addWidget(status_,1);statusBar()->hide();
 findBar_=new QWidget;findBar_->setObjectName("findBar");auto* findLayout=new QHBoxLayout(findBar_);findLayout->setContentsMargins(16,6,16,6);findLayout->addStretch();find_=new QLineEdit;find_->setPlaceholderText(tr("Найти на странице"));find_->setMinimumWidth(260);find_->installEventFilter(this);findLayout->addWidget(find_);findCount_=new QLabel;findCount_->setMinimumWidth(90);findLayout->addWidget(findCount_);
 auto findButton=[&](const QString& name,const QString& label){auto* b=new QToolButton;b->setProperty("iconName",name);b->setIcon(uiIcon(name));b->setToolTip(label);findLayout->addWidget(b);return b;};
 auto* previous=findButton("arrow-up",tr("Предыдущее совпадение"));auto* next=findButton("arrow-down",tr("Следующее совпадение"));auto* dismiss=findButton("close",tr("Закрыть поиск · Esc"));
 tabs_->setFindBar(findBar_);findBar_->hide();connect(find_,&QLineEdit::textEdited,this,[this]{findNext();});connect(find_,&QLineEdit::returnPressed,this,[this]{findNext();});connect(next,&QToolButton::clicked,this,[this]{findNext();});connect(previous,&QToolButton::clicked,this,[this]{findNext(false);});connect(dismiss,&QToolButton::clicked,this,[this]{findBar_->hide();withCurrent([](auto b){b->GetHost()->StopFinding(true);});if(current())current()->setFocus();});
 QVBoxLayout* dl;downloadsDialog_=panel(tr("Загрузки"),tr("Файлы, которые вы сохраняете из интернета."),dl);
 downloadsDialog_->setProperty("keepAlive",true);downloadsDialog_->hide();
 downloadsEmpty_=new QLabel(tr("Здесь пока пусто\nСкачанные файлы появятся в этом списке."));downloadsEmpty_->setObjectName("emptyState");downloadsEmpty_->setAlignment(Qt::AlignCenter);dl->addWidget(downloadsEmpty_,1);
 downloadsList_=new QListWidget;dl->addWidget(downloadsList_,1);downloadsList_->hide();auto* downloadDone=new QPushButton(tr("Готово"));downloadDone->setObjectName("primaryButton");dl->addWidget(downloadDone,0,Qt::AlignRight);connect(downloadDone,&QPushButton::clicked,downloadsDialog_,&QWidget::hide);loadDownloadHistory();
 suggestNetwork_=new QNetworkAccessManager(this);suggestTimer_=new QTimer(this);suggestTimer_->setSingleShot(true);suggestTimer_->setInterval(220);
 QNetworkProxyFactory::setUseSystemConfiguration(true);
 if(proxyMode=="direct")suggestNetwork_->setProxy(QNetworkProxy::NoProxy);
 else if(proxyMode=="fixed_servers"){QUrl u(proxy);if(u.scheme()!="https")suggestNetwork_->setProxy(QNetworkProxy(u.scheme()=="socks5"?QNetworkProxy::Socks5Proxy:QNetworkProxy::HttpProxy,u.host(),quint16(u.port())));}

 connect(suggestTimer_,&QTimer::timeout,this,&MainWindow::loadSearchSuggestions);
 connect(address_,&QLineEdit::textEdited,this,[this]{editingAddress_=true;++suggestionGeneration_;if(suggestReply_)suggestReply_->abort();suggestions_->setStringList(localSuggestions_);if(!privateMode_)suggestTimer_->start();});
 connect(address_,&QLineEdit::returnPressed,this,&MainWindow::navigate);connect(back_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoBack();});});connect(forward_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoForward();});});connect(reload_,&QToolButton::clicked,this,[this]{auto* p=current();if(p&&QUrl(p->url()).scheme()=="shield"&&QUrl(p->url()).host()=="error"){p->open(displayAddress(p->url()));return;}withCurrent([](auto b){b->IsLoading()?b->StopLoad():b->Reload();});});connect(homeButton,&QToolButton::clicked,this,[this]{if(current())current()->open(homeUrl);});connect(bookmark_,&QToolButton::clicked,this,&MainWindow::addBookmark);connect(downloads,&QToolButton::clicked,this,&MainWindow::showDownloads);connect(shield_,&QToolButton::clicked,this,&MainWindow::showProxy);
 connect(tabs_,&BrowserTabs::tabCloseRequested,this,&MainWindow::closeTab);connect(tabs_,&BrowserTabs::newTabRequested,this,[this]{newTab();});connect(tabs_,&BrowserTabs::currentChanged,this,[this](int){editingAddress_=false;refreshChrome();saveSession();});
 QStringList sequences={"Ctrl+T","Ctrl+W","Ctrl+Shift+T","Ctrl+L","Ctrl+R","Alt+Left","Alt+Right","Ctrl+D","Ctrl+H","Ctrl+J","Ctrl+F","Ctrl+Shift+N","Ctrl++","Ctrl+-","Ctrl+0","Ctrl+Tab","Ctrl+Shift+Tab","F11"};
 for(int i=1;i<=9;++i)sequences<<QString("Ctrl+%1").arg(i);
 for(const auto& s:sequences){auto* shortcut=new QShortcut(QKeySequence(s),this);connect(shortcut,&QShortcut::activated,this,[this,s]{if(s=="Ctrl++")key(VK_OEM_PLUS,int(Qt::ControlModifier));else if(s=="Ctrl+-")key(VK_OEM_MINUS,int(Qt::ControlModifier));else{auto c=QKeySequence(s)[0];int k=int(c.key());if(k==Qt::Key_Left)k=VK_LEFT;if(k==Qt::Key_Right)k=VK_RIGHT;if(k==Qt::Key_Tab)k=VK_TAB;if(k==Qt::Key_F11)k=VK_F11;key(k,int(c.keyboardModifiers()));}});}
 applyTheme(qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")?theme:"dark");
 restorePending_=initialUrl.isEmpty()&&!privateMode_&&prefs.value("restoreSession",true).toBool()&&qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST");
 newTab(privateMode_?homeUrl:initialUrl.isEmpty()?qEnvironmentVariable("SHIELD_START_URL",homeUrl):initialUrl);refreshSuggestions();
 if(restorePending_)restoreSession();
}
void MainWindow::restoreSession(){
 const auto revision=tabRevision_;QPointer<MainWindow> owner=this;QPointer<BrowserPage> initial=current();
 // Loading must precede the first save. Otherwise the initial empty tab can
 // overwrite the previous session while SQLite's worker reply is in flight.
 auto h=storage_;QMetaObject::invokeMethod(storageWorker_,[h,owner,initial,revision]{
  core::SessionRestorePlan plan;bool ok=true;
  try{if(!*h)throw std::runtime_error("storage unavailable");plan=core::planSessionRestore((*h)->loadSession());}catch(...){ok=false;}
  QMetaObject::invokeMethod(qApp,[owner,initial,revision,plan=std::move(plan),ok]{
   if(!owner||owner->closing_)return;
   auto eligible=[owner,initial,revision]{return owner&&initial&&owner->tabRevision_==revision&&owner->tabs_->count()==1&&owner->current()==initial&&home(initial->url());};
   auto finish=[owner,initial,revision,plan,eligible](bool restore,bool prompted){
    if(!owner||owner->closing_)return;
    bool applied=restore&&eligible()&&!plan.tabs.empty();
    if(applied){for(const auto& tab:plan.tabs)owner->newTab(QString::fromStdString(tab.url),false);
     owner->tabs_->setCurrentIndex(1+int(plan.active_index));
     int i=owner->tabs_->indexOf(initial);if(i>=0)owner->closeTab(i);}
    owner->restorePending_=false;owner->saveSession(false);owner->writeSessionTestProof(prompted,applied);
   };
   if(!ok){owner->status_->setText(tr("Не удалось прочитать предыдущую сессию. Она не была перезаписана."));return;}
   if(!eligible()){finish(false,false);return;}
   if(plan.requires_confirmation){
    auto* prompt=new QMessageBox(QMessageBox::Question,tr("Восстановить вкладки?"),tr("Предыдущий сеанс завершился неожиданно. Восстановить %1 вкладок? Если сбой вызвал сайт, можно начать с новой вкладки.").arg(plan.tabs.size()),QMessageBox::Yes|QMessageBox::No,owner);
    prompt->setObjectName("sessionRecoveryPrompt");prompt->setDefaultButton(QMessageBox::No);prompt->setAttribute(Qt::WA_DeleteOnClose);
    connect(prompt,&QDialog::finished,owner,[finish](int result){finish(result==QMessageBox::Yes,true);});prompt->open();
    // Dedicated CI hook; never auto-answers prompts in normal use.
    const auto test=qEnvironmentVariable("SHIELD_SESSION_TEST");const auto choice=qEnvironmentVariable("SHIELD_SESSION_CHOICE");
    if(!test.isEmpty()&&(choice=="accept"||choice=="decline"))QTimer::singleShot(200,prompt,[prompt,choice]{prompt->done(choice=="accept"?QMessageBox::Yes:QMessageBox::No);});
   }else finish(true,false);
  },Qt::QueuedConnection);
 },Qt::QueuedConnection);
}
void MainWindow::writeSessionTestProof(bool prompted,bool restored){
 const auto directory=qEnvironmentVariable("SHIELD_SESSION_TEST");if(directory.isEmpty())return;
 // Delay evidence until CEF has committed the active tab, but never activate the
 // background tabs to make a lazy-restore test pass by loading all of them.
 auto attempts=std::make_shared<int>(0);auto* timer=new QTimer(this);timer->setInterval(100);
 connect(timer,&QTimer::timeout,this,[this,timer,attempts,directory,prompted,restored]{
  auto* page=current();if(page&&page->property("completedUrl").toString()==page->url()){
   QJsonArray urls;int created=0;for(int i=0;i<tabs_->count();++i){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));urls.append(p->url());if(p->hasBrowser())++created;}
   QSaveFile file(QDir(directory).filePath("session-result.json"));if(file.open(QIODevice::WriteOnly)){file.write(QJsonDocument(QJsonObject{{"prompted",prompted},{"restored",restored},{"tabs",urls},{"activeIndex",tabs_->currentIndex()},{"activeUrl",page->url()},{"createdBrowsers",created}}).toJson());file.commit();}timer->stop();timer->deleteLater();
  }else if(++*attempts>=150){timer->stop();timer->deleteLater();}
 });timer->start();
}
MainWindow::~MainWindow(){auto holder=storage_;QMetaObject::invokeMethod(storageWorker_,[holder]{holder->reset();},Qt::BlockingQueuedConnection);storageThread_.quit();storageThread_.wait();}
void MainWindow::store(std::function<void(core::Storage&)> f){auto h=storage_;QPointer<MainWindow> g=this;QMetaObject::invokeMethod(storageWorker_,[h,f=std::move(f),g]{try{if(!*h)throw std::runtime_error("storage unavailable");f(**h);}catch(...){QMetaObject::invokeMethod(qApp,[g]{if(g)g->status_->setText(tr("Не удалось сохранить данные. Проверьте доступ к профилю."));},Qt::QueuedConnection);}},Qt::QueuedConnection);}
QIcon MainWindow::uiIcon(const QString& name)const{return QIcon(":/icons/"+name+(property("lightTheme").toBool()?"-dark":"")+".svg");}
BrowserPage* MainWindow::current()const{return qobject_cast<BrowserPage*>(tabs_->currentWidget());}
void MainWindow::withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>& f){if(current())current()->command(f);}
void MainWindow::refreshChrome(){
 auto* p=current();if(!p)return;
 if(!editingAddress_||!address_->hasFocus())address_->setText(displayAddress(p->url()));
 back_->setEnabled(p->canGoBack());forward_->setEnabled(p->canGoForward());reload_->setProperty("iconName",p->loading()?"stop":"reload");reload_->setIcon(uiIcon(p->loading()?"stop":"reload"));reload_->setToolTip(p->loading()?tr("Остановить загрузку"):tr("Обновить · Ctrl+R"));tabs_->setLoading(p->loading());
 int i=tabs_->currentIndex();setWindowTitle(tabs_->tabText(i)+" — Noma"+(privateMode_?tr(" · Приватно"):QString{}));
 bookmark_->setEnabled(QUrl(p->url()).scheme()=="http"||QUrl(p->url()).scheme()=="https");bookmark_->setProperty("iconName","bookmark");bookmark_->setIcon(uiIcon("bookmark"));
}
void MainWindow::newTab(const QString& requested,bool activate){
 if(closing_)return;++tabRevision_;QString url=home(requested)||requested.isEmpty()?homeUrl:requested;auto* p=new BrowserPage(context_);p->setProperty("nomaOwner",QVariant::fromValue(static_cast<QObject*>(this)));pages_.insert(p);QSettings pagePrefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);p->setDefaultZoom(std::clamp(pagePrefs.value("defaultZoom",100).toInt(),50,200));p->open(url);
 connect(p,&BrowserPage::contentFocused,this,[this,p]{if(p==current()){editingAddress_=false;address_->clearFocus();refreshChrome();}});
 connect(p,&BrowserPage::findResult,this,[this,p](int count,int active){if(p!=current())return;findCount_->setProperty("matches",count);findCount_->setText(count?tr("%1 из %2").arg(active).arg(count):tr("Не найдено"));});
 connect(p,&BrowserPage::titleChanged,this,[this,p](const QString& text){int i=tabs_->indexOf(p);if(i>=0){tabs_->setTabText(i,text.isEmpty()?tr("Новая вкладка"):text.left(40));tabs_->setTabToolTip(i,text);if(p==current())refreshChrome();}});
 connect(p,&BrowserPage::addressChanged,this,[this,p](const QString&){if(p==current())refreshChrome();saveSession();});
 connect(p,&BrowserPage::loadingChanged,this,[this,p](bool loading,bool,bool){if(p==current()){refreshChrome();status_->setText(loading?tr("Загрузка…"):home(p->url())?tr("Новая вкладка"):tr("Готово"));}});
 connect(p,&BrowserPage::loadFailed,this,[this,p](const QString& error){if(p==current())status_->setText(tr("Не удалось загрузить страницу: ")+error);});
 connect(p,&BrowserPage::completed,this,[this,p](const QString& url,const QString& title){p->setProperty("completedUrl",url);
  if(!privateMode_&&(url.startsWith("http://")||url.startsWith("https://"))){auto u=url.toUtf8().toStdString(),t=title.toUtf8().toStdString();auto now=QDateTime::currentMSecsSinceEpoch();store([=](auto& db){db.recordVisit(u,t,now);});refreshSuggestions();}
  const auto proof=qEnvironmentVariable("SHIELD_TEST_PROOF");if(!proof.isEmpty()&&QUrl(url).host()=="127.0.0.1"){QSaveFile f(proof);if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(QJsonObject{{"url",url},{"title",title},{"cefLoadCompleted",true}}).toJson());f.commit();}}
  if(!qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&QUrl(url).host()=="127.0.0.1"&&!property("downloadFixtureStarted").toBool()){
   setProperty("downloadFixtureStarted",true);
   QTimer::singleShot(150,this,[this,p]{if(!pages_.contains(p))return;p->command([](auto b){CefMouseEvent event;event.x=80;event.y=30;b->GetHost()->SendMouseClickEvent(event,MBT_LEFT,false,1);b->GetHost()->SendMouseClickEvent(event,MBT_LEFT,true,1);});});
   const auto downloadUrl=qEnvironmentVariable("SHIELD_DOWNLOAD_TEST_URL");p->command([downloadUrl](auto b){b->GetHost()->StartDownload(downloadUrl.toStdWString());QUrl slow(downloadUrl);slow.setPath("/slow-download.bin");b->GetHost()->StartDownload(slow.toString().toStdWString());});
   QTimer::singleShot(2200,this,[this,p]{if(pages_.contains(p)){setProperty("closedDownloadingTab",p->hasActiveDownloads());int index=tabs_->indexOf(p);if(index>=0)closeTab(index);}});
  }
  if(home(url)&&!(qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST")))runUiChecks();
 });
 connect(p,&BrowserPage::popupRequested,this,[this](const QString& u){newTab(u);});connect(p,&BrowserPage::shortcut,this,&MainWindow::key);
 connect(p,&BrowserPage::downloadChanged,this,[this,p](unsigned id,const QString& name,qint64 received,qint64 total,bool done,bool cancelled,int interrupted,bool paused){updateDownload(p,id,name,received,total,done,cancelled,interrupted,paused);});
 connect(p,&BrowserPage::closed,this,[this,p]{int i=tabs_->indexOf(p);if(i>=0)tabs_->removeTab(i);pages_.erase(p);p->deleteLater();if(closing_&&pages_.empty())QTimer::singleShot(0,this,&QWidget::close);});
 int i=tabs_->addTab(p,home(url)?tr("Новая вкладка"):QUrl(url).host());if(activate)tabs_->setCurrentIndex(i);refreshChrome();saveSession();
 if(activate&&home(url))QTimer::singleShot(80,this,[this,p]{if(p==current()){address_->clear();address_->setFocus();}});
}
void MainWindow::adoptPopup(BrowserPage* p){
 if(!p||pages_.contains(p))return;
 p->setProperty("nomaOwner",QVariant::fromValue(static_cast<QObject*>(this)));pages_.insert(p);
 connect(p,&BrowserPage::downloadChanged,this,[this,p](unsigned id,const QString& name,qint64 received,qint64 total,bool done,bool cancelled,int interrupted,bool paused){updateDownload(p,id,name,received,total,done,cancelled,interrupted,paused);});
 connect(p,&BrowserPage::closed,this,[this,p]{pages_.erase(p);if(closing_&&pages_.empty())QTimer::singleShot(0,this,&QWidget::close);});
}
void MainWindow::updateDownload(BrowserPage* p,unsigned id,const QString& name,qint64 received,qint64 total,bool done,bool cancelled,int interrupted,bool paused){
 downloadsEmpty_->hide();downloadsList_->show();QListWidgetItem* item=nullptr;
 for(int i=0;i<downloadsList_->count();++i){auto* row=downloadsList_->item(i);if(row->data(Qt::UserRole).toUInt()==id&&row->data(Qt::UserRole+1).value<quintptr>()==reinterpret_cast<quintptr>(p)){item=row;break;}}
 bool newlyComplete=done&&(!item||!item->data(Qt::UserRole+3).toBool());
 if(!item){item=new QListWidgetItem(downloadsList_);item->setData(Qt::UserRole,id);item->setData(Qt::UserRole+1,QVariant::fromValue(reinterpret_cast<quintptr>(p)));}
 auto size=[this](qint64 n){return n<1024?tr("%1 Б").arg(n):n<1048576?tr("%1 КБ").arg(n/1024.0,0,'f',1):tr("%1 МБ").arg(n/1048576.0,0,'f',1);};
 const QString state=paused?tr("Приостановлено"):interrupted?tr("Прервано · код %1").arg(interrupted):done?tr("Завершено · %1").arg(size(received)):cancelled?tr("Отменено"):total>0?size(received)+" / "+size(total):tr("Получено %1").arg(size(received));
 item->setSizeHint(QSize(0,160));auto* card=downloadsList_->itemWidget(item);
 if(!card){
  card=new QWidget;auto* box=new QVBoxLayout(card);box->setContentsMargins(10,10,10,10);box->setSpacing(8);
  auto* title=new QLabel;title->setTextFormat(Qt::PlainText);title->setObjectName("fileTitle");title->setWordWrap(true);box->addWidget(title);
  auto* sub=new QLabel;sub->setObjectName("fileState");box->addWidget(sub);
  auto* progress=new QProgressBar;progress->setObjectName("fileProgress");progress->setTextVisible(false);progress->setFixedHeight(4);box->addWidget(progress);
  auto* controls=new QHBoxLayout;controls->setSpacing(6);box->addLayout(controls);
  auto* pause=new QPushButton(tr("Пауза"));pause->setObjectName("filePause");controls->addWidget(pause);
  connect(pause,&QPushButton::clicked,this,[this,p,id,item]{if(pages_.contains(p))p->pauseDownload(id,!item->data(Qt::UserRole+4).toBool());});
  auto* open=new QPushButton(tr("Открыть"));open->setObjectName("fileOpen");controls->addWidget(open);
  connect(open,&QPushButton::clicked,this,[this,item]{const auto path=item->data(Qt::UserRole+2).toString();if(!QFileInfo(path).isFile()){QMessageBox::information(this,tr("Файл не найден"),tr("Файл перемещён или удалён."));return;}if(QMessageBox::question(this,tr("Открыть скачанный файл?"),QFileInfo(path).fileName()+tr("\n\nNoma не проверяет файлы антивирусом. Открывайте только файлы из источников, которым доверяете."),QMessageBox::Yes|QMessageBox::No,QMessageBox::No)==QMessageBox::Yes)QDesktopServices::openUrl(QUrl::fromLocalFile(path));});
  auto* action=new QPushButton(tr("Отменить"));action->setObjectName("fileAction");controls->addWidget(action);
  connect(action,&QPushButton::clicked,this,[this,p,id,item]{if(item->data(Qt::UserRole+3).toBool())QDesktopServices::openUrl(QUrl::fromLocalFile(QFileInfo(item->data(Qt::UserRole+2).toString()).absolutePath()));else if(pages_.contains(p))p->cancelDownload(id);});
  controls->addStretch();downloadsList_->setItemWidget(item,card);
 }
 card->findChild<QLabel*>("fileTitle")->setText(QFileInfo(name).fileName());card->findChild<QLabel*>("fileState")->setText(state);
 auto* progress=card->findChild<QProgressBar*>("fileProgress");progress->setRange(0,total>0?100:0);if(total>0)progress->setValue(int(double(received)*100/double(total)));progress->setVisible(!done&&!cancelled&&!interrupted);
 auto* action=card->findChild<QPushButton*>("fileAction");action->setText(interrupted?tr("Прервано"):done?tr("В папке"):tr("Отменить"));action->setEnabled(!cancelled&&!interrupted);
 auto* pause=card->findChild<QPushButton*>("filePause");pause->setText(paused?tr("Продолжить"):tr("Пауза"));pause->setVisible(!done&&!cancelled&&!interrupted);
 card->findChild<QPushButton*>("fileOpen")->setVisible(done);item->setToolTip(name);item->setData(Qt::UserRole+2,name);item->setData(Qt::UserRole+3,done);item->setData(Qt::UserRole+4,paused);item->setData(Qt::UserRole+5,received);
 if(newlyComplete&&p&&!privateMode_)saveDownloadHistory();
 if(p&&!qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&QFileInfo(name).fileName()=="fixture-slow.bin"){
  if(done){setProperty("slowDownloadDone",true);QTimer::singleShot(500,this,&MainWindow::runUiChecks);}
  if(paused){setProperty("pauseObserved",true);QPointer<BrowserPage> guard=p;QTimer::singleShot(500,this,[guard,id]{if(guard)guard->pauseDownload(id,false);});}
  else if(property("pauseObserved").toBool()&&!done)setProperty("resumeObserved",true);
  if(received>32768&&!done&&!cancelled&&!interrupted&&!property("pauseRequested").toBool()){setProperty("pauseRequested",true);pause->click();}
 }
}
void MainWindow::saveDownloadHistory(){
 if(privateMode_)return;QJsonArray records;QSet<QString> seen;
 for(int i=downloadsList_->count()-1;i>=0&&records.size()<500;--i){auto* item=downloadsList_->item(i);if(!item->data(Qt::UserRole+3).toBool())continue;const auto path=item->data(Qt::UserRole+2).toString();if(seen.contains(path))continue;seen.insert(path);records.append(QJsonObject{{"path",path},{"bytes",double(item->data(Qt::UserRole+5).toLongLong())}});}
 QSaveFile file(QDir(profile_).filePath("downloads.json"));if(file.open(QIODevice::WriteOnly)){file.write(QJsonDocument(records).toJson(QJsonDocument::Compact));file.commit();}
}
void MainWindow::loadDownloadHistory(){
 if(privateMode_)return;QFile file(QDir(profile_).filePath("downloads.json"));if(!file.open(QIODevice::ReadOnly)||file.size()>1048576)return;auto records=QJsonDocument::fromJson(file.readAll()).array();unsigned id=0;
 for(int index=int(records.size())-1;index>=0&&id<500;--index){auto row=records[index].toObject();const auto path=row.value("path").toString();if(path.size()>32768||!QFileInfo(path).isAbsolute())continue;const auto bytes=std::clamp(row.value("bytes").toDouble(),0.0,9e15);updateDownload(nullptr,++id,path,qint64(bytes),qint64(bytes),true,false,0,false);}
 setProperty("downloadHistoryRestored",id>0);
}
void MainWindow::navigate(){
 editingAddress_=false;auto text=address_->text().trimmed();if(text.isEmpty())return;
 if(!text.contains(' ')&&!text.startsWith("shield:")&&!text.startsWith("about:")&&(text.contains('.')||text.contains("://"))){QUrl u(text.contains("://")?text:"https://"+text);if(!u.host().isEmpty())text=QString::fromLatin1(u.toEncoded(QUrl::FullyEncoded));}
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);
 core::NavigationOptions options;const auto provider=prefs.value("searchProvider","Google").toString();
 if(provider=="Bing")options.search_prefix="https://www.bing.com/search?q=";
 else if(provider=="Яндекс")options.search_prefix="https://yandex.ru/search/?text=";
 else if(provider=="DuckDuckGo")options.search_prefix="https://duckduckgo.com/?q=";
 auto result=core::classifyNavigation(text.toUtf8().toStdString(),options);
 if(result.kind==core::NavigationKind::Internal){QString u=QString::fromStdString(result.url);if(u=="shield://history"){showHistory();return;}if(u=="shield://bookmarks"){showBookmarks();return;}if(u=="shield://settings"){showSettings();return;}if(current())current()->open(homeUrl);}
 else if(result.kind==core::NavigationKind::Web||result.kind==core::NavigationKind::Search){if(current())current()->open(QString::fromStdString(result.url));}
 else{status_->setText(tr("Адрес отклонён: поддерживаются HTTP(S)-сайты и поиск."));return;}
 if(current())current()->setFocus();address_->clearFocus();
}
void MainWindow::closeTab(int i){++tabRevision_;auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));if(!p)return;closedTabs_.push_back(home(p->url())?homeUrl:displayAddress(p->url()));if(closedTabs_.size()>30)closedTabs_.removeFirst();tabs_->removeTab(i);p->hide();p->closeWhenDownloadsFinish();if(!tabs_->count()&&!closing_)newTab();saveSession();}
void MainWindow::saveSession(bool clean){if(privateMode_||closing_||restorePending_)return;core::SessionSnapshot s;s.clean_shutdown=clean;s.active_index=0;for(int i=0;i<tabs_->count();++i){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));auto url=home(p->url())?homeUrl:displayAddress(p->url());if(!core::isPersistableUrl(url.toStdString()))continue;if(i==tabs_->currentIndex())s.active_index=s.tabs.size();s.tabs.push_back({url.toStdString(),tabs_->tabText(i).toStdString(),false});}store([s](auto& db){db.saveSession(s);});}
void MainWindow::closeEvent(QCloseEvent* e){if(pages_.empty()){if(!privateMode_&&!restorePending_)store([](auto& db){db.markSessionClean(true);});e->accept();return;}e->ignore();if(closing_)return;bool active=false;for(auto* p:pages_)active|=p->hasActiveDownloads();if(active&&QMessageBox::question(this,tr("Идут загрузки"),tr("Закрыть окно и отменить незавершённые загрузки?"),QMessageBox::Yes|QMessageBox::No,QMessageBox::No)!=QMessageBox::Yes)return;saveSession(false);closing_=true;setEnabled(false);auto all=pages_;for(auto* p:all)p->shutdown();}
void MainWindow::key(int key,int mods){bool shift=mods&int(Qt::ShiftModifier),alt=mods&int(Qt::AltModifier);if(key==VK_F11){isFullScreen()?showNormal():showFullScreen();return;}
 if(alt){if(key==VK_LEFT)withCurrent([](auto b){b->GoBack();});if(key==VK_RIGHT)withCurrent([](auto b){b->GoForward();});return;}
 if(key>='1'&&key<='9'){if(tabs_->count())tabs_->setCurrentIndex(key=='9'?tabs_->count()-1:std::min(key-'1',tabs_->count()-1));return;}
 switch(key){
 case VK_TAB:if(tabs_->count())tabs_->setCurrentIndex((tabs_->currentIndex()+tabs_->count()+(shift?-1:1))%tabs_->count());break;
 case 'T':if(shift){if(!closedTabs_.empty())newTab(closedTabs_.takeLast());}else newTab();break;
 case 'W':closeTab(tabs_->currentIndex());break;case 'L':address_->setFocus();address_->selectAll();break;case 'R':reload_->click();break;
 case 'D':addBookmark();break;case 'H':showHistory();break;case 'J':showDownloads();break;case 'F':showFind();break;
 case 'N':if(shift){CefRequestContextSettings s;auto c=CefRequestContext::CreateContext(s,nullptr);auto* w=new MainWindow(c,profile_,true);w->show();}break;
 case VK_OEM_PLUS:if(current())current()->zoomBy(1);break;case VK_OEM_MINUS:if(current())current()->zoomBy(-1);break;case '0':if(current())current()->resetZoom();break;
 }
 if(current()&&(key==VK_OEM_PLUS||key==VK_OEM_MINUS||key=='0'))status_->setText(tr("Масштаб: %1%").arg(current()->zoomPercent()));
}
void MainWindow::showFind(){findBar_->show();find_->setFocus();find_->selectAll();}
void MainWindow::findNext(bool forward){if(find_->text().isEmpty()){withCurrent([](auto b){b->GetHost()->StopFinding(true);});return;}withCurrent([s=find_->text().toStdWString(),forward](auto b){b->GetHost()->Find(s,forward,false,true);});}
bool MainWindow::eventFilter(QObject* o,QEvent* e){if(e->type()==QEvent::KeyPress){auto* k=static_cast<QKeyEvent*>(e);if(k->key()==Qt::Key_Escape){editingAddress_=false;if(o==find_){findBar_->hide();withCurrent([](auto b){b->GetHost()->StopFinding(true);});}if(o==address_)address_->setText(current()?displayAddress(current()->url()):QString{});if(current())current()->setFocus();return true;}}return QMainWindow::eventFilter(o,e);}
bool MainWindow::nativeEvent(const QByteArray& type,void* message,qintptr* result){
 auto* m=static_cast<MSG*>(message);
 if(m->message==WM_GETMINMAXINFO){MONITORINFO info{sizeof(info)};if(GetMonitorInfo(MonitorFromWindow(m->hwnd,MONITOR_DEFAULTTONEAREST),&info)){auto* mm=reinterpret_cast<MINMAXINFO*>(m->lParam);mm->ptMaxPosition={info.rcWork.left-info.rcMonitor.left,info.rcWork.top-info.rcMonitor.top};mm->ptMaxSize={info.rcWork.right-info.rcWork.left,info.rcWork.bottom-info.rcWork.top};mm->ptMinTrackSize={LONG(minimumWidth()*devicePixelRatioF()),LONG(minimumHeight()*devicePixelRatioF())};*result=0;return true;}}
 if(m->message==WM_NCHITTEST&&!isMaximized()&&!isFullScreen()){RECT r;GetWindowRect(m->hwnd,&r);int x=int(static_cast<short>(LOWORD(m->lParam))),y=int(static_cast<short>(HIWORD(m->lParam))),b=int(6*devicePixelRatioF());bool l=x<r.left+b,rr=x>=r.right-b,t=y<r.top+b,bb=y>=r.bottom-b;int h=t?(l?HTTOPLEFT:rr?HTTOPRIGHT:HTTOP):bb?(l?HTBOTTOMLEFT:rr?HTBOTTOMRIGHT:HTBOTTOM):l?HTLEFT:rr?HTRIGHT:0;if(h){*result=h;return true;}}
 return QMainWindow::nativeEvent(type,message,result);
}
void MainWindow::refreshSuggestions(){if(privateMode_)return;QPointer<MainWindow> g=this;store([g](auto& db){auto rows=db.history(100);QStringList urls;for(const auto& r:rows){auto u=QString::fromStdString(r.url);if(!urls.contains(u))urls<<u;}QMetaObject::invokeMethod(qApp,[g,urls]{if(g){g->localSuggestions_=urls;g->suggestions_->setStringList(urls);}},Qt::QueuedConnection);});}
void MainWindow::addBookmark(){if(!current()||!bookmark_->isEnabled())return;auto u=current()->url().toStdString(),t=tabs_->tabText(tabs_->currentIndex()).toStdString();auto now=QDateTime::currentMSecsSinceEpoch();QPointer<MainWindow> g=this;store([=](auto& db){db.addBookmark(u,t,now);QMetaObject::invokeMethod(qApp,[g]{if(g){g->status_->setText(tr("Сохранено в закладки · Меню → Закладки"));g->bookmark_->setProperty("iconName","star-filled");g->bookmark_->setIcon(g->uiIcon("star-filled"));}},Qt::QueuedConnection);});}
void MainWindow::showHistory(){showLibrary(false);}void MainWindow::showBookmarks(){showLibrary(true);}
void MainWindow::showLibrary(bool bookmarks){
 QVBoxLayout* layout;auto* d=panel(bookmarks?tr("Закладки"):tr("История"),bookmarks?tr("Ваши сохранённые страницы. Двойной щелчок — открыть."):tr("Последние 500 посещений. Приватные окна сюда не попадают."),layout);
 auto* search=new QLineEdit;search->setPlaceholderText(bookmarks?tr("Найти закладку…"):tr("Поиск в истории…"));layout->addWidget(search);
 auto* empty=new QLabel(bookmarks?tr("Сохраните то, что важно\nОткройте сайт и нажмите на звёздочку или Ctrl+D."):tr("Здесь будет история посещений\nОткрывайте сайты — и сможете быстро вернуться к ним."));empty->setObjectName("emptyState");empty->setAlignment(Qt::AlignCenter);empty->setWordWrap(true);layout->addWidget(empty,1);
 auto* list=new QListWidget;layout->addWidget(list,1);list->hide();
 auto* row=new QHBoxLayout;auto* remove=new QPushButton(bookmarks?tr("Удалить выбранную"):tr("Очистить историю"));row->addWidget(remove);remove->setEnabled(false);connect(list,&QListWidget::itemSelectionChanged,d,[list,remove,bookmarks]{remove->setEnabled(bookmarks?list->currentItem()!=nullptr:list->count()>0);});connect(list->model(),&QAbstractItemModel::rowsInserted,d,[list,remove,bookmarks]{if(!bookmarks)remove->setEnabled(list->count()>0);});connect(list->model(),&QAbstractItemModel::rowsRemoved,d,[list,remove,bookmarks]{remove->setEnabled(bookmarks?list->currentItem()!=nullptr:list->count()>0);});row->addStretch();auto* closeButton=new QPushButton(tr("Готово"));closeButton->setObjectName("primaryButton");row->addWidget(closeButton);layout->addLayout(row);connect(closeButton,&QPushButton::clicked,d,&QWidget::hide);
 connect(search,&QLineEdit::textChanged,d,[list,empty](const QString& text){int visible=0;for(int i=0;i<list->count();++i){auto* x=list->item(i);bool show=x->text().contains(text,Qt::CaseInsensitive);x->setHidden(!show);if(show)++visible;}if(list->count()){list->setVisible(visible>0);empty->setText(tr("Ничего не найдено. Попробуйте другой запрос."));empty->setVisible(!visible);}});
 connect(list,&QListWidget::itemActivated,this,[this,d](auto* item){newTab(item->data(Qt::UserRole).toString());d->close();});
 connect(remove,&QPushButton::clicked,d,[this,d,list,empty,bookmarks]{if(bookmarks){auto* i=list->currentItem();if(!i)return;auto id=i->data(Qt::UserRole+1).toLongLong();store([id](auto& db){db.removeBookmark(id);});delete i;if(!list->count()){list->hide();empty->setText(tr("Пока нет закладок. Добавьте сайт с помощью Ctrl+D."));empty->show();}}
 else {clearHistoryPanel();}});
 if(!bookmarks){auto* removeOne=new QPushButton(tr("Удалить выбранную запись"));row->insertWidget(1,removeOne);connect(removeOne,&QPushButton::clicked,d,[this,list]{auto* item=list->currentItem();if(!item)return;auto id=item->data(Qt::UserRole+1).toLongLong();store([id](auto& db){db.eraseHistoryEntry(id);});delete item;refreshSuggestions();});}
 QPointer<QListWidget> safeList=list;QPointer<QLabel> safeEmpty=empty;
 store([safeList,safeEmpty,bookmarks](auto& db){struct Row{QString url,title;qint64 id;};QVector<Row> data;if(bookmarks){for(const auto& r:db.bookmarks())data.push_back({QString::fromStdString(r.url),QString::fromStdString(r.title),r.id});}else{for(const auto& r:db.history(500))data.push_back({QString::fromStdString(r.url),QString::fromStdString(r.title),r.id});}
 QMetaObject::invokeMethod(qApp,[safeList,safeEmpty,data]{if(!safeList||!safeEmpty)return;for(const auto& r:data){auto* x=new QListWidgetItem((r.title.isEmpty()?QUrl(r.url).host():r.title)+"\n"+r.url,safeList);x->setData(Qt::UserRole,r.url);x->setData(Qt::UserRole+1,r.id);x->setToolTip(r.url);}safeList->setVisible(!data.empty());safeEmpty->setVisible(data.empty());},Qt::QueuedConnection);});
 d->show();
}
void MainWindow::showDownloads(){tabs_->setSidePanel(downloadsDialog_);}
void MainWindow::privacy(){auto answer=QMessageBox::question(this,tr("Очистить данные сайтов?"),tr("Удалить cookies и HTTP-кэш этого окна?\n\nЭто не удаляет localStorage, service workers, историю и закладки."));if(answer!=QMessageBox::Yes)return;auto ctx=context_;onCefUi([ctx]{ctx->GetCookieManager(nullptr)->DeleteCookies(CefString(),CefString(),nullptr);ctx->ClearHttpCache(nullptr);});status_->setText(tr("Запрошена очистка cookies и HTTP-кэша"));}
QWidget* MainWindow::panel(const QString& title,const QString& subtitle,QVBoxLayout*& layout){
 auto* host=new QWidget;host->setObjectName("sidePanel");auto* outer=new QVBoxLayout(host);outer->setContentsMargins(0,0,0,0);
 auto* heading=new QHBoxLayout;heading->setContentsMargins(20,16,14,12);auto* label=new QLabel(title);label->setStyleSheet("font-size:20px;font-weight:600;background:transparent;");heading->addWidget(label,1);auto* close=new QToolButton;close->setIcon(uiIcon("close"));close->setAccessibleName(tr("Закрыть панель"));heading->addWidget(close);outer->addLayout(heading);connect(close,&QToolButton::clicked,host,[host]{host->hide();});
 auto* scroll=new QScrollArea;scroll->setWidgetResizable(true);scroll->setFrameShape(QFrame::NoFrame);auto* content=new QWidget;layout=new QVBoxLayout(content);layout->setContentsMargins(20,8,20,20);layout->setSpacing(14);auto* sub=new QLabel(subtitle);sub->setWordWrap(true);sub->setObjectName("dialogSubtitle");layout->addWidget(sub);scroll->setWidget(content);outer->addWidget(scroll,1);tabs_->setSidePanel(host);return host;
}
void MainWindow::clearHistoryPanel(){
 QVBoxLayout* layout;auto* d=panel(tr("Очистить историю"),tr("Удаляются записи посещённых страниц. Закладки, cookies и скачанные файлы останутся. Период относится к последнему посещению страницы."),layout);
 auto* period=new QComboBox;period->addItem(tr("Последний час"),3600000LL);period->addItem(tr("Последние 24 часа"),86400000LL);period->addItem(tr("Последние 7 дней"),604800000LL);period->addItem(tr("Последние 30 дней"),2592000000LL);period->addItem(tr("Всё время"),0LL);period->setCurrentIndex(2);
 layout->addWidget(new QLabel(tr("За период")));layout->addWidget(period);auto* host=new QLineEdit;host->setPlaceholderText(tr("Все сайты или домен, например youtube.com"));layout->addWidget(new QLabel(tr("Только с сайта, включая поддомены")));layout->addWidget(host);auto* preview=new QLabel;preview->setWordWrap(true);layout->addWidget(preview);auto* remove=new QPushButton(tr("Удалить записи"));remove->setObjectName("primaryButton");layout->addWidget(remove);auto* cancel=new QPushButton(tr("Отмена"));layout->addWidget(cancel);layout->addStretch();
 struct Filter{qint64 from,to;QString host;bool valid=false;quint64 generation=0;};auto filter=std::make_shared<Filter>();
 auto update=[this,period,host,preview,remove,filter]{
  const auto span=period->currentData().toLongLong();filter->to=QDateTime::currentMSecsSinceEpoch();filter->from=span?std::max<qint64>(0,filter->to-span):0;filter->valid=false;remove->setEnabled(false);const auto generation=++filter->generation;
  auto input=host->text().trimmed();if(!input.isEmpty()){if(!input.contains("://"))input="https://"+input;QUrl url(input);if(!url.isValid()||url.host().isEmpty()||!url.userInfo().isEmpty()||url.port()!=-1||(!url.path().isEmpty()&&url.path()!="/")||url.hasQuery()||url.hasFragment()){preview->setText(tr("Введите только домен сайта."));return;}filter->host=QString::fromLatin1(QUrl::toAce(url.host()));}else filter->host.clear();
  QPointer<QLabel> label=preview;QPointer<QPushButton> button=remove;auto f=*filter;
  store([filter,f,generation,label,button](auto& db){std::size_t n=0;try{n=db.countHistory(f.from,f.to,f.host.toStdString());}catch(...){QMetaObject::invokeMethod(qApp,[label]{if(label)label->setText(tr("Некорректный домен."));},Qt::QueuedConnection);return;}
   QMetaObject::invokeMethod(qApp,[filter,generation,label,button,n]{if(!label||!button||filter->generation!=generation)return;filter->valid=true;label->setText(tr("Будет удалено записей: %1").arg(qulonglong(n)));button->setEnabled(n>0);},Qt::QueuedConnection);
  });
 };
 connect(period,&QComboBox::currentIndexChanged,d,[update](int){update();});connect(host,&QLineEdit::textChanged,d,[update](const QString&){update();});connect(cancel,&QPushButton::clicked,this,&MainWindow::showHistory);
 connect(remove,&QPushButton::clicked,d,[this,filter,preview,remove]{if(!filter->valid)return;remove->setEnabled(false);auto f=*filter;QPointer<QLabel> label=preview;QPointer<MainWindow> self=this;store([self,f,label](auto& db){auto n=db.eraseHistory(f.from,f.to,f.host.toStdString());QMetaObject::invokeMethod(qApp,[self,label,n]{if(self){self->refreshSuggestions();if(label)label->setText(tr("Удалено записей: %1").arg(qulonglong(n)));}},Qt::QueuedConnection);});});update();
}
void MainWindow::showSettings(){
 QVBoxLayout* layout;auto* d=panel(tr("Настройки"),tr("Настройки Noma на этом компьютере."),layout);
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);
 auto* theme=new QComboBox;theme->addItems({tr("Тёмная"),tr("Светлая")});theme->setCurrentIndex(prefs.value("theme","dark")=="light"?1:0);layout->addWidget(new QLabel(tr("Оформление")));layout->addWidget(theme);connect(theme,&QComboBox::currentIndexChanged,d,[this](int i){applyTheme(i?"light":"dark");});
 auto* provider=new QComboBox;provider->addItems({"Google","Яндекс","Bing","DuckDuckGo"});provider->setCurrentText(prefs.value("searchProvider","Google").toString());layout->addWidget(new QLabel(tr("Поисковая система")));layout->addWidget(provider);connect(provider,&QComboBox::currentTextChanged,d,[this](const QString& value){QSettings s(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);s.setValue("searchProvider",value);setInternalSearch(value.toStdString());for(auto* p:pages_)if(home(p->url()))p->command([](auto b){b->Reload();});});
 auto* restore=new QCheckBox(tr("Восстанавливать вкладки при запуске"));restore->setChecked(prefs.value("restoreSession",true).toBool());layout->addWidget(restore);connect(restore,&QCheckBox::toggled,d,[this](bool value){QSettings s(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);s.setValue("restoreSession",value);});
 auto* suggestions=new QCheckBox(tr("Подсказки поисковика в адресной строке"));suggestions->setChecked(prefs.value("searchSuggestions",true).toBool());layout->addWidget(suggestions);auto* notice=new QLabel(tr("При вводе текст отправляется Google для получения подсказок. В приватном окне сетевые подсказки выключены."));notice->setWordWrap(true);notice->setObjectName("dialogSubtitle");layout->addWidget(notice);connect(suggestions,&QCheckBox::toggled,d,[this](bool value){QSettings s(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);s.setValue("searchSuggestions",value);if(!value){suggestTimer_->stop();++suggestionGeneration_;if(suggestReply_)suggestReply_->abort();suggestions_->setStringList(localSuggestions_);}});
 auto* proxy=new QPushButton(tr("Соединение и прокси…"));layout->addWidget(proxy);connect(proxy,&QPushButton::clicked,this,&MainWindow::showProxy);
 auto* history=new QPushButton(tr("Удалить историю за период…"));layout->addWidget(history);connect(history,&QPushButton::clicked,this,&MainWindow::clearHistoryPanel);
 auto* cookies=new QPushButton(tr("Очистить cookies и HTTP-кэш…"));layout->addWidget(cookies);connect(cookies,&QPushButton::clicked,this,&MainWindow::privacy);
 auto* zoom=new QSpinBox;zoom->setRange(50,200);zoom->setSingleStep(10);zoom->setSuffix(" %");zoom->setValue(prefs.value("defaultZoom",100).toInt());layout->addWidget(new QLabel(tr("Масштаб новых страниц")));layout->addWidget(zoom);connect(zoom,&QSpinBox::valueChanged,d,[this](int value){QSettings s(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);s.setValue("defaultZoom",value);});layout->addStretch();d->show();
}
void MainWindow::loadSearchSuggestions(){
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);const auto text=address_->text().trimmed();
 if((prefs.value("proxyMode")=="fixed_servers"&&prefs.value("proxy").toString().startsWith("https:"))||privateMode_||!address_->hasFocus()||!prefs.value("searchSuggestions",true).toBool()||text.size()<2||text.size()>200||text.contains("://")||text.contains('@'))return;
 const auto generation=suggestionGeneration_;QUrl url("https://suggestqueries.google.com/complete/search");QUrlQuery q;q.addQueryItem("client","firefox");q.addQueryItem("hl","ru");q.addQueryItem("q",text);url.setQuery(q);QNetworkRequest request(url);request.setTransferTimeout(2500);suggestReply_=suggestNetwork_->get(request);auto* reply=suggestReply_.data();reply->setReadBufferSize(65536);
 connect(reply,&QNetworkReply::finished,this,[this,reply,generation,text]{reply->deleteLater();if(generation!=suggestionGeneration_||reply->error()!=QNetworkReply::NoError||reply->bytesAvailable()>65536||!address_->hasFocus()||address_->text().trimmed()!=text)return;auto doc=QJsonDocument::fromJson(reply->readAll());auto array=doc.array();if(array.size()<2||!array[1].isArray())return;QStringList rows;rows<<text;for(const auto& x:array[1].toArray()){auto s=x.toString();if(!s.isEmpty()&&s.size()<400&&!rows.contains(s))rows<<s;if(rows.size()>=9)break;}for(const auto& s:localSuggestions_)if(s.contains(text,Qt::CaseInsensitive)&&!rows.contains(s)&&rows.size()<12)rows<<s;suggestions_->setStringList(rows);address_->completer()->complete();});
}
void MainWindow::applyTheme(const QString& value){
 const bool light=value=="light"&&!privateMode_;
 setProperty("lightTheme",light&&!privateMode_);
 QFile css(light?":/styles/light.qss":":/styles/dark.qss");
 QString style;if(css.open(QIODevice::ReadOnly))style=QString::fromUtf8(css.readAll());
 if(privateMode_){
  style+="QMainWindow,QStackedWidget{background:#1c1726;}QWidget#titleBar,QToolBar#navigation{background:#2b2239;}QLineEdit{background:#1c1726;border-color:#59436e;color:#f3eafa;}QLineEdit:focus{border:2px solid #d0aff4;}QTabBar#browserTabBar::tab:selected{background:#453450;color:#f3eafa;}QProgressBar::chunk{background:#d0aff4;}";
 }
 setStyleSheet(style);if(!privateMode_)setInternalTheme(light);
 if(!privateMode_){QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);prefs.setValue("theme",value);}
 for(auto* b:findChildren<QToolButton*>()){auto name=b->property("iconName").toString();if(!name.isEmpty())b->setIcon(uiIcon(name));}
 tabs_->applyTheme();darkTitle(this);
}
void MainWindow::showProxy(){
 QVBoxLayout* layout;auto* d=panel(tr("Подключение"),tr("Системные настройки, прямое соединение или ваш прокси. Встроенного VPN нет. Настройка применяется к открытым окнам Noma и не меняет Windows."),layout);
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);
 auto* mode=new QComboBox;mode->addItem(tr("Использовать настройки Windows"),"system");mode->addItem(tr("Без прокси"),"direct");mode->addItem(tr("Мой прокси-сервер"),"fixed_servers");int selected=mode->findData(prefs.value("proxyMode","system").toString());mode->setCurrentIndex(std::max(0,selected));layout->addWidget(new QLabel(tr("Режим подключения")));layout->addWidget(mode);
 auto* address=new QLineEdit;address->setPlaceholderText("http://host:port или socks5://host:port");address->setText(prefs.value("proxy").toString());address->setEnabled(mode->currentData()=="fixed_servers");layout->addWidget(address);connect(mode,&QComboBox::currentIndexChanged,d,[mode,address]{address->setEnabled(mode->currentData()=="fixed_servers");});
 auto* error=new QLabel;error->setWordWrap(true);layout->addWidget(error);auto* apply=new QPushButton(tr("Применить"));apply->setObjectName("primaryButton");layout->addWidget(apply);layout->addStretch();
 connect(apply,&QPushButton::clicked,d,[this,mode,address,error,apply]{
  const auto selected=mode->currentData().toString();auto server=address->text().trimmed();QUrl url(server);
  if(selected=="fixed_servers"&&(!url.isValid()||(url.scheme()!="http"&&url.scheme()!="https"&&url.scheme()!="socks5")||url.host().isEmpty()||url.port()<1||url.port()>65535||!url.userInfo().isEmpty()||url.hasQuery()||url.hasFragment()||(!url.path().isEmpty()&&url.path()!="/"))){error->setText(tr("Укажите HTTP, HTTPS или SOCKS5 прокси с портом, без логина, пароля и пути."));return;}
  if(selected!="fixed_servers")server.clear();else server=url.toString(QUrl::FullyEncoded);
  std::vector<CefRefPtr<CefRequestContext>> contexts;for(auto* top:QApplication::topLevelWidgets())if(auto* w=qobject_cast<MainWindow*>(top))contexts.push_back(w->context_);
  QPointer<MainWindow> owner=this;QPointer<QLabel> label=error;QPointer<QPushButton> button=apply;apply->setEnabled(false);
  onCefUi([contexts,selected,server,owner,label,button]{
   std::vector<CefRefPtr<CefValue>> previous;bool ok=true;std::string why;
   for(auto ctx:contexts){previous.push_back(ctx->GetPreference("proxy"));auto dict=CefDictionaryValue::Create();dict->SetString("mode",selected.toStdString());if(!server.isEmpty())dict->SetString("server",server.toStdString());auto value=CefValue::Create();value->SetDictionary(dict);CefString reason;if(!ctx->SetPreference("proxy",value,reason)){ok=false;why=reason.ToString();break;}}
   if(!ok){for(std::size_t i=0;i<previous.size();++i){CefString ignored;contexts[i]->SetPreference("proxy",previous[i],ignored);}}
   QMetaObject::invokeMethod(qApp,[owner,label,button,selected,server,ok,why]{if(button)button->setEnabled(true);if(!owner)return;if(!ok){if(label)label->setText(tr("Не применено: ")+QString::fromStdString(why));return;}
    QSettings prefs(QDir(owner->profile_).filePath("appearance.ini"),QSettings::IniFormat);prefs.setValue("proxyMode",selected);prefs.setValue("proxy",server);prefs.sync();
    for(auto* top:QApplication::topLevelWidgets())if(auto* w=qobject_cast<MainWindow*>(top)){
     if(selected=="system")w->suggestNetwork_->setProxy(QNetworkProxy::DefaultProxy);
     else if(selected=="direct")w->suggestNetwork_->setProxy(QNetworkProxy::NoProxy);
     else{QUrl u(server);if(u.scheme()=="https"){w->suggestTimer_->stop();++w->suggestionGeneration_;if(w->suggestReply_)w->suggestReply_->abort();}else w->suggestNetwork_->setProxy(QNetworkProxy(u.scheme()=="socks5"?QNetworkProxy::Socks5Proxy:QNetworkProxy::HttpProxy,u.host(),quint16(u.port())));}
    }
    if(label)label->setText(tr("Применено. Перезагрузите нужную вкладку. Для HTTPS-прокси сетевые подсказки отключены."));
   },Qt::QueuedConnection);
  });
 });d->show();
}
void MainWindow::runUiChecks(){
 const auto dir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");if(!property("slowDownloadDone").toBool())return;if(privateMode_||dir.isEmpty()||property("uiTourStarted").toBool())return;setProperty("uiTourStarted",true);
 QDir().mkpath(dir);
 if(!property("rendererRecoveryChecked").toBool()){
  setProperty("uiTourStarted",false);if(property("rendererRecoveryStarted").toBool())return;setProperty("rendererRecoveryStarted",true);
  QUrl fixture(qEnvironmentVariable("SHIELD_START_URL"));fixture.setPath("/recovery");fixture.setQuery(QString{});newTab(fixture.toString());QPointer<BrowserPage> probe=current();
  auto finished=std::make_shared<bool>(false);
  auto finish=[this,probe,finished](bool success){if(*finished)return;*finished=true;setProperty("rendererRecoveryChecked",true);setProperty("rendererRecoveryPassed",success);if(probe){int i=tabs_->indexOf(probe);if(i>=0)closeTab(i);}QTimer::singleShot(300,this,&MainWindow::runUiChecks);};
  connect(probe,&BrowserPage::completed,this,[this,probe,fixture,dir,finish](const QString& url,const QString&){
   if(!probe)return;const int stage=probe->property("crashTestStage").toInt();
   if(stage==0&&url==fixture.toString()){
    probe->setProperty("crashTestStage",1);probe->command([](auto b){b->GetHost()->ExecuteDevToolsMethod(0,"Page.crash",nullptr);});
   }else if(stage==1&&url.startsWith("shield://error/")&&probe->property("rendererCrashHandled").toBool()){
    probe->setProperty("crashTestStage",2);QTimer::singleShot(350,this,[this,probe,dir,fixture]{if(!probe)return;if(screen())screen()->grabWindow(0,frameGeometry().x(),frameGeometry().y(),width(),height()).save(QDir(dir).filePath("native-renderer-crash.png"));QUrl retry(fixture);retry.setQuery("recovered=1");probe->open(retry.toString());});
   }else if(stage==2&&QUrl(url).path()=="/recovery"&&QUrl(url).query()=="recovered=1")finish(true);
  });
  QTimer::singleShot(20000,this,[finish]{finish(false);});return;
 }
 auto capture=[this,dir](const QString& name){if(screen())screen()->grabWindow(0,frameGeometry().x(),frameGeometry().y(),width(),height()).save(QDir(dir).filePath(name));};
 auto checks=std::make_shared<QJsonObject>();(*checks)["rendererCrashRecovery"]=property("rendererRecoveryPassed").toBool();(*checks)["downloadPause"]=property("pauseObserved").toBool();(*checks)["downloadResume"]=property("resumeObserved").toBool();(*checks)["downloadContinuedAfterTabClose"]=property("closedDownloadingTab").toBool()&&property("slowDownloadDone").toBool();if(!qEnvironmentVariableIsEmpty("SHIELD_EXPECT_RESTORED_DOWNLOADS"))(*checks)["downloadHistoryRestored"]=property("downloadHistoryRestored").toBool();
 QTimer::singleShot(700,this,[this,capture,checks,dir]{
  capture("native-home-dark.png");(*checks)["ownCxxTabStrip"]=tabs_->count()>0;(*checks)["nativeAddressPresent"]=findChild<QLineEdit*>("address")!=nullptr;
  showDownloads();QTimer::singleShot(250,this,[this,capture,checks,dir]{
   capture("native-downloads.png");(*checks)["downloadsInWindow"]=downloadsDialog_->window()==this;
   (*checks)["downloadCompleted"]=downloadsList_->count()>=2;for(int i=0;i<downloadsList_->count();++i)if(!downloadsList_->item(i)->data(Qt::UserRole+3).toBool())(*checks)["downloadCompleted"]=false;tabs_->hideSidePanel();
   showSettings();QTimer::singleShot(250,this,[this,capture,checks,dir]{
    capture("native-settings.png");clearHistoryPanel();QTimer::singleShot(250,this,[this,capture,checks,dir]{
     capture("native-history-filter.png");tabs_->hideSidePanel();
     int before=tabs_->count();newTab();(*checks)["tabAdd"]=tabs_->count()==before+1;closeTab(tabs_->count()-1);(*checks)["tabClose"]=tabs_->count()==before;key('T',int(Qt::ControlModifier|Qt::ShiftModifier));(*checks)["tabReopen"]=tabs_->count()==before+1;closeTab(tabs_->count()-1);
     key('L',int(Qt::ControlModifier));(*checks)["addressShortcut"]=address_->hasFocus();
     applyTheme("light");if(current())current()->command([](auto b){b->Reload();});
     QTimer::singleShot(500,this,[this,capture,checks,dir]{
      capture("native-home-light.png");CefRequestContextSettings s;auto ctx=CefRequestContext::CreateContext(s,nullptr);auto* privateWindow=new MainWindow(ctx,profile_,true);privateWindow->show();
      QTimer::singleShot(3000,this,[this,capture,checks,dir,privateWindow]{
       if(privateWindow->screen())privateWindow->screen()->grabWindow(0,privateWindow->frameGeometry().x(),privateWindow->frameGeometry().y(),privateWindow->width(),privateWindow->height()).save(QDir(dir).filePath("native-private.png"));(*checks)["privateHomeLoaded"]=privateWindow->current()&&home(privateWindow->current()->url())&&!privateWindow->current()->loading()&&privateWindow->current()->property("homeDomVerified").toBool();(*checks)["privateOwnWindow"]=privateWindow->privateMode_&&privateWindow->context_->GetCachePath().empty();privateWindow->close();
       QSaveFile file(QDir(dir).filePath("native-ui-result.json"));if(file.open(QIODevice::WriteOnly)){file.write(QJsonDocument(*checks).toJson());file.commit();}QTimer::singleShot(300,this,&QWidget::close);
      });
     });
    });
   });
  });
 });
}
} // namespace shield
