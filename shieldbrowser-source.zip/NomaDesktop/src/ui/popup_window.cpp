#include "shield/popup_window.h"
#include "shield/browser_page.h"
#include <QCloseEvent>
#include <QLineEdit>
#include <QToolBar>
#include <QToolButton>
#include <QPointer>
#include <QScreen>
#include <QPixmap>
#include <QTimer>
#include <QUrl>
#include <QApplication>
#include <algorithm>
namespace shield {
PopupWindow::PopupWindow(CefRefPtr<CefRequestContext> context,const QString& target,const QString& style,int width,int height){
 setAttribute(Qt::WA_DeleteOnClose);setProperty("nomaPopup",true);setStyleSheet(style);setWindowTitle(tr("Окно сайта — Noma"));
 auto* bar=new QToolBar;bar->setObjectName("navigation");bar->setMovable(false);addToolBar(bar);
 auto* address=new QLineEdit;address->setReadOnly(true);address->setAccessibleName(tr("Адрес окна сайта"));address->setText(target);bar->addWidget(address);
 page_=new BrowserPage(context,this,true);setCentralWidget(page_);
 connect(page_,&BrowserPage::addressChanged,address,&QLineEdit::setText);
 connect(page_,&BrowserPage::titleChanged,this,[this](const QString& title){setWindowTitle(title.left(150)+QString::fromUtf8(" — Noma"));});
 connect(page_,&BrowserPage::closed,this,[this]{browserClosed_=true;close();});
 connect(page_,&BrowserPage::completed,this,[this](const QString& url,const QString&){
  const auto dir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");
  if(!dir.isEmpty()&&QUrl(url).host()=="127.0.0.1"&&QUrl(url).path()=="/oauth-popup"){
   QTimer::singleShot(200,this,[this,dir]{raise();activateWindow();if(screen())screen()->grabWindow(0,frameGeometry().x(),frameGeometry().y(),this->width(),this->height()).save(dir+"/native-auth-popup.png");});
  }
 });
 auto available=screen()?screen()->availableGeometry():QRect(0,0,1024,768);
 resize(std::clamp(width,480,available.width()),std::clamp(height,400,available.height()));move(available.center()-rect().center());
}
void PopupWindow::closeEvent(QCloseEvent* event){if(browserClosed_){event->accept();return;}event->ignore();if(page_->hasActiveDownloads()){hide();page_->closeWhenDownloadsFinish();}else page_->shutdown();}
}
