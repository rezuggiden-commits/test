#include "shield/core/navigation.h"
#include <algorithm>
#include <cctype>
#include <charconv>
#include <vector>

namespace shield::core {
namespace {
constexpr std::size_t kMaxInput = 8192;
bool asciiAlpha(char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'); }
bool digit(char c) { return c >= '0' && c <= '9'; }
std::string lower(std::string s) { for (auto& c : s) if (c >= 'A' && c <= 'Z') c += 'a'-'A'; return s; }
NavigationResult blocked(std::string reason) { return {NavigationKind::Blocked, {}, std::move(reason)}; }
bool portOk(std::string_view s) {
    if (s.empty() || s.size() > 5) return false;
    unsigned n = 0;
    auto [p, ec] = std::from_chars(s.data(), s.data()+s.size(), n);
    return ec == std::errc{} && p == s.data()+s.size() && n > 0 && n <= 65535;
}
bool ipv4(std::string_view s) {
    int parts = 0;
    while (!s.empty()) {
        const auto dot = s.find('.'); auto piece = s.substr(0, dot);
        if (piece.empty() || piece.size() > 3 || (piece.size()>1 && piece.front()=='0')) return false;
        unsigned n = 0; auto [p, ec] = std::from_chars(piece.data(),piece.data()+piece.size(),n);
        if(ec!=std::errc{} || p!=piece.data()+piece.size() || n>255) return false;
        ++parts; if(dot==std::string_view::npos) return parts==4;
        s.remove_prefix(dot+1); if(s.empty()) return false;
    }
    return false;
}
bool ipv6(std::string_view s) {
    // Numeric IPv6, including IPv4 tails; zone identifiers are intentionally rejected.
    auto compressed=s.find("::");
    if(compressed!=std::string_view::npos && s.find("::",compressed+2)!=std::string_view::npos) return false;
    int groups=0;
    auto count=[&](std::string_view part, bool final)->bool {
        while(!part.empty()) {
            auto sep=part.find(':'); auto word=part.substr(0,sep);
            if(word.empty()) return false;
            if(std::any_of(word.begin(),word.end(),[](char c){return c=='.';})) {
                if(!final || sep!=std::string_view::npos || !ipv4(word)) return false;
                groups+=2;
            } else {
                if(word.size()>4 || !std::all_of(word.begin(),word.end(),[](unsigned char c){return std::isxdigit(c)!=0;})) return false;
                ++groups;
            }
            if(sep==std::string_view::npos) break;
            part.remove_prefix(sep+1); if(part.empty()) return false;
        }
        return true;
    };
    if(compressed==std::string_view::npos) return count(s,true) && groups==8;
    return count(s.substr(0,compressed),false) && count(s.substr(compressed+2),true) && groups<8;
}
bool hostOk(std::string_view host) {
    if(host.empty() || host.size()>253) return false;
    if(host.back()=='.') host.remove_suffix(1);
    if(host.empty()) return false;
    bool numeric=std::all_of(host.begin(),host.end(),[](char c){return digit(c)||c=='.';});
    if(numeric) return ipv4(host);
    while(!host.empty()) {
        auto dot=host.find('.'); auto label=host.substr(0,dot);
        if(label.empty() || label.size()>63 || label.front()=='-' || label.back()=='-') return false;
        if(!std::all_of(label.begin(),label.end(),[](char c){return asciiAlpha(c)||digit(c)||c=='-';})) return false;
        if(dot==std::string_view::npos) break;
        host.remove_prefix(dot+1);
    }
    return true;
}
NavigationResult web(std::string_view text) {
    auto sep=text.find("://"); auto scheme=lower(std::string(text.substr(0,sep)));
    if(scheme!="http" && scheme!="https") return blocked("Only HTTP and HTTPS are web URLs");
    auto rest=text.substr(sep+3); auto stop=rest.find_first_of("/?#");
    auto authority=rest.substr(0,stop); std::string_view host=authority;
    if(authority.find('@')!=std::string_view::npos) return blocked("Credentials in URLs are not allowed");
    if(authority.find('\\')!=std::string_view::npos) return blocked("Backslashes in URLs are not allowed");
    if(host.starts_with('[')) {
        auto close=host.find(']');
        if(close==std::string_view::npos || !ipv6(host.substr(1,close-1))) return blocked("Invalid IPv6 host");
        auto tail=host.substr(close+1);
        if(!tail.empty() && (!tail.starts_with(':') || !portOk(tail.substr(1)))) return blocked("Invalid port");
    } else {
        auto colon=host.find(':');
        if(colon!=std::string_view::npos) {
            if(!portOk(host.substr(colon+1))) return blocked("Invalid port");
            host=host.substr(0,colon);
        }
        if(!hostOk(host)) return blocked("Invalid host; use ASCII or IDNA-encoded names");
    }
    std::string result=scheme+"://"+lower(std::string(authority));
    if(stop==std::string_view::npos) result+='/';
    else {
        auto path=rest.substr(stop);
        if(path.front()!='/' ) result+='/';
        for(unsigned char c:path) { if(c==' ') result+="%20"; else if(c=='\\') return blocked("Backslashes in URLs are not allowed"); else result+=static_cast<char>(c); }
    }
    return {NavigationKind::Web,std::move(result),{}};
}
} // namespace
std::string encodeQuery(std::string_view s) {
    constexpr char hex[]="0123456789ABCDEF"; std::string out;
    for(unsigned char c:s) {
        if(asciiAlpha(static_cast<char>(c)) || digit(static_cast<char>(c)) || c=='-' || c=='_' || c=='.' || c=='~') out+=static_cast<char>(c);
        else {out+='%';out+=hex[c>>4];out+=hex[c&15];}
    }
    return out;
}
NavigationResult classifyNavigation(std::string_view input,const NavigationOptions& opt) {
    if(input.size()>kMaxInput) return blocked("Input exceeds 8192 bytes");
    while(!input.empty() && input.front()==' ') input.remove_prefix(1);
    while(!input.empty() && input.back()==' ') input.remove_suffix(1);
    if(input.empty()) return blocked("Empty address");
    if(std::any_of(input.begin(),input.end(),[](unsigned char c){return c<0x20 || c==0x7f;})) return blocked("Control characters are not allowed");
    auto folded=lower(std::string(input));
    if(folded=="about:blank" || (folded=="shield://newtab"||folded=="shield://newtab/") || folded=="shield://settings" || folded=="shield://history" || folded=="shield://bookmarks")
        return {NavigationKind::Internal,folded,{}};
    if(folded.starts_with("http://") || folded.starts_with("https://")) return web(input);
    if(folded.starts_with("file:")) {
        if(!opt.allow_local_files) return blocked("Local file access is disabled");
        if(!input.starts_with("file:///") || input.size()<=8 || input.find_first_of("?#\\")!=std::string_view::npos) return blocked("Only absolute local file URLs are supported");
        return {NavigationKind::LocalFile,std::string(input),{}};
    }
    if(folded.starts_with("mailto:") || folded.starts_with("tel:")) {
        if(!opt.allow_external_protocols) return blocked("External protocols require explicit opt-in and user confirmation");
        if(input.find(' ')!=std::string_view::npos || input.size()<=input.find(':')+1) return blocked("Invalid external protocol URI");
        return {NavigationKind::ExternalProtocol,std::string(input),"User confirmation required"};
    }
    // Interpret host:port before scheme detection, but never search malformed explicit URLs.
    auto first=input.substr(0,input.find_first_of("/?#"));
    bool hostCandidate=input.find(' ')==std::string_view::npos &&
        (first.find('.')!=std::string_view::npos || first.starts_with('[') || first=="localhost" || first.starts_with("localhost:"));
    if(hostCandidate && input.find("://")==std::string_view::npos) return web("https://"+std::string(input));
    auto colon=input.find(':');
    if(colon!=std::string_view::npos) {
        auto prefix=input.substr(0,colon);
        if(!prefix.empty() && asciiAlpha(prefix.front()) && std::all_of(prefix.begin(),prefix.end(),[](char c){return asciiAlpha(c)||digit(c)||c=='+'||c=='-'||c=='.';}))
            return blocked("Unsupported or unsafe URL scheme");
    }
    if(input.find("://")!=std::string_view::npos) return blocked("Malformed URL");
    if(!opt.search_prefix.starts_with("https://")) return blocked("Search provider must use HTTPS");
    auto provider=web(opt.search_prefix);
    if(!provider.allowed() || opt.search_prefix.find('?')==std::string::npos || opt.search_prefix.find('#')!=std::string::npos)
        return blocked("Invalid search provider prefix");
    return {NavigationKind::Search,provider.url+encodeQuery(input),{}};
}
bool isPersistableUrl(std::string_view url) {
    auto folded=lower(std::string(url));
    if(!(folded.starts_with("http://") || folded.starts_with("https://") || folded.starts_with("shield://") || folded=="about:blank")) return false;
    auto r=classifyNavigation(url);
    return r.kind==NavigationKind::Web || r.kind==NavigationKind::Internal;
}
} // namespace shield::core
