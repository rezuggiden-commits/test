# Rust dependency license inventory

Generated from pinned Cargo metadata; this inventory is not a completed legal audit.

| Crate | Version | Declared license | Copied upstream license files |
| --- | --- | --- | --- |
| adblock | 0.13.3 | MPL-2.0 | LICENSE |
| addr | 0.15.6 | MIT/Apache-2.0 | LICENSE, LICENSE-APACHE |
| aho-corasick | 1.1.5 | Unlicense OR MIT | COPYING, LICENSE-MIT, UNLICENSE |
| arrayvec | 0.7.8 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| base64 | 0.22.1 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| bitflags | 2.13.2 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| displaydoc | 0.2.7 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| either | 1.19.0 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| flatbuffers | 25.12.19 | Apache-2.0 | LICENSE from exact upstream vcs commit |
| form_urlencoded | 1.2.2 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| icu_collections | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_locale_core | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_normalizer | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_normalizer_data | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_properties | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_properties_data | 2.3.0 | Unicode-3.0 | LICENSE |
| icu_provider | 2.3.1 | Unicode-3.0 | LICENSE |
| idna | 1.1.0 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| idna_adapter | 1.2.2 | Apache-2.0 OR MIT | LICENSE-APACHE, LICENSE-MIT |
| itertools | 0.14.0 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| itoa | 1.0.18 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| litemap | 0.8.3 | Unicode-3.0 | LICENSE |
| memchr | 2.8.3 | Unlicense OR MIT | COPYING, LICENSE-MIT, UNLICENSE |
| percent-encoding | 2.3.2 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| potential_utf | 0.1.6 | Unicode-3.0 | LICENSE |
| precomputed-hash | 0.1.1 | MIT | LICENSE |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| psl | 2.1.243 | MIT/Apache-2.0 | LICENSE |
| psl-types | 2.0.11 | MIT/Apache-2.0 | LICENSE, LICENSE-APACHE |
| quote | 1.0.47 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| regex | 1.13.1 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| regex-automata | 0.4.18 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| regex-syntax | 0.8.11 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| rustc-hash | 2.1.3 | Apache-2.0 OR MIT | LICENSE-APACHE, LICENSE-MIT |
| rustc_version | 0.4.1 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| seahash | 4.1.0 | MIT | LICENSE from current upstream master; historical confirmation outstanding |
| semver | 1.0.28 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| serde | 1.0.229 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| serde_json | 1.0.154 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| smallvec | 1.16.3 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| syn | 2.0.119 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| syn | 3.0.9 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| synstructure | 0.14.0 | MIT | LICENSE |
| thiserror | 1.0.69 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| thiserror-impl | 1.0.69 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| tinystr | 0.8.4 | Unicode-3.0 | LICENSE |
| unicode-ident | 1.0.27 | (MIT OR Apache-2.0) AND Unicode-3.0 | LICENSE-APACHE, LICENSE-MIT, LICENSE-UNICODE |
| url | 2.5.8 | MIT OR Apache-2.0 | LICENSE-APACHE, LICENSE-MIT |
| utf8_iter | 1.0.4 | Apache-2.0 OR MIT | LICENSE-APACHE, LICENSE-MIT |
| writeable | 0.6.4 | Unicode-3.0 | LICENSE |
| yoke | 0.8.3 | Unicode-3.0 | LICENSE |
| yoke-derive | 0.8.4 | Unicode-3.0 | LICENSE |
| zerofrom | 0.1.8 | Unicode-3.0 | LICENSE |
| zerofrom-derive | 0.1.8 | Unicode-3.0 | LICENSE |
| zerotrie | 0.2.5 | Unicode-3.0 | LICENSE |
| zerovec | 0.11.8 | Unicode-3.0 | LICENSE |
| zerovec-derive | 0.11.6 | Unicode-3.0 | LICENSE |
| zmij | 1.0.23 | MIT | LICENSE-MIT |

Missing crate-root license files were retrieved from upstream repositories:
- https://raw.githubusercontent.com/google/flatbuffers/7e163021e59cca4f8e1e35a7c828b5c6b7915953/LICENSE
- https://gitlab.redox-os.org/redox-os/seahash/-/raw/master/LICENSE (exact crate VCS commit URL returned 404; verify historical license before commercial redistribution)
