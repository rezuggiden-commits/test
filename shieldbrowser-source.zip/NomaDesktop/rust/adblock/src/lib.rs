// SPDX-License-Identifier: MPL-2.0
//! Network-only Brave adblock-rust bridge. See include/shield/adblock.h for ABI safety.
use adblock::{
    Engine,
    lists::{FilterSet, ParseOptions, RuleTypes},
    request::Request,
};
use std::{
    panic::{AssertUnwindSafe, catch_unwind},
    slice, str,
    sync::Mutex,
};

pub const OK: i32 = 0;
pub const INVALID_ARGUMENT: i32 = 1;
pub const INVALID_UTF8: i32 = 2;
pub const INVALID_URL: i32 = 3;
pub const PANIC: i32 = 4;
pub const BLOCK: u32 = 1;
pub const EXCEPTION: u32 = 2;
const MAX_RULES: usize = 32 * 1024 * 1024;
const MAX_URL: usize = 64 * 1024;

/// Opaque to C. No layout or Rust-owned reference crosses the ABI.
pub struct ShieldAdblockEngine {
    engine: Mutex<Engine>,
}

fn boundary(f: impl FnOnce() -> Result<(), i32>) -> i32 {
    match catch_unwind(AssertUnwindSafe(f)) {
        Ok(Ok(())) => OK,
        Ok(Err(e)) => e,
        Err(payload) => {
            // Even an exotic panic payload can panic when dropped. Keep that second
            // unwind out of the ABI boundary (one payload leaks on the error path).
            std::mem::forget(payload);
            PANIC
        }
    }
}

// SAFETY: caller supplies readable, stable, initialized bytes for the specified length.
unsafe fn text<'a>(p: *const u8, n: usize, max: usize) -> Result<&'a str, i32> {
    if n > max || (p.is_null() && n != 0) {
        return Err(INVALID_ARGUMENT);
    }
    let bytes = if n == 0 {
        &[]
    } else {
        unsafe { slice::from_raw_parts(p, n) }
    };
    if bytes.contains(&0) {
        return Err(INVALID_ARGUMENT);
    }
    str::from_utf8(bytes).map_err(|_| INVALID_UTF8)
}

fn resource_type(kind: u32) -> Result<&'static str, i32> {
    match kind {
        0 => Ok("other"),
        1 => Ok("document"),
        2 => Ok("subdocument"),
        3 => Ok("script"),
        4 => Ok("image"),
        5 => Ok("stylesheet"),
        6 => Ok("xmlhttprequest"),
        7 => Ok("font"),
        8 => Ok("media"),
        9 => Ok("websocket"),
        10 => Ok("ping"),
        11 => Ok("object"),
        12 => Ok("csp_report"),
        _ => Err(INVALID_ARGUMENT),
    }
}

/// Create an immutable rules engine from UTF-8 ABP/EasyList text.
/// # Safety
/// Input must remain readable for the call; output must be writable, aligned and non-aliasing.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn shield_adblock_create(
    rules: *const u8,
    rules_len: usize,
    out_engine: *mut *mut ShieldAdblockEngine,
) -> i32 {
    boundary(|| {
        if out_engine.is_null() {
            return Err(INVALID_ARGUMENT);
        }
        unsafe {
            *out_engine = std::ptr::null_mut();
        }
        let rules = unsafe { text(rules, rules_len, MAX_RULES)? };
        let mut set = FilterSet::new(false);
        set.add_filter_list(
            rules.to_owned(),
            ParseOptions {
                rule_types: RuleTypes::NetworkOnly,
                ..ParseOptions::default()
            },
        );
        let engine = Box::new(ShieldAdblockEngine {
            engine: Mutex::new(Engine::new_with_filter_set(set)),
        });
        unsafe {
            *out_engine = Box::into_raw(engine);
        }
        Ok(())
    })
}

/// Evaluate a request; output is zero on error, BLOCK/EXCEPTION bits on success.
/// # Safety
/// Handle must be live; readable input buffers and writable output cannot alias engine storage.
/// Concurrent checks are supported; destruction must not overlap any call.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn shield_adblock_check(
    engine: *const ShieldAdblockEngine,
    url: *const u8,
    url_len: usize,
    source: *const u8,
    source_len: usize,
    kind: u32,
    out_flags: *mut u32,
) -> i32 {
    boundary(|| {
        if out_flags.is_null() {
            return Err(INVALID_ARGUMENT);
        }
        unsafe {
            *out_flags = 0;
        }
        if engine.is_null() {
            return Err(INVALID_ARGUMENT);
        }
        let url = unsafe { text(url, url_len, MAX_URL)? };
        let source = unsafe { text(source, source_len, MAX_URL)? };
        let kind = resource_type(kind)?;
        // Upstream tolerates invalid source URLs as unknown; reject malformed nonempty input here.
        if !source.is_empty() {
            Request::new(source, source, "document", "").map_err(|_| INVALID_URL)?;
        }
        let request = Request::new(url, source, kind, "").map_err(|_| INVALID_URL)?;
        let guard = unsafe { &*engine }.engine.lock().map_err(|_| PANIC)?;
        let result = guard.check_network_request(&request);
        let flags = if result.should_block() { BLOCK } else { 0 }
            | if result.exception.is_some() {
                EXCEPTION
            } else {
                0
            };
        unsafe {
            *out_flags = flags;
        }
        Ok(())
    })
}

/// Free an engine; NULL is a successful no-op.
/// # Safety
/// A non-null handle must come from create, be owned exactly once, and have no active users.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn shield_adblock_destroy(engine: *mut ShieldAdblockEngine) -> i32 {
    boundary(|| {
        if !engine.is_null() {
            unsafe {
                drop(Box::from_raw(engine));
            }
        }
        Ok(())
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn panic_is_contained() {
        assert_eq!(boundary(|| panic!("injected panic")), PANIC);
    }
    #[test]
    fn panicking_payload_drop_is_not_run() {
        struct BadDrop;
        impl Drop for BadDrop {
            fn drop(&mut self) {
                panic!("payload destructor");
            }
        }
        assert_eq!(boundary(|| std::panic::panic_any(BadDrop)), PANIC);
    }
    #[test]
    fn engine_is_send_sync() {
        fn check<T: Send + Sync>() {}
        check::<ShieldAdblockEngine>();
    }
    #[test]
    fn poisoned_engine_returns_error_without_unwinding() {
        let engine = ShieldAdblockEngine {
            engine: Mutex::new(Engine::default()),
        };
        let _ = catch_unwind(AssertUnwindSafe(|| {
            let _guard = engine.engine.lock().unwrap();
            panic!("poison");
        }));
        let mut flags = 99;
        let u = b"https://example.com/";
        assert_eq!(
            unsafe {
                shield_adblock_check(
                    &engine,
                    u.as_ptr(),
                    u.len(),
                    std::ptr::null(),
                    0,
                    0,
                    &mut flags,
                )
            },
            PANIC
        );
        assert_eq!(flags, 0);
    }
}
