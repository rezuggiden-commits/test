# Noma 0.5: release candidate, NOT public production release

## Implemented
- Visually distinct purple private windows; Ctrl+Shift+N tested through keyboard input.
- Address suggestions: typed search, history, bookmarks, remote provider suggestions; 180 ms debounce, abort stale requests, keyboard navigation. No remote suggestions in private windows. Toggle in Settings. URLs and email addresses are not sent to the suggestion endpoint.
- History drawer and in-app clearing modal: hour/day/week/month/all time AND optional exact domain/subdomains; individual entry deletion; pre-delete count.
- Downloads drawer, explicit full manager and toolbar double-click; pause/resume/cancel/open/show folder; completed normal downloads survive restart.
- Assistant toolbar button and hideable home companion. Ollama dependency removed.
- Debounced atomic profile writes, throttled state emissions, history omitted from unrelated chrome updates, deferred background restore, serialized filter cache.

## Release blockers — do not market as finished
1. Cloud AI endpoint is not provisioned. server/ai.cjs implements a provider adapter; requires funded provider credentials stored ONLY on a server, HTTPS, per-user authentication, abuse/budget controls, privacy policy, and an actual deployment. Basic loopback rate limits are not sufficient for an unauthenticated public service. Browser uses NOMA_AI_URL (HTTPS /chat endpoint). No provider key in browser.
2. No built-in VPN server/network. Existing system/custom HTTP or SOCKS5 proxy remains available. No random free proxies, silent traffic interception, TLS bypass, or availability guarantee. A real built-in VPN requires a trusted service, credentials/entitlements and leak/route testing.
3. Google account login is NOT certified or guaranteed. Google OAuth can reject embedded user agents; user-agent changes are not a supported fix. Electron is not Chrome and does not support arbitrary Chrome Web Store extensions. See https://developers.google.com/identity/protocols/oauth2/native-app and https://www.electronjs.org/docs/latest/api/extensions .
4. No signed installer or verified publisher, secure updater, independent security audit, account/sync infrastructure, crash-recovery soak test or broad Windows hardware coverage.
5. Public site checks depend on network, region, CAPTCHA and account status. A successful page load is not proof of successful Google login or reliable YouTube playback.

## AI server (developer setup, not an end-user installation)
Node 24: OPENAI_API_KEY is set in server secret storage, NOMA_AI_MODEL optional. Run node server/ai.cjs behind an authenticated HTTPS gateway. Configure NOMA_AI_URL for the browser process, pointing to /chat. Production authentication flow must be implemented before making this public. Unit tests use mocked provider responses, not a live paid service.

## Verification
npm test: navigation, privacy/security, history selection, suggestion parsing, provider adapter validation. tests/electron.cjs: actual native Electron with local fixtures plus separately reported public-network checks. DOM screenshots are design checks, not native runtime evidence. Packaged executable startup checked by CI.
