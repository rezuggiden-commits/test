import urllib.request,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
for name,slug,color in [('youtube','youtube','#ff0033'),('google','google','#4285f4'),('github','github','currentColor'),('wikipedia','wikipedia','#7a7f89')]:
 url='https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/'+slug+'.svg'
 text=urllib.request.urlopen(url,timeout=30).read().decode()
 text=text.replace('<svg ','<svg aria-hidden="true" ',1)
 (root/'ui/assets'/f'{name}.svg').write_text(text)
 print(name,len(text))
for name,url in [('easylist','https://easylist.to/easylist/easylist.txt'),('easyprivacy','https://easylist.to/easylist/easyprivacy.txt')]:
 data=urllib.request.urlopen(url,timeout=60).read()
 (root/'filters'/f'{name}.txt').write_bytes(data)
 print(name,len(data))
