$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
node --version
npm ci --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
npm test
if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed' }
$env:NOMA_TEST_PROFILE = Join-Path $env:RUNNER_TEMP ('noma-test-' + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Force $env:NOMA_TEST_PROFILE | Out-Null
New-Item -ItemType Directory -Force docs/runtime | Out-Null
$runtime = Start-Process -FilePath (Join-Path $PWD 'node_modules/electron/dist/electron.exe') -ArgumentList '.', '--self-test' -WorkingDirectory $PWD -PassThru -RedirectStandardOutput docs/runtime/stdout.log -RedirectStandardError docs/runtime/stderr.log
if (!$runtime.WaitForExit(480000)) { Stop-Process -Id $runtime.Id -Force; throw 'Runtime tests timed out (8 min); see diagnostic logs' }
Get-Content docs/runtime/stdout.log
Get-Content docs/runtime/stderr.log
if ($runtime.ExitCode -ne 0) { throw "Real Electron integration tests failed ($($runtime.ExitCode))" }
if (!(Test-Path docs/runtime/runtime.json)) { throw 'Runtime evidence missing' }
$evidence = Get-Content docs/runtime/runtime.json -Raw | ConvertFrom-Json
if (!$evidence.fixturePassed) { throw 'Fixture checks did not pass' }
npm run package
if ($LASTEXITCODE -ne 0) { throw 'Windows packaging failed' }
if (!(Test-Path dist/Noma-win32-x64/Noma.exe)) { throw 'EXE missing' }
@'
Noma 0.5 — release candidate (not a public stable release)
Extract this ENTIRE folder, then run Noma.exe. Do not move just the EXE.
New profile: %APPDATA%\Noma. Old ShieldBrowser profile is not modified.
Cloud AI is not connected. No built-in VPN/Tor or automatic updater. Update manually for security fixes.
Public-network checks are in docs/runtime/runtime.json of the diagnostics artifact.
'@ | Set-Content dist/Noma-win32-x64/START-HERE.txt -Encoding UTF8
Copy-Item LICENSE dist/Noma-win32-x64/APP-LICENSE.txt
Copy-Item THIRD_PARTY_NOTICES.md dist/Noma-win32-x64/
Compress-Archive -Path dist/Noma-win32-x64/* -DestinationPath dist/Noma-Windows-x64-portable.zip -CompressionLevel Optimal
(Get-FileHash dist/Noma-Windows-x64-portable.zip -Algorithm SHA256).Hash.ToLowerInvariant() | Set-Content dist/SHA256.txt -Encoding ASCII
