$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
node --version
npm ci --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' }
node node_modules/electron/install.js
if ($LASTEXITCODE -ne 0) { throw 'Electron runtime install failed' }
npm test
if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed' }
$env:NOMA_TEST_PROFILE = Join-Path $env:RUNNER_TEMP ('noma-test-' + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Force $env:NOMA_TEST_PROFILE | Out-Null
New-Item -ItemType Directory -Force docs/runtime | Out-Null
$electron = Join-Path (Resolve-Path node_modules/electron/dist) 'electron.exe'
$stdout = Join-Path (Resolve-Path docs/runtime) 'stdout.log'
$stderr = Join-Path (Resolve-Path docs/runtime) 'stderr.log'
$process = Start-Process -FilePath $electron -ArgumentList '.', '--self-test' -NoNewWindow -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
if (!$process.WaitForExit(480000)) {
  Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
  Get-Content $stdout -ErrorAction SilentlyContinue
  Get-Content $stderr -ErrorAction SilentlyContinue
  throw 'Real Electron integration tests timed out'
}
Get-Content $stdout -ErrorAction SilentlyContinue
Get-Content $stderr -ErrorAction SilentlyContinue
if (!(Test-Path docs/runtime/runtime.json)) { throw 'Runtime evidence missing' }
$evidence = Get-Content docs/runtime/runtime.json -Raw | ConvertFrom-Json
if (!$evidence.fixturePassed) { throw 'Fixture checks did not pass' }
npm run package
if ($LASTEXITCODE -ne 0) { throw 'Windows packaging failed' }
if (!(Test-Path dist/Noma-win32-x64/Noma.exe)) { throw 'EXE missing' }
$env:NOMA_TEST_PROFILE = Join-Path $env:RUNNER_TEMP ('noma-smoke-' + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Force $env:NOMA_TEST_PROFILE | Out-Null
$smokeOut = Join-Path (Resolve-Path docs/runtime) 'packaged-smoke-stdout.log'
$smokeErr = Join-Path (Resolve-Path docs/runtime) 'packaged-smoke-stderr.log'
$smoke = Start-Process -FilePath (Resolve-Path dist/Noma-win32-x64/Noma.exe) -ArgumentList '--smoke-test' -NoNewWindow -PassThru -RedirectStandardOutput $smokeOut -RedirectStandardError $smokeErr
if (!$smoke.WaitForExit(60000)) { Stop-Process -Id $smoke.Id -Force -ErrorAction SilentlyContinue; throw 'Packaged EXE smoke test timed out' }
Get-Content $smokeOut -ErrorAction SilentlyContinue
Get-Content $smokeErr -ErrorAction SilentlyContinue
if (!(Select-String -Path $smokeOut -SimpleMatch 'NOMA_SMOKE_OK' -Quiet)) { throw 'Packaged EXE did not reach ready UI state' }
@'
Noma 0.4 — development preview
Extract this ENTIRE folder, then run Noma.exe. Do not move just the EXE.
New profile: %APPDATA%\Noma. Old ShieldBrowser profile is not modified.
No built-in VPN/Tor or automatic updater. Update manually for security fixes.
Public-network checks are in docs/runtime/runtime.json of the diagnostics artifact.
'@ | Set-Content dist/Noma-win32-x64/START-HERE.txt -Encoding UTF8
Copy-Item LICENSE dist/Noma-win32-x64/APP-LICENSE.txt
Copy-Item THIRD_PARTY_NOTICES.md dist/Noma-win32-x64/
Compress-Archive -Path dist/Noma-win32-x64/* -DestinationPath dist/Noma-Windows-x64-portable.zip -CompressionLevel Optimal
(Get-FileHash dist/Noma-Windows-x64-portable.zip -Algorithm SHA256).Hash.ToLowerInvariant() | Set-Content dist/SHA256.txt -Encoding ASCII
