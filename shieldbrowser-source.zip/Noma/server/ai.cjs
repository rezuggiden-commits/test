'use strict';
// Server-only component. Never package provider keys with the browser.
const http=require('node:http');
function createAIService({key=process.env.OPENAI_API_KEY,model=process.env.NOMA_AI_MODEL||'gpt-4.1-mini',endpoint=process.env.NOMA_PROVIDER_URL||'https://api.openai.com/v1/chat/completions',fetchImpl=fetch}={}){
 const buckets=new Map();let active=0;
 const server=http.createServer(async(req,res)=>{
  const send=(code,body)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));};
  if(req.url==='/health'&&req.method==='GET')return send(key?200:503,{ready:!!key});
  if(req.url!=='/chat'||req.method!=='POST')return send(404,{error:'Not found'});
  if(!key)return send(503,{error:'AI service not configured'});
  const ip=req.socket.remoteAddress,now=Date.now(),bucket=buckets.get(ip)||{since:now,n:0};if(now-bucket.since>60000){bucket.since=now;bucket.n=0;}bucket.n++;buckets.set(ip,bucket);
  if(bucket.n>12||active>=8)return send(429,{error:'Please retry later'});
  let raw='',large=false;for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>64000){large=true;break;}}if(large)return send(413,{error:'Request too large'});
  let messages;try{const data=JSON.parse(raw);if(!Array.isArray(data.messages)||!data.messages.length||data.messages.length>12)throw Error();messages=data.messages.map(m=>{if(!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>12000)throw Error();return {role:m.role,content:m.content};});}catch{return send(400,{error:'Invalid messages'});}
  active++;try{const upstream=await fetchImpl(endpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+key},body:JSON.stringify({model,max_tokens:1600,messages:[{role:'system',content:'Ты помощник браузера Noma. Отвечай на языке пользователя, ясно и по делу. У тебя нет доступа к истории, страницам, аккаунтам или файлам браузера. Не утверждай, что выполнял действия.'},...messages]}),signal:AbortSignal.timeout(40000)});if(!upstream.ok)return send(upstream.status===429?429:502,{error:'Provider unavailable'});const data=await upstream.json();const answer=data.choices?.[0]?.message?.content;if(typeof answer!=='string')throw Error();send(200,{answer});}catch{send(502,{error:'AI service unavailable'});}finally{active--;}
 });
 const timer=setInterval(()=>{for(const [ip,b]of buckets)if(Date.now()-b.since>120000)buckets.delete(ip);},60000);timer.unref();server.on('close',()=>clearInterval(timer));return server;
}
module.exports={createAIService};
if(require.main===module)createAIService().listen(Number(process.env.PORT)||8787,'127.0.0.1',()=>console.log('Noma AI service listening on loopback; expose only behind authenticated HTTPS gateway.'));
