'use strict';
const{contextBridge,ipcRenderer}=require('electron');
// One closed command channel. No Node objects, ipcRenderer, file access or arbitrary JS exposed.
contextBridge.exposeInMainWorld('browser',Object.freeze({command:(action,payload={})=>ipcRenderer.invoke('command',action,payload),subscribe:fn=>{const cb=(_,data)=>fn(data);ipcRenderer.on('state',cb);return()=>ipcRenderer.removeListener('state',cb);}}));
for(const[channel,event]of [['focus-address','noma-focus-address'],['content-focus','noma-content-focus'],['find-result','noma-find-result']])ipcRenderer.on(channel,(_e,data)=>window.dispatchEvent(new CustomEvent(event,{detail:data})));
