'use strict';
const { domainToUnicode } = require('node:url');
const searchEngines = { duckduckgo:'https://duckduckgo.com/?q=', google:'https://www.google.com/search?q=', yandex:'https://yandex.ru/search/?text=', brave:'https://search.brave.com/search?q=' };
const shortcuts = [
 {id:'youtube',name:'YouTube',url:'https://www.youtube.com/',icon:'youtube'},
 {id:'google',name:'Google',url:'https://www.google.com/',icon:'google'},
 {id:'wikipedia',name:'Википедия',url:'https://ru.wikipedia.org/',icon:'wikipedia'},
 {id:'github',name:'GitHub',url:'https://github.com/',icon:'github'}
];
const aliases = new Map([['youtube',shortcuts[0].url],['ютуб',shortcuts[0].url],['ютюб',shortcuts[0].url],['википедия',shortcuts[2].url],['wikipedia',shortcuts[2].url],['github',shortcuts[3].url],['гитхаб',shortcuts[3].url],['google',shortcuts[1].url],['гугл',shortcuts[1].url]]);
function navigateInput(input, engine='duckduckgo') {
 if(typeof input!=='string'||input.length>16384) throw new Error('Слишком длинный адрес');
 const value=input.trim(); if(!value)return {kind:'internal',url:'noma:newtab'};
 if(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(value))throw new Error('Недопустимые символы в адресе');
 if(aliases.has(value.toLowerCase()))return{kind:'web',url:aliases.get(value.toLowerCase()),alias:true};
 if(/^noma:(newtab|history|bookmarks|downloads|settings|assistant)$/.test(value))return{kind:'internal',url:value};
 let candidate=value;
 const explicit=/^[a-z][a-z\d+.-]*:/i.test(value)&&!/^localhost:\d/i.test(value)&&!/^\S+\.\S+:\d/.test(value);
 if(explicit&&!/^https?:/i.test(value))throw new Error('Разрешены только адреса HTTP и HTTPS');
 if(!explicit && !/\s/.test(value) && (/^(localhost|\d{1,3}(\.\d{1,3}){3}|\[[\da-f:]+\])(?::\d+)?(?:\/|$)/i.test(value)|| /^[^/?#]+\.[^/?#]+(?:[/?#]|$)/u.test(value))) candidate=(/^(localhost|127\.|\[::1\])/.test(value)?'http://':'https://')+value;
 if(/^https?:/i.test(candidate)) {const u=new URL(candidate);if(u.username||u.password)throw new Error('Адреса с логином и паролем не поддерживаются');return {kind:'web',url:u.href};}
 return{kind:'search',url:(searchEngines[engine]||searchEngines.duckduckgo)+encodeURIComponent(value),query:value};
}
function displayURL(raw){
 try{const u=new URL(raw); if(!['http:','https:'].includes(u.protocol))return '';
 // Decode Unicode path characters only; reserved delimiters, controls and bidi stay encoded.
 const path=(u.pathname+u.search+u.hash).replace(/(?:%[0-9a-f]{2})+/gi,seq=>{try{const s=decodeURIComponent(seq);return /^[\p{L}\p{N}\p{M}\p{Zs}._~-]+$/u.test(s)&&!/[\u00a0\u202f]/u.test(s)?s:seq;}catch{return seq;}});
 // Keep punycode hosts. Decoding them permits IDN homograph spoofing.
 return u.protocol+'//'+u.host+(path==='/'?'':path);
 }catch{return '';}
}
function host(raw){try{return new URL(raw).hostname;}catch{return '';}}
function validProxy(value){if(!value)return{mode:'system'};const u=new URL(value);if(!['http:','socks5:'].includes(u.protocol)||u.username||u.password||!u.port||!u.hostname||u.pathname!=='/'&&u.pathname!==''||u.search||u.hash)throw new Error('Нужен http://host:port или socks5://host:port без пароля');return{mode:'fixed_servers',proxyRules:u.protocol+'//'+u.host,proxyBypassRules:'<-loopback>'};}
function privacyHeaders(headers){const h={...headers};for(const k of Object.keys(h))if(['dnt','sec-gpc'].includes(k.toLowerCase()))delete h[k];h.DNT='1';h['Sec-GPC']='1';return h;}
module.exports={navigateInput,displayURL,host,shortcuts,searchEngines,validProxy,privacyHeaders};
