'use strict';
const {randomUUID}=require('node:crypto');
const {app,BrowserWindow,WebContentsView,ipcMain,session,dialog,shell,clipboard,Menu,nativeTheme,nativeImage}=require('electron');
const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const{navigateInput,displayURL,host,shortcuts,validProxy,privacyHeaders}=require('./navigation.cjs');
const{Store}=require('./store.cjs');
const{parseBookmarks,mergeBookmarks,exportBookmarks,inspectExtension,copyExtension}=require('./library.cjs');
const{clearVisits,historyMatches,localSuggestions,suggestionURL,parseSuggestions,maySuggest}=require('./features.cjs');
const{FiltersEngine,Request}=require('@ghostery/adblocker');
app.setName('Noma');
// Set before session creation. No --no-sandbox or TLS bypass switches.
app.commandLine.appendSwitch('force-webrtc-ip-handling-policy','disable_non_proxied_udp');
const selfTesting=process.argv.includes('--self-test'),smokeTesting=process.argv.includes('--smoke-test'),sessionTesting=process.argv.includes('--session-check'),testing=selfTesting||smokeTesting||sessionTesting;
if(testing)process.on('uncaughtException',e=>{console.error('NOMA_FATAL',e.stack||e);app.exit(1);});
if(process.env.NOMA_TEST_PROFILE&&testing)app.setPath('userData',process.env.NOMA_TEST_PROFILE);
else app.setPath('userData',path.join(app.getPath('appData'),'Noma'));
const uiFile=path.join(__dirname,'../ui/index.html'),uiURL=pathToFileURL(uiFile).href;
let engine,store,normalSession;const controllers=new Set();let seq=0;let activeDownloads=[];const disabledHosts=new Set();
let shuttingDown=false;
function finiteString(v,max=16384){if(typeof v!=='string'||v.length>max)throw Error('Некорректные данные');return v;}
function guardWebURL(v){const r=navigateInput(v);if(r.kind!=='web')throw Error('Нужен полный адрес сайта');return r.url;}
function setupSession(s){
 s.setUserAgent(app.userAgentFallback.replace(/\sElectron\/\S+/g,'').replace(/\s(?:noma-browser|Noma)\/\S+/gi,''));
 const allowed=(wc,permission)=>permission==='fullscreen'&&[...controllers].some(c=>c.current()?.view?.webContents===wc);
 s.setPermissionRequestHandler((wc,permission,cb)=>cb(allowed(wc,permission)));s.setPermissionCheckHandler((wc,permission)=>allowed(wc,permission));
 s.on('will-download',(event,item,wc)=>{
  const c=[...controllers].find(c=>c.tabs.some(t=>t.view?.webContents===wc));
  if(!c){event.preventDefault();return;}
  const d={id:randomUUID(),name:path.basename(item.getFilename()).replace(/[<>:"/\\|?*\x00-\x1f]/g,'_'),received:0,total:item.getTotalBytes(),status:'Загружается',private:c.private,owner:c.win.id,item,path:''};
  activeDownloads.unshift(d);
  if(testing&&process.env.NOMA_TEST_PROFILE)item.setSavePath(path.join(process.env.NOMA_TEST_PROFILE,d.name));
  else item.setSaveDialogOptions({title:'Сохранить файл',defaultPath:path.join(app.getPath('downloads'),d.name)});
  item.on('updated',(_e,state)=>{d.received=item.getReceivedBytes();d.status=state==='interrupted'?'Соединение прервано':item.isPaused()?'Приостановлено':'Загружается';emitAll();});
  item.once('done',(_e,state)=>{d.received=item.getReceivedBytes();d.path=item.getSavePath();d.status=state==='completed'?'Завершено':state==='cancelled'?'Отменено':'Не удалось скачать';d.done=true;d.success=state==='completed';d.item=null;if(!d.private){const {item,...saved}=d;store.data.downloads=[saved,...(store.data.downloads||[])].slice(0,300);activeDownloads=activeDownloads.filter(x=>x!==d);store.scheduleSave();}emitAll();});c.emit();
 });
 s.webRequest.onBeforeSendHeaders({urls:['http://*/*','https://*/*']},(d,cb)=>cb({requestHeaders:privacyHeaders(d.requestHeaders)}));
 s.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*','ws://*/*','wss://*/*']},(d,cb)=>{
  const c=[...controllers].find(c=>c.tabs.some(t=>t.view?.webContents.id===d.webContentsId));const tab=c?.tabs.find(t=>t.view?.webContents.id===d.webContentsId);
  const source=tab?.url||d.referrer||'';let blocked=false;
  if(store.data.settings.blocking&&engine&&d.resourceType!=='mainFrame'&&!disabledHosts.has(host(source))){
   try{blocked=engine.match(Request.fromRawDetails({url:d.url,sourceUrl:source,type:d.resourceType,requestId:String(d.id)})).match;}catch{blocked=false;}
  }
  if(blocked&&tab&&tab.blocked.size<100){const h=host(d.url);tab.blocked.set(h,(tab.blocked.get(h)||0)+1);c.emit();}
  cb({cancel:blocked});
 });
 s.webRequest.onErrorOccurred({urls:['http://*/*','https://*/*']},d=>{const c=[...controllers].find(c=>c.tabs.some(t=>t.view?.webContents.id===d.webContentsId));const t=c?.tabs.find(t=>t.view?.webContents.id===d.webContentsId);if(t&&t.errors.length<100)t.errors.push({host:host(d.url),type:d.resourceType,error:d.error,time:Date.now()});});
}
function emitAll(){for(const c of controllers)c.emit();}
function stepHistory(t,delta,done){const wc=t?.view?.webContents,history=wc?.navigationHistory;if(!history)return;const target=history.getActiveIndex()+delta;if(target>=0&&target<history.getAllEntries().length){wc.once('did-start-navigation',()=>{const poll=setInterval(()=>{if(wc.isDestroyed()||!wc.isLoadingMainFrame()){clearInterval(poll);t.loading=false;clearTimeout(t.timer);done();}},25);poll.unref();});history.goToIndex(target);}}
class Controller{
 constructor(isPrivate=false){
  this.private=isPrivate;this.tabs=[];this.closed=[];this.active=null;this.panel='';this.find='';this.omnibox=false;this.diagnostics=[];this.toast='';this.suggestAbort=null;
  this.ses=isPrivate?session.fromPartition('private-'+randomUUID()):normalSession;this.sessionReady=Promise.resolve();if(isPrivate){setupSession(this.ses);this.sessionReady=this.ses.setProxy(validProxy(store.data.settings.proxy)).catch(e=>{this.proxyError=e.message;});}
  this.win=new BrowserWindow({width:1320,height:880,minWidth:720,minHeight:500,frame:false,show:false,backgroundColor:'#15171c',title:'Noma',icon:path.join(__dirname,'../ui/assets/app.png'),webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,spellcheck:false}});
  controllers.add(this);this.win.setMenu(null);this.win.loadFile(uiFile);this.win.once('ready-to-show',()=>this.win.show());this.win.on('resize',()=>this.layout());this.win.on('maximize',()=>this.emit());this.win.on('unmaximize',()=>this.emit());
  this.win.webContents.setWindowOpenHandler(()=>({action:'deny'}));this.win.webContents.on('will-navigate',e=>e.preventDefault());this.win.webContents.on('before-input-event',(e,input)=>this.key(e,input));
  this.win.on('close',()=>{this.suggestAbort?.abort();this.persist();if(!this.private)this.ses.flushStorageData();store.save();});this.win.on('closed',()=>{controllers.delete(this);for(const t of this.tabs)if(t.view&&!t.view.webContents.isDestroyed())t.view.webContents.close({waitForBeforeUnload:false});this.tabs=[];if(this.private){this.ses.clearStorageData().catch(()=>{});this.ses.clearCache().catch(()=>{});for(const d of activeDownloads.filter(d=>d.owner===this.win.id&&d.private))d.item?.cancel();activeDownloads=activeDownloads.filter(d=>d.owner!==this.win.id||!d.private);} });
  const restored=!isPrivate&&store.data.settings.restore?store.data.session:[];
  if(restored.length)for(const u of restored.slice(0,25))this.newTab(u,false,true);else this.newTab('noma:newtab',false);
  this.activate(this.tabs[0].id);store.data.clean=false;store.save();
 }
 current(){return this.tabs.find(t=>t.id===this.active);}
 state(){const t=this.current();return{version:app.getVersion(),private:this.private,tabs:this.tabs.map(t=>({id:t.id,title:t.title,url:t.url,display:displayURL(t.url),route:t.route,status:t.status,error:t.error,loading:t.loading})),active:this.active,panel:this.panel,find:this.find,settings:store.data.settings,shortcuts:[...shortcuts,...store.data.shortcuts],history:this.private||!(t?.route==='history'||this.panel==='history')?[]:store.data.history.map(x=>({...x,display:displayURL(x.url)})),bookmarks:store.data.bookmarks.map(x=>({...x,display:displayURL(x.url)})),downloads:[...activeDownloads.filter(d=>!d.private||d.owner===this.win.id).map(({item,...d})=>d),...(this.private?[]:(store.data.downloads||[]))],profile:this.private?{name:'Приватное окно',avatar:''}:store.data.profile,extensions:this.private?[]:store.data.extensions.map(({path,...e})=>e),blocked:t?[...t.blocked].map(([host,count])=>({host,count})):[],disabled:disabledHosts.has(host(t?.url)),diagnostics:this.diagnostics,toast:this.toast,maximized:this.win.isMaximized(),canBack:t?.view?.webContents.navigationHistory.canGoBack()||false,canForward:t?.view?.webContents.navigationHistory.canGoForward()||false};}
 emit(){if(this.win.isDestroyed())return;if(this.emitTimer)return;this.emitTimer=setTimeout(()=>{this.emitTimer=null;if(!this.win.isDestroyed())this.win.webContents.send('state',this.state());},60);}
 layout(){if(this.win.isDestroyed())return;const[w,h]=this.win.getContentSize();const top=104+(this.find?52:0)+(this.omnibox?this.omniHeight||300:0);for(const t of this.tabs){if(!t.view)continue;const visible=t.id===this.active&&!t.route&&!t.error&&!this.modal;t.view.setVisible(visible);if(visible)t.view.setBounds({x:0,y:top,width:Math.max(1,w-(this.panel?Math.min(420,Math.floor(w*.48)):0)),height:Math.max(1,h-top)});}}
 persist(){if(this.private)return;store.data.session=this.tabs.filter(t=>!t.route&&/^https?:/.test(t.url)).map(t=>t.url);store.scheduleSave();}
 newTab(url='noma:newtab',activate=true,lazy=false){const t={id:String(++seq),url:'',title:'Новая вкладка',route:'newtab',view:null,loading:false,error:null,blocked:new Map(),errors:[]};this.tabs.push(t);if(activate)this.active=t.id;if(lazy){t.url=url;t.route='';t.title=host(url);t.pending=true;}else this.navigate(t,url);this.layout();this.emit();return t;}
 activate(id){if(!this.tabs.some(t=>t.id===id))return;this.active=id;const tab=this.current();if(tab.pending){tab.pending=false;this.navigate(tab,tab.url);}this.panel='';this.omnibox=false;this.find='';this.layout();this.emit();}
 ensureView(t,inherited={}){if(t.view)return t.view;const view=new WebContentsView({webPreferences:{...inherited,preload:undefined,session:this.ses,nodeIntegration:false,nodeIntegrationInSubFrames:false,contextIsolation:true,sandbox:true,webSecurity:true,allowRunningInsecureContent:false,safeDialogs:true,autoplayPolicy:'user-gesture-required',navigateOnDragDrop:false}});t.view=view;view.setBackgroundColor('#ffffff');this.win.contentView.addChildView(view);const wc=view.webContents;wc.setWebRTCIPHandlingPolicy('disable_non_proxied_udp');
  wc.on('before-input-event',(e,input)=>this.key(e,input));
  wc.on('focus',()=>{if(t.id!==this.active||t.route||t.error||this.modal)return;this.omnibox=false;this.layout();this.win.webContents.send('content-focus');});
  wc.on('will-navigate',(e,url)=>{if(!/^https?:\/\//i.test(url))e.preventDefault();});
  wc.on('will-redirect',(e,url)=>{if(!/^https?:\/\//i.test(url))e.preventDefault();});
  this.configurePopups(wc);
  wc.on('did-start-navigation',(_e,url,inPlace,main)=>{if(!main)return;if(!inPlace){t.loading=true;t.error=null;t.blocked.clear();t.errors=[];clearTimeout(t.timer);t.timer=setTimeout(()=>{if(t.loading&&!wc.isDestroyed()){wc.stop();t.loading=false;t.error={code:'TIMEOUT',message:'Сайт не ответил за 30 секунд'};this.layout();this.emit();}},30000);}t.url=url;this.emit();});
  wc.on('did-navigate',(_e,url,httpCode)=>{t.url=url;t.status=httpCode;this.persist();this.emit();});
  wc.on('did-navigate-in-page',(_e,url,main)=>{if(main){t.url=url;this.persist();this.emit();}});
  // DOM readiness is distinct from background network activity. Background beacons cannot keep chrome spinning.
  wc.on('dom-ready',()=>{t.loading=false;clearTimeout(t.timer);t.title=wc.getTitle()||host(t.url);if(!this.private&&!t.error)store.visit(t.url,t.title);this.emit();});
  wc.on('page-title-updated',(_e,title)=>{t.title=title;const row=store.data.history[0];if(!this.private&&row?.url===t.url){row.title=title;store.scheduleSave();}this.emit();});
  wc.on('did-fail-load',(_e,code,desc,url,main)=>{if(!main||code===-3)return;t.url=url||t.url;t.loading=false;clearTimeout(t.timer);t.error={code,message:desc};t.title='Не удалось открыть сайт';this.layout();this.emit();});
  wc.on('render-process-gone',(_e,d)=>{t.loading=false;clearTimeout(t.timer);t.error={code:d.reason,message:'Процесс страницы завершился'};this.layout();this.emit();});
  wc.on('unresponsive',()=>{this.toast='Страница не отвечает. Можно остановить её или закрыть вкладку.';this.emit();});
  wc.on('found-in-page',(_e,result)=>{this.findResult=result;this.win.webContents.send('find-result',result);});
  wc.on('context-menu',(_e,p)=>{const items=[];if(p.linkURL&&/^https?:/.test(p.linkURL))items.push({label:'Открыть в новой вкладке',click:()=>this.newTab(p.linkURL)},{label:'Копировать ссылку',click:()=>clipboard.writeText(p.linkURL)});if(p.selectionText)items.push({label:'Копировать',role:'copy'},{label:'Найти выделенное',click:()=>this.newTab((require('./navigation.cjs').searchEngines[store.data.settings.search])+encodeURIComponent(p.selectionText))});if(p.isEditable)items.push({role:'cut',label:'Вырезать'},{role:'copy',label:'Копировать'},{role:'paste',label:'Вставить'});if(!items.length)items.push({label:'Назад',enabled:wc.navigationHistory.canGoBack(),click:()=>stepHistory(t,-1,()=>{this.layout();this.emit();})},{label:'Обновить',click:()=>wc.reload()});Menu.buildFromTemplate(items).popup({window:this.win});});
  return view;
 }
 configurePopups(wc){
  wc.setWindowOpenHandler(({url})=>{if((!/^https?:\/\//i.test(url)&&url!=='about:blank')||(this.popupCount||0)>=8)return{action:'deny'};return{action:'allow',overrideBrowserWindowOptions:{width:640,height:780,minWidth:420,minHeight:400,autoHideMenuBar:true,title:'Noma — окно сайта',webPreferences:{preload:undefined,session:this.ses,nodeIntegration:false,nodeIntegrationInSubFrames:false,contextIsolation:true,sandbox:true,webSecurity:true,allowRunningInsecureContent:false,safeDialogs:true}}};});
  wc.on('did-create-window',(popup,{url})=>{this.popupCount=(this.popupCount||0)+1;popup.setMenu(null);popup.webContents.setWebRTCIPHandlingPolicy('disable_non_proxied_udp');const title=()=>{if(!popup.isDestroyed())popup.setTitle('Noma — '+(host(popup.webContents.getURL())||host(url)||'окно сайта'));};popup.on('page-title-updated',e=>{e.preventDefault();title();});popup.webContents.on('did-navigate',title);for(const event of ['will-navigate','will-redirect'])popup.webContents.on(event,(e,url)=>{if(!/^https?:\/\//i.test(url))e.preventDefault();});this.configurePopups(popup.webContents);popup.on('closed',()=>{this.popupCount=Math.max(0,(this.popupCount||1)-1);});title();});
 }
 navigate(t,input){let result;try{result=navigateInput(input,store.data.settings.search);}catch(e){this.toast=e.message;this.emit();return;}
  this.panel='';this.omnibox=false;t.error=null;t.url=result.url;t.route=result.kind==='internal'?result.url.slice(5):'';clearTimeout(t.timer);
  if(t.route){if(t.view)t.view.webContents.stop();t.title={newtab:'Новая вкладка',history:'История',bookmarks:'Закладки',downloads:'Загрузки',settings:'Настройки',extensions:'Расширения',profile:'Профиль'}[t.route]||'Новая вкладка';t.loading=false;}else{const wc=this.ensureView(t).webContents;t.loading=true;this.sessionReady.then(()=>{if(this.proxyError)throw Error('Не удалось применить прокси: '+this.proxyError);if(wc.isDestroyed()||t.url!==result.url||t.route)return;return wc.loadURL(t.url);}).catch(e=>{if(e.code==='ERR_ABORTED'||e.errno===-3)return;if(t.url===result.url&&!t.error){t.loading=false;clearTimeout(t.timer);t.error={code:e.code||e.errno,message:e.message};this.layout();this.emit();}});}
  this.layout();this.persist();this.emit();
 }
 closeTab(id){const at=this.tabs.findIndex(t=>t.id===id);if(at<0)return;const t=this.tabs[at];this.closed.push(t.url);if(this.closed.length>25)this.closed.shift();clearTimeout(t.timer);if(t.view){this.win.contentView.removeChildView(t.view);if(!t.view.webContents.isDestroyed())t.view.webContents.close({waitForBeforeUnload:false});}this.tabs.splice(at,1);if(!this.tabs.length)this.newTab();else if(this.active===id)this.activate(this.tabs[Math.min(at,this.tabs.length-1)].id);this.persist();this.layout();this.emit();}
 key(e,input){if(input.type!=='keyDown')return;const k=input.key.toLowerCase(),mod=input.control||input.meta;let action;if(mod&&k==='tab'){e.preventDefault();const at=this.tabs.findIndex(t=>t.id===this.active),step=input.shift?-1:1;this.activate(this.tabs[(at+step+this.tabs.length)%this.tabs.length].id);return;}else if(mod&&/^[1-9]$/.test(k)){e.preventDefault();const at=k==='9'?this.tabs.length-1:Math.min(Number(k)-1,this.tabs.length-1);if(this.tabs[at])this.activate(this.tabs[at].id);return;}else if(mod&&input.shift&&k==='n')action='private';else if(mod&&k==='l')action='focusAddress';else if(mod&&k==='t')action=input.shift?'reopen':'newTab';else if(mod&&k==='w')action='closeTab';else if(mod&&k==='f')action='find';else if(mod&&k==='h')action='history';else if(mod&&k==='j')action='downloads';else if(mod&&k==='d')action='bookmark';else if(mod&&['+','=','-','0'].includes(k)){e.preventDefault();const wc=this.current()?.view?.webContents;if(wc)wc.setZoomLevel(k==='0'?0:wc.getZoomLevel()+(k==='-'?-0.5:0.5));return;}else if(k==='f5')action='reload';else if(k==='f11'){e.preventDefault();this.win.setFullScreen(!this.win.isFullScreen());return;}else if(input.alt&&k==='left')action='back';else if(input.alt&&k==='right')action='forward';else if(k==='escape'){this.panel='';this.omnibox=false;this.find='';this.layout();this.emit();return;}
  if(action){e.preventDefault();if(action==='focusAddress'){this.win.webContents.focus();this.win.webContents.send('focus-address');}else this.command(action,{}).catch(()=>{});}
 }
 async suggest(text){
  this.suggestAbort?.abort();const ac=new AbortController();this.suggestAbort=ac;
  let local;try{local=localSuggestions(text,{history:this.private?[]:store.data.history,bookmarks:store.data.bookmarks,search:store.data.settings.search});}catch{return {items:[]};}
  if(this.private||!store.data.settings.suggestions||!maySuggest(text))return {items:local};
  const timer=setTimeout(()=>ac.abort(),2200);
  try{const r=await this.ses.fetch(suggestionURL(store.data.settings.search,text),{signal:ac.signal,credentials:'omit',redirect:'error'});if(r.ok){const raw=await r.text();if(raw.length<100000){const seen=new Set(local.map(x=>x.title.toLowerCase()));for(const title of parseSuggestions(JSON.parse(raw))){if(seen.has(title.toLowerCase()))continue;seen.add(title.toLowerCase());local.push({kind:'suggestion',title,detail:'Подсказка поиска',url:navigateInput(title,store.data.settings.search).url});}}}}catch{}finally{clearTimeout(timer);}
  return {items:local.slice(0,9)};
 }
 async importBookmarksFile(file){if(this.private)throw Error('Импорт недоступен в приватном окне');if(fs.statSync(file).size>20*1024*1024)throw Error('Файл больше 20 МБ');const incoming=parseBookmarks(fs.readFileSync(file,'utf8'));const merged=mergeBookmarks(store.data.bookmarks,incoming);store.data.bookmarks=merged.rows;store.save();this.toast='Импортировано закладок: '+merged.added;emitAll();return {added:merged.added};}
 async installExtensionFolder(folder,confirmed=false){if(this.private)throw Error('Расширения отключены в приватных окнах');const info=inspectExtension(folder);if(!confirmed){const r=await dialog.showMessageBox(this.win,{type:'warning',buttons:['Отмена','Установить'],defaultId:0,cancelId:0,message:'Установить «'+info.name+'»?',detail:'Расширение может читать и менять данные сайтов. Устанавливайте только из доверенного источника.\n\nЗапрошенные разрешения:\n'+(info.permissions.join('\n')||'Не указаны')});if(r.response!==1)return {cancelled:true};}const folderID=randomUUID(),destination=path.join(store.dir,'extensions',folderID);fs.mkdirSync(path.dirname(destination),{recursive:true});try{copyExtension(folder,destination);const ext=await normalSession.extensions.loadExtension(destination,{allowFileAccess:false});const saved={...info,id:ext.id,folderID,path:destination,enabled:true,error:''};store.data.extensions.push(saved);store.save();emitAll();return {id:ext.id};}catch(e){fs.rmSync(destination,{recursive:true,force:true});throw Error('Расширение не удалось загрузить: '+e.message);}}
 async diagnose(){this.diagnostics=[{target:'Проверка',status:'Проверяем через текущий профиль и прокси…'}];this.emit();const urls=[this.current()?.url,'https://www.google.com/','https://www.youtube.com/','https://ru.wikipedia.org/'].filter(u=>/^https?:/.test(u||''));const result=[];for(const url of [...new Set(urls)].slice(0,4)){const started=Date.now();try{const r=await this.ses.fetch(url,{signal:AbortSignal.timeout(10000),cache:'no-store'});await r.body?.cancel();result.push({target:new URL(url).origin,status:'HTTP '+r.status,ms:Date.now()-started});}catch(e){result.push({target:new URL(url).origin,status:String(e.message).slice(0,180),ms:Date.now()-started});}this.diagnostics=[...result];this.emit();}return result;}
 async command(action,p){const t=this.current(),wc=t?.view?.webContents;
  switch(action){
   case 'modal':this.modal=!!p.open;this.layout();break;
   case 'state':return this.state();case 'navigate':this.navigate(t,finiteString(p.input));break;
   case 'newTab':this.newTab(p.url?finiteString(p.url):'noma:newtab');setTimeout(()=>{if(!this.win.isDestroyed()){this.win.webContents.focus();this.win.webContents.send('focus-address');}},90);break;
   case 'activate':this.activate(finiteString(p.id,80));break;case 'closeTab':this.closeTab(p.id||this.active);break;
   case 'reopen':this.newTab(this.closed.pop()||'noma:newtab');break;
   case 'reorder':{const from=this.tabs.findIndex(x=>x.id===p.from),to=this.tabs.findIndex(x=>x.id===p.to);if(from>=0&&to>=0){this.tabs.splice(to,0,this.tabs.splice(from,1)[0]);this.emit();}break;}
   case 'reload':if(wc)this.navigate(t,t.url);break;
   case 'stop':wc?.stop();t.loading=false;clearTimeout(t.timer);this.emit();break;
   case 'back':if(wc?.navigationHistory.canGoBack())stepHistory(t,-1,()=>{this.layout();this.emit();});break;
   case 'forward':if(wc?.navigationHistory.canGoForward())stepHistory(t,1,()=>{this.layout();this.emit();});break;
   case 'home':this.navigate(t,'noma:newtab');break;
   case 'history':case 'downloads':case 'profile':this.panel=this.panel===action?'':action;this.omnibox=false;this.win.webContents.focus();this.layout();this.emit();break;
   case 'historyPage':case 'downloadsPage':this.navigate(this.newTab(), 'noma:'+action.replace('Page',''));break;
   case 'bookmarks':case 'settings':case 'extensions':this.navigate(t,'noma:'+action);break;
   case 'panel':this.panel=this.panel===p.name?'':(['menu','protection','downloads','history','profile'].includes(p.name)?p.name:'');this.omnibox=false;this.layout();this.emit();break;
   case 'omnibox':this.omnibox=Boolean(p.open);this.omniHeight=Math.max(56,Math.min(460,Number(p.height)||300));if(!p.open)this.suggestAbort?.abort();this.layout();break;
   case 'suggest':return this.suggest(finiteString(p.text,300));
   case 'find':this.find=this.find?'': ' ';this.win.webContents.focus();this.layout();this.emit();break;
   case 'findText':if(wc&&p.text)return{requestId:wc.findInPage(finiteString(p.text,1000),{forward:p.forward!==false,findNext:!!p.next})};wc?.stopFindInPage('clearSelection');break;
   case 'closeFind':this.find='';wc?.stopFindInPage('clearSelection');this.layout();this.emit();break;
   case 'bookmark':if(/^https?:/.test(t.url)){store.bookmark(t.url,t.title);this.toast=store.data.bookmarks.some(b=>b.url===t.url)?'Страница сохранена в закладках':'Закладка удалена';this.emit();}break;
   case 'removeBookmark':store.data.bookmarks=store.data.bookmarks.filter(x=>x.id!==p.id);store.save();this.emit();break;
   case 'deleteHistory':store.data.history=store.data.history.filter(x=>x.id!==p.id);store.save();this.emit();break;
   case 'historyCount':return {count:this.private?0:store.data.history.filter(x=>historyMatches(x,p)).length};
   case 'clearHistory':{if(!this.private){const before=store.data.history.length;store.data.history=clearVisits(store.data.history,p);store.save();this.toast='Удалено записей: '+(before-store.data.history.length);emitAll();}break;}
   case 'shortcut':{if(store.data.shortcuts.length>=16)throw Error('Можно добавить до 16 сайтов');const url=guardWebURL(finiteString(p.url)),name=finiteString(p.name,60).trim();if(!name)throw Error('Введите название');store.data.shortcuts.push({id:randomUUID(),url,name,icon:'globe'});store.save();this.emit();break;}
   case 'removeShortcut':store.data.shortcuts=store.data.shortcuts.filter(s=>s.id!==p.id);store.save();this.emit();break;
   case 'settingsSave':{const s=store.data.settings;if(p.search&&['duckduckgo','google','yandex','brave'].includes(p.search))s.search=p.search;if(p.theme&&['system','dark','light'].includes(p.theme)){s.theme=p.theme;nativeTheme.themeSource=s.theme;}for(const k of ['blocking','restore','rememberHistory','suggestions'])if(typeof p[k]==='boolean')s[k]=p[k];store.save();emitAll();break;}
   case 'proxy':{const value=finiteString(p.value,250).trim();const conf=validProxy(value);for(const c of controllers){await c.ses.setProxy(conf);await c.ses.closeAllConnections();}if(!this.private){store.data.settings.proxy=value;store.save();}this.toast='Прокси применён. Обновите открытые сайты.';this.emit();break;}
   case 'toggleProtection':{const h=host(t.url);if(h){if(disabledHosts.has(h))disabledHosts.delete(h);else disabledHosts.add(h);this.emit();}break;}
   case 'diagnose':return this.diagnose();
   case 'exportDiagnostics':{const r=await dialog.showSaveDialog(this.win,{defaultPath:'network-diagnostics.json'});if(!r.canceled)fs.writeFileSync(r.filePath,JSON.stringify({version:app.getVersion(),electron:process.versions.electron,chromium:process.versions.chrome,proxy:!!store.data.settings.proxy,checks:this.diagnostics,errors:t.errors},null,2));break;}
   case 'clearData':{const r=await dialog.showMessageBox(this.win,{buttons:['Отмена','Очистить'],defaultId:0,cancelId:0,message:'Очистить cookies и кэш?',detail:'Произойдёт выход из аккаунтов. История, закладки и файлы останутся.'});if(r.response===1){await this.ses.clearStorageData();await this.ses.clearCache();this.toast='Cookies и кэш очищены';this.emit();}break;}
   case 'downloadCancel':{const d=activeDownloads.find(x=>x.id===p.id&&(!x.private||x.owner===this.win.id));d?.item?.cancel();break;}
   case 'downloadShow':{const d=[...activeDownloads,...(this.private?[]:store.data.downloads||[])].find(x=>x.id===p.id&&(!x.private||x.owner===this.win.id));if(d?.success&&d.path)shell.showItemInFolder(d.path);break;}
   case 'downloadPause':{const d=activeDownloads.find(x=>x.id===p.id&&(!x.private||x.owner===this.win.id));if(d?.item){if(d.item.isPaused())d.item.resume();else d.item.pause();d.paused=d.item.isPaused();this.emit();}break;}
   case 'downloadOpen':{const d=[...activeDownloads,...(this.private?[]:store.data.downloads||[])].find(x=>x.id===p.id&&(!x.private||x.owner===this.win.id));if(d?.success&&d.path){const error=await shell.openPath(d.path);if(error)throw Error(error);}break;}
   case 'private':new Controller(true);break;
   case 'minimize':this.win.minimize();break;case 'maximize':this.win.isMaximized()?this.win.unmaximize():this.win.maximize();break;case 'closeWindow':this.win.close();break;
   case 'copyURL':clipboard.writeText(t.url);break;
   case 'readSelection':return wc?String(await wc.executeJavaScript('window.getSelection().toString()')).slice(0,12000):'';
   case 'googleSignIn':this.newTab('https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmyaccount.google.com%2F');break;
   case 'googleAccount':this.newTab('https://myaccount.google.com/');break;
   case 'gmail':this.newTab('https://mail.google.com/');break;
   case 'youtubeAccount':this.newTab('https://www.youtube.com/');break;
   case 'profileSave':{if(this.private)throw Error('Приватное окно не меняет обычный профиль');const name=finiteString(p.name,60).trim();if(!name)throw Error('Введите имя профиля');store.data.profile.name=name;store.save();emitAll();break;}
   case 'profileAvatar':{if(this.private)throw Error('Недоступно в приватном окне');const r=await dialog.showOpenDialog(this.win,{title:'Аватар профиля Noma',properties:['openFile'],filters:[{name:'Изображения',extensions:['png','jpg','jpeg','webp']}]});if(r.canceled)break;const file=r.filePaths[0];if(fs.statSync(file).size>4*1024*1024)throw Error('Выберите изображение до 4 МБ');const image=nativeImage.createFromPath(file);if(image.isEmpty())throw Error('Не удалось прочитать изображение');store.data.profile.avatar=image.resize({width:96,height:96,quality:'good'}).toDataURL();store.save();emitAll();break;}
   case 'profileAvatarRemove':if(!this.private){store.data.profile.avatar='';store.save();emitAll();}break;
   case 'importBookmarks':{if(this.private)throw Error('Недоступно в приватном окне');const r=await dialog.showOpenDialog(this.win,{title:'Импорт закладок',properties:['openFile'],filters:[{name:'Закладки HTML / Chrome JSON',extensions:['html','htm','json']},{name:'Файл Bookmarks',extensions:['*']}]});if(!r.canceled)return this.importBookmarksFile(r.filePaths[0]);break;}
   case 'exportBookmarks':{const r=await dialog.showSaveDialog(this.win,{title:'Экспорт закладок',defaultPath:'Noma-bookmarks.html',filters:[{name:'HTML',extensions:['html']}]});if(!r.canceled)fs.writeFileSync(r.filePath,exportBookmarks(store.data.bookmarks),'utf8');break;}
   case 'extensionInstall':{if(this.private)throw Error('Расширения отключены в приватных окнах');const r=await dialog.showOpenDialog(this.win,{title:'Папка распакованного расширения с manifest.json',properties:['openDirectory']});if(!r.canceled)return this.installExtensionFolder(r.filePaths[0]);break;}
   case 'extensionToggle':{if(this.private)throw Error('Недоступно в приватном окне');const ext=store.data.extensions.find(x=>x.id===p.id);if(!ext)throw Error('Расширение не найдено');if(ext.enabled){normalSession.extensions.removeExtension(ext.id);ext.enabled=false;ext.error='';}else{try{const loaded=await normalSession.extensions.loadExtension(ext.path,{allowFileAccess:false});ext.id=loaded.id;ext.enabled=true;ext.error='';}catch(e){ext.error=e.message;store.save();emitAll();throw e;}}store.save();emitAll();break;}
   case 'extensionRemove':{if(this.private)throw Error('Недоступно в приватном окне');const ext=store.data.extensions.find(x=>x.id===p.id);if(!ext)break;const r=await dialog.showMessageBox(this.win,{type:'question',message:'Удалить «'+ext.name+'»?',buttons:['Отмена','Удалить'],defaultId:0,cancelId:0});if(r.response!==1)break;normalSession.extensions.removeExtension(ext.id);store.data.extensions=store.data.extensions.filter(x=>x!==ext);if(path.dirname(ext.path)===path.join(store.dir,'extensions'))fs.rmSync(ext.path,{recursive:true,force:true});store.save();emitAll();break;}
   default:throw Error('Неизвестная команда');
  }return{ok:true};
 }
}
ipcMain.handle('command',async(e,action,payload)=>{const c=[...controllers].find(c=>c.win.webContents===e.sender);if(!c||e.senderFrame!==c.win.webContents.mainFrame||e.senderFrame.url!==uiURL)throw Error('Untrusted IPC sender');if(typeof action!=='string'||!payload||typeof payload!=='object')throw Error('Invalid command');try{return await c.command(action,payload);}catch(err){return{error:String(err.message)};}});
app.on('web-contents-created',(_e,wc)=>{wc.on('will-attach-webview',e=>e.preventDefault());});
app.on('certificate-error',(event,_wc,_url,_error,_certificate,callback)=>{event.preventDefault();callback(false);});
app.on('before-quit',()=>{shuttingDown=true;if(store){store.data.clean=true;store.save();}});
app.on('window-all-closed',()=>app.quit());
app.whenReady().then(async()=>{
 if(!testing&&!app.requestSingleInstanceLock()){app.quit();return;}
 console.log('NOMA_STARTUP app ready');Menu.setApplicationMenu(null);store=new Store(app.getPath('userData'));nativeTheme.themeSource=store.data.settings.theme;
 const rules=['easylist','easyprivacy'].map(f=>fs.readFileSync(path.join(__dirname,'../filters',f+'.txt'),'utf8')).join('\n');const digest=require('node:crypto').createHash('sha256').update(rules).digest('hex').slice(0,16);const cache=path.join(app.getPath('userData'),'filters-'+digest+'.bin');try{engine=FiltersEngine.deserialize(new Uint8Array(fs.readFileSync(cache)));}catch{engine=FiltersEngine.parse(rules,{loadCosmeticFilters:false,enableCompression:true});fs.writeFileSync(cache,engine.serialize());}
 console.log('NOMA_STARTUP filters ready');normalSession=session.fromPartition('persist:web');setupSession(normalSession);await normalSession.setProxy(validProxy(store.data.settings.proxy));
 for(const ext of store.data.extensions){if(!ext.enabled)continue;try{const loaded=await normalSession.extensions.loadExtension(ext.path,{allowFileAccess:false});ext.id=loaded.id;ext.error='';}catch(e){ext.error=e.message;}}
 if(sessionTesting){const cookies=await normalSession.cookies.get({url:'https://noma-session-test.invalid/',name:'noma-restart-test'});if(cookies.length!==1||cookies[0].value!=='fixture-only')throw Error('Persistent cookie restart check failed');if(!normalSession.extensions.getAllExtensions().some(e=>e.name==='Noma fixture extension'))throw Error('Extension restart check failed');console.log('NOMA_SESSION_OK');app.exit(0);return;}
 console.log('NOMA_STARTUP session ready');const c=new Controller();console.log('NOMA_STARTUP window created');app.on('second-instance',()=>{c.win.restore();c.win.focus();});
 if(selfTesting)setTimeout(()=>{console.error('Self-test watchdog expired');app.exit(2);},420000).unref();
 if(selfTesting)require('../tests/electron.cjs').run({app,c,store,controllers,Controller,engine}).catch(e=>{console.error(e);app.exit(1);});
 if(smokeTesting)c.win.webContents.once('did-finish-load',()=>setTimeout(()=>{if(c.win.isDestroyed())return app.exit(1);console.log('NOMA_SMOKE_OK');c.win.destroy();app.exit(0);},750));
}).catch(e=>{console.error('STARTUP FAILURE',e.stack||e);if(!testing)dialog.showErrorBox('Не удалось запустить браузер',e.message);app.exit(1);});
