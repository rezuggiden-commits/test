'use strict';
const {host,navigateInput}=require('./navigation.cjs');
const periods={hour:3600000,day:86400000,week:604800000,month:2592000000,all:Infinity};
function historyMatches(row,filter={},now=Date.now()){
 if(!Object.hasOwn(periods,filter.period||'all'))throw Error('Неизвестный период');
 const domain=String(filter.domain||'').trim().toLowerCase().replace(/^www\./,'');
 if(domain&&!/^[\p{L}\p{N}.-]+$/u.test(domain))throw Error('Укажите домен без пути, например youtube.com');
 const h=host(row.url).toLowerCase().replace(/^www\./,'');
 return row.time>=now-periods[filter.period||'all']&&(!domain||h===domain||h.endsWith('.'+domain));
}
function clearVisits(rows,filter,now=Date.now()){historyMatches({url:'',time:now},filter,now);return rows.filter(r=>!historyMatches(r,filter,now));}
function localSuggestions(text,{history=[],bookmarks=[],search='duckduckgo'}={}){
 const query=text.trim().slice(0,300);if(!query)return [];
 const target=navigateInput(query,search),q=query.toLocaleLowerCase();
 const results=[{kind:target.kind==='search'?'search':'url',title:query,url:target.url,detail:target.kind==='search'?'Найти':'Перейти'}],seen=new Set([target.url]);
 for(const [kind,rows]of [['bookmark',bookmarks],['history',history]])for(const r of rows){if(results.length>=7)break;if(!seen.has(r.url)&&(r.title+' '+r.url).toLocaleLowerCase().includes(q)){seen.add(r.url);results.push({kind,title:r.title||host(r.url),url:r.url,detail:r.url});}}
 return results;
}
function suggestionURL(engine,q){const query=encodeURIComponent(q);return engine==='yandex'?`https://suggest.yandex.ru/suggest-ff.cgi?part=${query}`:engine==='duckduckgo'?`https://duckduckgo.com/ac/?q=${query}&type=list`:`https://suggestqueries.google.com/complete/search?client=firefox&q=${query}`;}
function parseSuggestions(data){const rows=Array.isArray(data?.[1])?data[1]:Array.isArray(data)?data:[];return rows.map(x=>typeof x==='string'?x:x?.phrase).filter(x=>typeof x==='string'&&x.length<300).slice(0,7);}
function maySuggest(q){return q.length>=2&&q.length<=160&&!/[\/@:?=#\\]/.test(q)&&!/^\S+\.\S+$/.test(q)&&!/[\w.+-]+@[\w.-]+/.test(q);}
module.exports={clearVisits,historyMatches,localSuggestions,suggestionURL,parseSuggestions,maySuggest};
