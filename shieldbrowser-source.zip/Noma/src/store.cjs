'use strict';
const {randomUUID}=require('node:crypto');
const fs=require('node:fs'),path=require('node:path');
const defaults=()=>({version:1,settings:{search:'duckduckgo',theme:'system',blocking:true,proxy:'',restore:true,rememberHistory:true,aiModel:'qwen3:4b'},history:[],bookmarks:[],shortcuts:[],session:[],clean:true});
class Store{
 constructor(dir,ephemeral=false){this.dir=dir;this.ephemeral=ephemeral;this.data=defaults();this.file=path.join(dir,'browser.json');if(!ephemeral){fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(this.file)){try{const d=JSON.parse(fs.readFileSync(this.file,'utf8'));if(d.version!==1||!Array.isArray(d.history)||!Array.isArray(d.bookmarks))throw Error('Invalid profile');this.data={...defaults(),...d,settings:{...defaults().settings,...d.settings}};}catch(e){fs.copyFileSync(this.file,this.file+'.corrupt-'+Date.now());throw new Error('Профиль повреждён. Резервная копия сохранена; данные не перезаписаны.');}}}}
 save(){if(this.ephemeral)return;const temp=this.file+'.tmp';const fd=fs.openSync(temp,'w',0o600);try{fs.writeFileSync(fd,JSON.stringify(this.data));fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.renameSync(temp,this.file);}
 visit(url,title){if(this.ephemeral||!this.data.settings.rememberHistory||!/^https?:/.test(url))return;const now=Date.now();const first=this.data.history[0];if(first?.url===url&&now-first.time<15000){first.title=title;first.time=now;}else this.data.history.unshift({id:randomUUID(),url,title:title||url,time:now});this.data.history=this.data.history.slice(0,10000);this.save();}
 bookmark(url,title){const found=this.data.bookmarks.find(x=>x.url===url);if(found)this.data.bookmarks=this.data.bookmarks.filter(x=>x.url!==url);else this.data.bookmarks.unshift({id:randomUUID(),url,title:title||url,time:Date.now()});this.save();}
}
module.exports={Store,defaults};
