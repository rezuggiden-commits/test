# Third-party notices and sources

Noma's application code is MPL-2.0. Copyright 2026 Noma contributors.
This is a new Electron implementation, not a rebrand of a binary from another browser.

- Electron 44.9.3, MIT; Chromium/BoringSSL/FFmpeg and their component licenses are included in Electron's LICENSE and LICENSES.chromium.html in the portable directory. https://github.com/electron/electron/tree/v44.9.3
- @ghostery/adblocker 2.20.1 and its MPL-2.0 dependencies: https://github.com/ghostery/adblocker ; production npm package manifests and LICENSE files reside inside resources/app.asar/node_modules. No Ghostery Electron preload is used.
- EasyList / EasyPrivacy: distributed snapshots from https://easylist-downloads.adblockplus.org/easylist.txt and https://easylist-downloads.adblockplus.org/easyprivacy.txt . The upstream license page offers GPL-3.0-or-later or CC-BY-SA-3.0-or-later. Distributed here under CC-BY-SA-4.0, unmodified, authors as credited in each file and upstream repository https://github.com/easylist/easylist . License: https://creativecommons.org/licenses/by-sa/4.0/ . Source copies are in filters/. No cosmetic or scriptlet application.
- Local brand SVGs: Simple Icons, CC0-1.0 https://github.com/simple-icons/simple-icons . Google G PNG: Google static branding asset https://www.gstatic.com/images/branding/product/2x/googleg_48dp.png (used to identify the destination; not covered by Simple Icons CC0). Google, YouTube, Wikipedia and GitHub trademarks belong to their owners. The marks identify destination sites, not an affiliation. Assets are shipped locally, no third-party favicon service.
- Architectural research/reference: Min https://github.com/minbrowser/min (Apache-2.0). No Min source code or prebuilt binary is included; its WebContentsView/tab architecture and feature set were reviewed as an existing browser baseline.

The full source archive, including lockfile and filters, accompanies development builds in the repository. Rebuilding requires Node 24 and npm ci, npm test, npm run package (on Windows). This development preview does not have signed binaries or an automatic security updater.
