#include "shield/internal_pages.h"
#include "include/cef_scheme.h"
#include "include/cef_resource_handler.h"
#include "include/cef_parser.h"
#include "include/cef_command_line.h"
#include <QFile>
#include <atomic>
#include <algorithm>
#include <cstring>
namespace shield {
namespace {
std::atomic<bool> lightTheme{false};
class App final:public CefApp {
 public:
 void OnBeforeCommandLineProcessing(const CefString&,CefRefPtr<CefCommandLine> c) override {c->AppendSwitchWithValue("force-webrtc-ip-handling-policy","disable_non_proxied_udp");}
 void OnRegisterCustomSchemes(CefRawPtr<CefSchemeRegistrar> registrar) override {
  registrar->AddCustomScheme("shield",CEF_SCHEME_OPTION_STANDARD|CEF_SCHEME_OPTION_SECURE|CEF_SCHEME_OPTION_DISPLAY_ISOLATED);
 }
 private: IMPLEMENT_REFCOUNTING(App);
};
class Page final:public CefResourceHandler {
 public:
  explicit Page(std::string body,int status):body_(std::move(body)),status_(status){}
  bool Open(CefRefPtr<CefRequest>,bool& handle,CefRefPtr<CefCallback>) override {handle=true;return true;}
  void GetResponseHeaders(CefRefPtr<CefResponse> response,int64_t& length,CefString&) override {
   response->SetStatus(status_);response->SetMimeType("text/html");response->SetCharset("utf-8");
   response->SetHeaderByName("Cache-Control","no-store",true);
   response->SetHeaderByName("Content-Security-Policy","default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'none'; base-uri 'none'; form-action https://www.google.com; frame-ancestors 'none'",true);
   response->SetHeaderByName("Referrer-Policy","no-referrer",true);length=static_cast<int64_t>(body_.size());
  }
  bool Read(void* out,int size,int& read,CefRefPtr<CefResourceReadCallback>) override {
   if(size<=0){read=0;return false;}
   read=static_cast<int>(std::min<std::size_t>(size,body_.size()-position_));if(!read)return false;
   std::memcpy(out,body_.data()+position_,read);position_+=read;return true;
  }
  void Cancel() override {}
 private:std::string body_;int status_;std::size_t position_=0;IMPLEMENT_REFCOUNTING(Page);
};
class Factory final:public CefSchemeHandlerFactory {
 public: explicit Factory(std::string html):html_(std::move(html)){}
  CefRefPtr<CefResourceHandler> Create(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,const CefString&,CefRefPtr<CefRequest> request) override {
   CefURLParts p;bool ok=CefParseURL(request->GetURL(),p);
   auto path=CefString(&p.path).ToString();
   if(!ok||request->GetMethod()!="GET"||(path!="/"&&!path.empty()))return new Page("Not found",404);
   auto html=html_;auto at=html.find("__THEME__");if(at!=std::string::npos)html.replace(at,9,lightTheme.load()?"light":"dark");
   return new Page(std::move(html),200);
  }
 private:std::string html_;IMPLEMENT_REFCOUNTING(Factory);
};
}
CefRefPtr<CefApp> createApp(){return new App;}
bool registerInternalPages(){QFile f(":/pages/newtab.html"),e(":/pages/error.html");if(!f.open(QIODevice::ReadOnly)||!e.open(QIODevice::ReadOnly))return false;return CefRegisterSchemeHandlerFactory("shield","newtab",new Factory(f.readAll().toStdString())) && CefRegisterSchemeHandlerFactory("shield","error",new Factory(e.readAll().toStdString()));}
void setInternalTheme(bool light){lightTheme.store(light);}
}
