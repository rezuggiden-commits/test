#include "shield/browser_page.h"
#include "shield/cef_task.h"
#include <QCoreApplication>
#include <QPointer>
#include <QResizeEvent>
#include <QShowEvent>
#include <QTimer>
#include <windows.h>
#include <map>
#include "include/cef_client.h"
#include "include/cef_parser.h"
#include "include/cef_download_handler.h"
#include "include/cef_permission_handler.h"
namespace shield {
namespace {
unsigned resourceType(cef_resource_type_t type) {
  switch(type) {
    case RT_MAIN_FRAME:return 1; case RT_SUB_FRAME:return 2; case RT_SCRIPT:return 3;
    case RT_IMAGE:return 4; case RT_STYLESHEET:return 5;case RT_XHR:return 6;
    case RT_FONT_RESOURCE:return 7;case RT_MEDIA:return 8;case RT_PING:return 10;
    case RT_OBJECT:return 11;default:return 0;
  }
}
}
class BrowserClient final : public CefClient,public CefLifeSpanHandler,public CefDisplayHandler,
 public CefLoadHandler,public CefRequestHandler,public CefResourceRequestHandler,
 public CefPermissionHandler,public CefKeyboardHandler,public CefDownloadHandler {
 public:
  BrowserClient(BrowserPage* page,std::shared_ptr<AdBlockService> adblock): page_(page),adblock_(std::move(adblock)) {}
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override{return this;}
  CefRefPtr<CefDisplayHandler> GetDisplayHandler() override{return this;}
  CefRefPtr<CefLoadHandler> GetLoadHandler() override{return this;}
  CefRefPtr<CefRequestHandler> GetRequestHandler() override{return this;}
  CefRefPtr<CefPermissionHandler> GetPermissionHandler() override{return this;}
  CefRefPtr<CefKeyboardHandler> GetKeyboardHandler() override{return this;}
  CefRefPtr<CefDownloadHandler> GetDownloadHandler() override{return this;}
  template<class F> void deliver(F f) {
    auto page=page_;
    QMetaObject::invokeMethod(QCoreApplication::instance(), [page,f=std::move(f)] {if(page) f(*page);},Qt::QueuedConnection);
  }
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    deliver([browser](BrowserPage& p){p.created(browser);});
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {
    closed_.store(true);downloads_.clear(); deliver([](BrowserPage& p){p.beforeClose();});
  }
  bool DoClose(CefRefPtr<CefBrowser> browser) override {
    // Windowed Alloy's default WM_CLOSE targets the Qt TOP-LEVEL window, not
    // this tab. Tear down only CEF's child HWND on its owning CEF UI thread.
    // Defer teardown until after this callback returns to avoid reentrancy.
    auto self=CefRefPtr<BrowserClient>(this);
    const bool posted=onCefUi([self,browser]{if(!browser->IsValid())return;
      auto hwnd=browser->GetHost()->GetWindowHandle();
      if(hwnd && IsWindow(hwnd) && !DestroyWindow(hwnd))
        self->deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("Ошибка уничтожения окна CEF; завершение приостановлено"));});
    });
    if(!posted)deliver([](BrowserPage& p){emit p.loadFailed(QString::fromUtf8("CEF не принял задачу закрытия; завершение приостановлено"));});
    return true;
  }
  void OnTitleChange(CefRefPtr<CefBrowser>,const CefString& title) override {
    title_=QString::fromStdWString(title.ToWString());
    deliver([s=QString::fromStdWString(title.ToWString())](BrowserPage& p){emit p.titleChanged(s);});
  }
  void OnAddressChange(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,const CefString& url) override {
    if(!frame->IsMain())return;
    count_=0;
    std::atomic_store(&topUrl_,std::make_shared<const std::string>(url.ToString()));
    deliver([s=QString::fromStdWString(url.ToWString())](BrowserPage& p){p.url_=s;emit p.addressChanged(s);emit p.blockedChanged(0);});
  }
  void OnLoadingStateChange(CefRefPtr<CefBrowser>,bool loading,bool back,bool forward) override {
    deliver([=](BrowserPage& p){emit p.loadingChanged(loading,back,forward);});
  }
  void OnLoadEnd(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,int status) override {
    if(frame->IsMain() && status>=200 && status<400) {
      const auto loadedUrl=QString::fromStdWString(frame->GetURL().ToWString());
      const auto loadedTitle=title_;
      deliver([loadedUrl,loadedTitle](BrowserPage& p){emit p.completed(loadedUrl,loadedTitle);});
    }
  }
  void OnLoadError(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame> frame,ErrorCode error,const CefString& text,const CefString&) override {
    if(frame->IsMain() && error!=ERR_ABORTED) deliver([s=QString::fromStdWString(text.ToWString())](BrowserPage& p){emit p.loadFailed(s);});
  }
  bool OnBeforePopup(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,int,const CefString& target,const CefString&,
    CefLifeSpanHandler::WindowOpenDisposition,bool userGesture,const CefPopupFeatures&,CefWindowInfo&,CefRefPtr<CefClient>&,
    CefBrowserSettings&,CefRefPtr<CefDictionaryValue>&,bool*) override {
    if(userGesture) deliver([s=QString::fromStdWString(target.ToWString())](BrowserPage& p){emit p.popupRequested(s);});
    return true; // Never create an unmanaged browser; user-initiated links become tabs.
  }
  bool OnBeforeBrowse(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,CefRefPtr<CefRequest> request,bool,bool) override {
    CefURLParts parts;
    if(!CefParseURL(request->GetURL(),parts)) return true;
    const auto scheme=CefString(&parts.scheme).ToString();
    return scheme!="http" && scheme!="https" && scheme!="about" && scheme!="blob";
  }
  CefRefPtr<CefResourceRequestHandler> GetResourceRequestHandler(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,
    CefRefPtr<CefRequest>,bool,bool,const CefString&,bool&) override {return this;}
  ReturnValue OnBeforeResourceLoad(CefRefPtr<CefBrowser> browser,CefRefPtr<CefFrame> frame,
    CefRefPtr<CefRequest> request,CefRefPtr<CefCallback>) override {
    // CEF IO thread: immutable rules snapshot; no disk, network or Qt widgets.
    if(request->GetResourceType()==RT_MAIN_FRAME) return RV_CONTINUE;
    // Resource callbacks may outlive OnBeforeClose. Never dereference browser
    // or frame here: use a thread-safe main-document snapshot instead.
    if(closed_.load())return RV_CANCEL;
    auto sourceSnapshot=std::atomic_load(&topUrl_);
    const std::string source=sourceSnapshot?*sourceSnapshot:std::string{};
    if(adblock_->block(request->GetURL().ToString(),source,resourceType(request->GetResourceType()))) {
      const auto n=++count_;
      // Batch UI counters: poll from the Qt timer instead of posting per blocked request.
      (void)n; return RV_CANCEL;
    }
    return RV_CONTINUE;
  }
  bool OnCertificateError(CefRefPtr<CefBrowser>,cef_errorcode_t,const CefString&,CefRefPtr<CefSSLInfo>,CefRefPtr<CefCallback>) override {
    return false; // Engine cancels certificate errors. No insecure bypass.
  }
  bool OnRequestMediaAccessPermission(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,const CefString&,uint32_t,
    CefRefPtr<CefMediaAccessCallback> callback) override {callback->Cancel();return true;}
  bool OnShowPermissionPrompt(CefRefPtr<CefBrowser>,uint64_t,const CefString&,uint32_t,
    CefRefPtr<CefPermissionPromptCallback> callback) override {callback->Continue(CEF_PERMISSION_RESULT_DENY);return true;}
  bool OnPreKeyEvent(CefRefPtr<CefBrowser>,const CefKeyEvent& event,CefEventHandle,bool* shortcut) override {
    if(event.type!=KEYEVENT_RAWKEYDOWN)return false;
    const bool ctrl=event.modifiers & EVENTFLAG_CONTROL_DOWN;
    const bool alt=event.modifiers & EVENTFLAG_ALT_DOWN;
    const int key=event.windows_key_code;
    if((ctrl && (key=='T'||key=='W'||key=='L'||key=='R'||key=='D'||key=='H'||key=='J'||key=='N'||key=='F'||key==VK_OEM_PLUS||key==VK_OEM_MINUS||key=='0')) ||
       (alt && (key==VK_LEFT||key==VK_RIGHT))) {
      int mods=(ctrl?int(Qt::ControlModifier):0)|(alt?int(Qt::AltModifier):0)|((event.modifiers&EVENTFLAG_SHIFT_DOWN)?int(Qt::ShiftModifier):0);
      deliver([key,mods](BrowserPage& p){emit p.shortcut(key,mods);});*shortcut=true;return true;
    }
    return false;
  }
  bool OnBeforeDownload(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem>,const CefString&,
    CefRefPtr<CefBeforeDownloadCallback> callback) override {callback->Continue(CefString(),true);return true;}
  void OnDownloadUpdated(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,CefRefPtr<CefDownloadItemCallback> callback) override {
    auto id=item->GetId();
    if(item->IsInProgress())downloads_[id]=callback;else downloads_.erase(id);
    auto name=QString::fromStdWString(item->GetFullPath().ToWString());
    if(name.isEmpty())name=QString::fromStdWString(item->GetURL().ToWString());
    auto received=item->GetReceivedBytes(), total=item->GetTotalBytes();bool done=item->IsComplete(),cancelled=item->IsCanceled();
    deliver([=](BrowserPage& p){emit p.downloadChanged(id,name,received,total,done,cancelled);});
  }
  void cancel(unsigned id) {auto it=downloads_.find(id);if(it!=downloads_.end())it->second->Cancel();}
  std::atomic<quint64> count_{0};
 private:
  QPointer<BrowserPage> page_;
  std::shared_ptr<AdBlockService> adblock_;
  QString title_; // CEF UI thread only; copied with completed-document events.
  std::atomic<bool> closed_{false};
  std::shared_ptr<const std::string> topUrl_;
  std::map<unsigned,CefRefPtr<CefDownloadItemCallback>> downloads_; // CEF UI only
  IMPLEMENT_REFCOUNTING(BrowserClient);
};
BrowserPage::BrowserPage(CefRefPtr<CefRequestContext> context,std::shared_ptr<AdBlockService> adblock,QWidget* parent)
 :QWidget(parent),context_(context),adblock_(std::move(adblock)) {
  setAttribute(Qt::WA_NativeWindow);setFocusPolicy(Qt::StrongFocus);
  auto* client=new BrowserClient(this,adblock_);client_=client;
  auto* timer=new QTimer(this);timer->setInterval(250);
  connect(timer,&QTimer::timeout,this,[this,client]{emit blockedChanged(client->count_.load());});timer->start();
}
BrowserPage::~BrowserPage() = default;
void BrowserPage::showEvent(QShowEvent* e) {
  QWidget::showEvent(e);
  if(started_)return; started_=true;
  CefWindowInfo info;
  info.SetAsChild(reinterpret_cast<HWND>(winId()),CefRect(0,0,int(width()*devicePixelRatioF()),int(height()*devicePixelRatioF())));
  info.runtime_style=CEF_RUNTIME_STYLE_ALLOY;
  CefBrowserSettings settings;
  if(!CefBrowserHost::CreateBrowser(info,client_,url_.toStdWString(),settings,nullptr,context_)) {
    started_=false; emit loadFailed(tr("CEF не создал окно браузера"));
  }
}
void BrowserPage::created(CefRefPtr<CefBrowser> browser) {browser_=browser;if(closing_)shutdown();else fit();}
void BrowserPage::beforeClose() {browser_=nullptr;emit closed();}
void BrowserPage::open(const QString& url) {url_=url;command([u=url.toStdWString()](auto browser){browser->GetMainFrame()->LoadURL(u);});}
void BrowserPage::command(const std::function<void(CefRefPtr<CefBrowser>)>& f) {
  if(browser_) {auto b=browser_;onCefUi([b,f]{if(b->IsValid())f(b);});}
}
void BrowserPage::shutdown() {
  closing_=true;
  if(browser_)command([](auto b){b->GetHost()->CloseBrowser(true);});
  else if(!started_)QTimer::singleShot(0,this,[this]{emit closed();});
}
void BrowserPage::cancelDownload(unsigned id) {auto client=CefRefPtr<BrowserClient>(static_cast<BrowserClient*>(client_.get()));onCefUi([client,id]{client->cancel(id);});}
void BrowserPage::fit() {
  command([w=int(width()*devicePixelRatioF()),h=int(height()*devicePixelRatioF())](auto b){
    SetWindowPos(b->GetHost()->GetWindowHandle(),nullptr,0,0,w,h,SWP_NOZORDER|SWP_NOACTIVATE);
  });
}
void BrowserPage::resizeEvent(QResizeEvent* e){QWidget::resizeEvent(e);fit();}
void BrowserPage::focusInEvent(QFocusEvent* e){QWidget::focusInEvent(e);command([](auto b){b->GetHost()->SetFocus(true);});}
}
