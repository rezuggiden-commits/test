#include "shield/browser_tabs.h"
#include <QTabBar>
#include <QStackedWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QToolButton>
#include <QLabel>
#include <QMouseEvent>
#include <QWindow>
#include <QProgressBar>
#include <QMenu>
#include <QIcon>
#include <QApplication>
#include <QPainter>
#include <QVariantAnimation>
#include <QEnterEvent>
namespace shield {
namespace {
class CrossButton final:public QToolButton {
 QVariantAnimation hover_;qreal amount_=0;
 public:explicit CrossButton(QWidget* parent):QToolButton(parent){setFixedSize(28,28);setCursor(Qt::PointingHandCursor);setAccessibleName(QString::fromUtf8("Закрыть"));hover_.setDuration(qApp->property("reduceMotion").toBool()?0:130);connect(&hover_,&QVariantAnimation::valueChanged,this,[this](const QVariant& v){amount_=v.toReal();update();});}
 protected:void paintEvent(QPaintEvent*) override {QPainter p(this);p.setRenderHint(QPainter::Antialiasing);bool light=qApp->property("lightTheme").toBool();QColor bg=light?QColor(0,0,0,int(amount_*20)):QColor(255,255,255,int(amount_*22));p.setPen(Qt::NoPen);p.setBrush(bg);p.drawRoundedRect(rect().adjusted(1,1,-1,-1),7,7);p.setPen(QPen(light?QColor("#546174"):QColor("#b9c3d4"),1.6,Qt::SolidLine,Qt::RoundCap));QPointF c=rect().center()+QPointF(.5,.5);p.drawLine(c+QPointF(-3.5,-3.5),c+QPointF(3.5,3.5));p.drawLine(c+QPointF(3.5,-3.5),c+QPointF(-3.5,3.5));if(hasFocus()){p.setPen(QColor("#8299d1"));p.setBrush(Qt::NoBrush);p.drawRoundedRect(rect().adjusted(1,1,-1,-1),7,7);}}
 void enterEvent(QEnterEvent* e) override {hover_.stop();hover_.setStartValue(amount_);hover_.setEndValue(1.);hover_.start();QToolButton::enterEvent(e);}
 void leaveEvent(QEvent* e) override {hover_.stop();hover_.setStartValue(amount_);hover_.setEndValue(0.);hover_.start();QToolButton::leaveEvent(e);}
};
class DragStrip : public QWidget {
 public:
  explicit DragStrip(QWidget* parent):QWidget(parent) {}
 protected:
  void mousePressEvent(QMouseEvent* e) override {if(e->button()==Qt::LeftButton && window()->windowHandle())window()->windowHandle()->startSystemMove();}
  void mouseDoubleClickEvent(QMouseEvent* e) override {if(e->button()==Qt::LeftButton){if(window()->isMaximized())window()->showNormal();else window()->showMaximized();}}
};
class TabStrip : public QTabBar {
 public: using QTabBar::QTabBar;
 protected:
  void mousePressEvent(QMouseEvent* e) override {
    if(e->button()==Qt::MiddleButton){int i=tabAt(e->position().toPoint());if(i>=0)emit tabCloseRequested(i);return;}
    if(e->button()==Qt::LeftButton && tabAt(e->position().toPoint())<0){if(window()->windowHandle())window()->windowHandle()->startSystemMove();return;}
    QTabBar::mousePressEvent(e);
  }
  void mouseDoubleClickEvent(QMouseEvent* e) override {if(tabAt(e->position().toPoint())<0){window()->isMaximized()?window()->showNormal():window()->showMaximized();}else QTabBar::mouseDoubleClickEvent(e);}
};
}
QToolButton* makeCloseButton(QWidget* p){return new CrossButton(p);}
BrowserTabs::BrowserTabs(QWidget* host,bool privateMode):QWidget(host) {
 layout_=new QVBoxLayout(this);layout_->setContentsMargins(0,0,0,0);layout_->setSpacing(0);
 auto* title=new DragStrip(this);title->setObjectName("titleBar");title->setFixedHeight(48);
 auto* row=new QHBoxLayout(title);row->setContentsMargins(10,4,0,0);row->setSpacing(5);
 auto* mark=new QLabel;mark->setPixmap(QIcon(":/icons/app.svg").pixmap(25,25));mark->setFixedWidth(33);mark->setAlignment(Qt::AlignCenter);row->addWidget(mark);
 if(privateMode){auto* label=new QLabel(tr("Приватно"));label->setObjectName("privateBadge");row->addWidget(label);}
 bar_=new TabStrip(title);bar_->setObjectName("browserTabBar");bar_->setDocumentMode(true);bar_->setTabsClosable(false);bar_->setMovable(true);bar_->setExpanding(false);bar_->setElideMode(Qt::ElideRight);bar_->setUsesScrollButtons(true);bar_->setDrawBase(false);
 bar_->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);row->addWidget(bar_);
 auto* plus=new QToolButton;plus->setProperty("iconName","plus");plus->setIcon(QIcon(":/icons/plus.svg"));plus->setToolTip(tr("Новая вкладка · Ctrl+T"));plus->setAccessibleName(tr("Новая вкладка"));plus->setFixedSize(32,32);row->addWidget(plus);connect(plus,&QToolButton::clicked,this,&BrowserTabs::newTabRequested);
 auto* drag=new DragStrip(title);drag->setMinimumWidth(22);drag->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Preferred);row->addWidget(drag,1);
 for(const auto& type: {QString("minimize"),QString("maximize"),QString("close")}) {
   auto* b=new QToolButton; b->setObjectName(type=="close"?"windowClose":"windowControl");b->setProperty("iconName",type);b->setIcon(QIcon(":/icons/"+type+".svg"));b->setFixedSize(46,42);b->setIconSize(QSize(16,16));row->addWidget(b);
   if(type=="minimize"){b->setToolTip(tr("Свернуть"));connect(b,&QToolButton::clicked,host,&QWidget::showMinimized);}
   else if(type=="maximize"){b->setToolTip(tr("Развернуть / восстановить"));connect(b,&QToolButton::clicked,host,[host]{host->isMaximized()?host->showNormal():host->showMaximized();});}
   else{b->setToolTip(tr("Закрыть окно"));connect(b,&QToolButton::clicked,host,&QWidget::close);}
 }
 layout_->addWidget(title);
 progress_=new QProgressBar;progress_->setObjectName("loadProgress");progress_->setFixedHeight(2);progress_->setTextVisible(false);progress_->setRange(0,1);progress_->setValue(0);
 layout_->addWidget(progress_);
 stack_=new QStackedWidget;layout_->addWidget(stack_,1);
 connect(bar_,&QTabBar::tabCloseRequested,this,&BrowserTabs::tabCloseRequested);
 connect(bar_,&QTabBar::currentChanged,this,[this](int i){if(i>=0&&i<pages_.size())stack_->setCurrentWidget(pages_[i]);emit currentChanged(i);});
 connect(bar_,&QTabBar::tabMoved,this,[this](int from,int to){pages_.move(from,to);if(auto* p=widget(bar_->currentIndex()))stack_->setCurrentWidget(p);emit currentChanged(bar_->currentIndex());});
 bar_->setContextMenuPolicy(Qt::CustomContextMenu);
 connect(bar_,&QWidget::customContextMenuRequested,this,[this](const QPoint& p){int i=bar_->tabAt(p);if(i<0)return;QMenu m;auto* close=m.addAction(tr("Закрыть вкладку"));auto* others=m.addAction(tr("Закрыть остальные вкладки"));auto* result=m.exec(bar_->mapToGlobal(p));if(result==close)emit tabCloseRequested(i);else if(result==others){QWidget* keep=widget(i);for(int j=count()-1;j>=0;--j)if(widget(j)!=keep)emit tabCloseRequested(j);}});
}
int BrowserTabs::addTab(QWidget* p,const QString& text){pages_.push_back(p);stack_->addWidget(p);int i=bar_->addTab(QIcon(qApp->property("lightTheme").toBool()?":/icons/globe-dark.svg":":/icons/globe.svg"),text);auto* close=makeCloseButton(bar_);close->setToolTip(tr("Закрыть вкладку"));bar_->setTabButton(i,QTabBar::RightSide,close);connect(close,&QToolButton::clicked,this,[this,p]{emit tabCloseRequested(indexOf(p));});return i;}
void BrowserTabs::removeTab(int i){if(i<0||i>=count())return;auto* p=pages_.takeAt(i);stack_->removeWidget(p);bar_->removeTab(i);if(auto* current=currentWidget())stack_->setCurrentWidget(current);}
int BrowserTabs::count()const{return pages_.size();} int BrowserTabs::currentIndex()const{return bar_->currentIndex();}
QWidget* BrowserTabs::currentWidget()const{return widget(currentIndex());}
QWidget* BrowserTabs::widget(int i)const{return i>=0&&i<pages_.size()?pages_[i]:nullptr;}
int BrowserTabs::indexOf(QWidget* p)const{return pages_.indexOf(p);} void BrowserTabs::setCurrentIndex(int i){bar_->setCurrentIndex(i);}
void BrowserTabs::setTabText(int i,const QString& t){bar_->setTabText(i,t);} QString BrowserTabs::tabText(int i)const{return bar_->tabText(i);}
void BrowserTabs::setTabToolTip(int i,const QString& t){bar_->setTabToolTip(i,t);} QString BrowserTabs::tabToolTip(int i)const{return bar_->tabToolTip(i);}
void BrowserTabs::applyTheme(){for(int i=0;i<count();++i)bar_->setTabIcon(i,QIcon(qApp->property("lightTheme").toBool()?":/icons/globe-dark.svg":":/icons/globe.svg"));}
void BrowserTabs::setNavigation(QWidget* p){layout_->insertWidget(1,p);}
void BrowserTabs::setFindBar(QWidget* p){layout_->insertWidget(layout_->indexOf(stack_),p);}
void BrowserTabs::setLoading(bool loading){progress_->setRange(0,loading?0:1);progress_->setValue(0);}
}
