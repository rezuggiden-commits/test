#include <windows.h>
#include <algorithm>
#include "include/cef_cookie.h"
#include "shield/main_window.h"
#include "shield/core/navigation.h"
#include "shield/brand.h"
#include <QAction>
#include <QApplication>
#include <QCloseEvent>
#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenu>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPushButton>
#include <QSaveFile>
#include <QShortcut>
#include <QStatusBar>
#include <QTabWidget>
#include <QToolBar>
#include <QToolButton>
#include <QUrl>
#include <QVBoxLayout>
#include <QTimer>
#include <QPointer>
#include "shield/cef_task.h"
namespace shield {
namespace {
QToolButton* button(QToolBar* bar,const QString& name,const QString& icon) {
  auto* b=new QToolButton(bar);b->setToolTip(name);b->setAccessibleName(name);
  b->setIcon(QIcon(":/icons/"+icon+".svg"));b->setIconSize(QSize(20,20));bar->addWidget(b);return b;
}
}
MainWindow::MainWindow(CefRefPtr<CefRequestContext> context,QString profile,bool privateMode)
 :context_(context),adblock_(std::make_shared<AdBlockService>()),privateMode_(privateMode),profile_(std::move(profile)),
 storageWorker_(new QObject),storage_(std::make_shared<std::unique_ptr<core::Storage>>()) {
  setAttribute(Qt::WA_DeleteOnClose);resize(1220,820);setMinimumSize(680,420);
  setWindowTitle(QString::fromUtf8(SHIELD_NAME)+(privateMode?tr(" — приватное окно"):QString{}));
  storageWorker_->moveToThread(&storageThread_);connect(&storageThread_,&QThread::finished,storageWorker_,&QObject::deleteLater);storageThread_.start();
  auto holder=storage_;
  const auto path=privateMode?QString(":memory:"):QDir(profile_).filePath("browser.sqlite");
  QMetaObject::invokeMethod(storageWorker_,[holder,path]{try{*holder=std::make_unique<core::Storage>(path.toUtf8().toStdString());}catch(...){}},Qt::QueuedConnection);
  auto* bar=addToolBar(tr("Навигация"));bar->setMovable(false);
  back_=button(bar,tr("Назад"),"back");forward_=button(bar,tr("Вперёд"),"forward");reload_=button(bar,tr("Обновить / остановить"),"reload");
  auto* home=button(bar,tr("Домой"),"home");
  address_=new QLineEdit;address_->setPlaceholderText(tr("Адрес или поисковый запрос"));address_->setClearButtonEnabled(true);bar->addWidget(address_);
  shield_=button(bar,tr("Защита: фильтры не загружены"),"shield");
  auto* bookmark=button(bar,tr("Добавить закладку"),"bookmark");auto* downloads=button(bar,tr("Загрузки"),"download");
  auto* menuButton=button(bar,tr("Меню"),"menu");auto* menu=new QMenu(this);menuButton->setMenu(menu);menuButton->setPopupMode(QToolButton::InstantPopup);
  menu->addAction(tr("Новая вкладка"),this,[this]{newTab();});
  menu->addAction(tr("Приватное окно"),this,[this]{key('N',int(Qt::ControlModifier|Qt::ShiftModifier));});
  menu->addAction(tr("История"),this,&MainWindow::showHistory);menu->addAction(tr("Закладки"),this,&MainWindow::showBookmarks);
  menu->addAction(tr("Обновить EasyList + EasyPrivacy"),this,&MainWindow::updateFilters);
  menu->addAction(tr("Загрузить собственный список фильтров"),this,[this]{
    const auto path=QInputDialog::getText(this,tr("Локальные правила"),tr("Путь к UTF-8 файлу ABP (не более 16 МиБ):"));
    if(path.isEmpty())return;QFile file(path);
    if(!file.open(QIODevice::ReadOnly)||file.size()>16*1024*1024){QMessageBox::warning(this,tr("Фильтры"),tr("Не удалось прочитать допустимый файл"));return;}
    compileRules(file.readAll());
  });
  menu->addAction(tr("Приватность и очистка"),this,&MainWindow::privacy);
  menu->addAction(tr("О браузере"),this,[this]{QMessageBox::about(this,QString::fromUtf8(SHIELD_NAME),tr("Исследовательская сборка %1\nCEF %2\nQt %3\nНет автоматических обновлений. Не использовать как основной браузер до Windows-проверок.\nРазрешения камеры, микрофона, геолокации и уведомлений отклоняются.\nКосметическая фильтрация не реализована.").arg(SHIELD_VERSION,SHIELD_CEF_VERSION,qVersion()));});
  tabs_=new QTabWidget;tabs_->setDocumentMode(true);tabs_->setTabsClosable(true);tabs_->setMovable(true);setCentralWidget(tabs_);
  auto* plus=new QPushButton("+");plus->setAccessibleName(tr("Новая вкладка"));tabs_->setCornerWidget(plus);connect(plus,&QPushButton::clicked,this,[this]{newTab();});
  status_=new QLabel;statusBar()->addWidget(status_,1);
  downloadsDialog_=new QDialog(this);downloadsDialog_->setWindowTitle(tr("Загрузки"));downloadsDialog_->resize(740,380);
  auto* dl=new QVBoxLayout(downloadsDialog_);downloadsList_=new QListWidget;dl->addWidget(downloadsList_);
  auto* cancel=new QPushButton(tr("Отменить выбранную загрузку"));dl->addWidget(cancel);
  connect(cancel,&QPushButton::clicked,this,[this]{auto* item=downloadsList_->currentItem();if(!item)return;
    auto* page=reinterpret_cast<BrowserPage*>(item->data(Qt::UserRole+1).value<quintptr>());
    if(pages_.contains(page))page->cancelDownload(item->data(Qt::UserRole).toUInt());});
  auto* folder=new QPushButton(tr("Показать папку выбранного завершённого файла"));dl->addWidget(folder);
  connect(folder,&QPushButton::clicked,this,[this]{auto* item=downloadsList_->currentItem();if(!item||!item->data(Qt::UserRole+3).toBool())return;
    const auto file=item->data(Qt::UserRole+2).toString();QDesktopServices::openUrl(QUrl::fromLocalFile(QFileInfo(file).absolutePath()));});
  connect(address_,&QLineEdit::returnPressed,this,&MainWindow::navigate);
  connect(back_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoBack();});});
  connect(forward_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoForward();});});
  connect(reload_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){if(b->IsLoading())b->StopLoad();else b->Reload();});});
  connect(home,&QToolButton::clicked,this,[this]{if(current())current()->open("about:blank");});
  connect(bookmark,&QToolButton::clicked,this,&MainWindow::addBookmark);connect(downloads,&QToolButton::clicked,this,&MainWindow::showDownloads);
  connect(shield_,&QToolButton::clicked,this,[this]{if(!current())return;auto host=QUrl(current()->url()).host().toLower().toStdString();
    if(host.empty())return;bool enable=!adblock_->enabled(host);adblock_->setEnabled(host,enable);
    shield_->setToolTip(enable?tr("Защита включена для сайта"):tr("Защита отключена для сайта"));withCurrent([](auto b){b->Reload();});});
  connect(tabs_,&QTabWidget::tabCloseRequested,this,&MainWindow::closeTab);
  connect(tabs_,&QTabWidget::currentChanged,this,[this](int){if(current())address_->setText(current()->url());saveSession();});
  for(const auto& sequence: {"Ctrl+T","Ctrl+W","Ctrl+Shift+T","Ctrl+L","Ctrl+R","Alt+Left","Alt+Right","Ctrl+D","Ctrl+H","Ctrl+J","Ctrl+F","Ctrl+Shift+N","Ctrl++","Ctrl+-","Ctrl+0"}) {
    auto* shortcut=new QShortcut(QKeySequence(sequence),this);
    connect(shortcut,&QShortcut::activated,this,[this,s=QString(sequence)]{
      if(s=="Ctrl++")key(VK_OEM_PLUS,int(Qt::ControlModifier));else if(s=="Ctrl+-")key(VK_OEM_MINUS,int(Qt::ControlModifier));
      else {auto combo=QKeySequence(s)[0];auto k=int(combo.key());if(k==Qt::Key_Left)k=VK_LEFT;if(k==Qt::Key_Right)k=VK_RIGHT;key(k,int(combo.keyboardModifiers()));}
    });
  }
  QFile cachedFilters(QDir(profile_).filePath("network-filters.txt"));
  if(cachedFilters.open(QIODevice::ReadOnly)&&cachedFilters.size()<=16*1024*1024)compileRules(cachedFilters.readAll());
  if(!privateMode_){QPointer<MainWindow> guard=this;store([guard](auto& db){auto snapshot=db.loadSession();
    if(snapshot.tabs.empty())return;
    QMetaObject::invokeMethod(qApp,[guard,snapshot]{if(!guard||guard->closing_)return;
      if(QMessageBox::question(guard,tr("Предыдущая сессия"),snapshot.clean_shutdown?tr("Восстановить предыдущие вкладки?"):tr("Предыдущее завершение было аварийным. Восстановить вкладки?"))!=QMessageBox::Yes)return;
      auto* initial=guard->current();for(const auto& tab:snapshot.tabs)guard->newTab(QString::fromStdString(tab.url));
      if(initial){int index=guard->tabs_->indexOf(initial);if(index>=0)guard->closeTab(index);}
      if(snapshot.active_index<std::size_t(guard->tabs_->count()))guard->tabs_->setCurrentIndex(int(snapshot.active_index));
    },Qt::QueuedConnection);
  });}
  newTab(qEnvironmentVariable("SHIELD_START_URL","https://example.org"));
  status_->setText(privateMode?tr("Приватная сессия: IP не скрывается, скачанные файлы остаются. Фильтры не загружены."):tr("Фильтры не загружены. Выберите обновление EasyList + EasyPrivacy в меню."));
}
MainWindow::~MainWindow(){
  for(auto* worker:filterWorkers_)worker->wait();
  auto holder=storage_;
  QMetaObject::invokeMethod(storageWorker_,[holder]{holder->reset();},Qt::BlockingQueuedConnection);
  storageThread_.quit();storageThread_.wait();
}
void MainWindow::store(std::function<void(core::Storage&)> f) {
  auto holder=storage_;QPointer<MainWindow> guard=this;
  QMetaObject::invokeMethod(storageWorker_,[holder,f=std::move(f),guard]{try{if(!*holder)throw std::runtime_error("storage unavailable");f(**holder);}catch(...){QMetaObject::invokeMethod(qApp,[guard]{if(guard)guard->status_->setText(tr("Ошибка хранилища: операция не выполнена"));},Qt::QueuedConnection);}},Qt::QueuedConnection);
}
BrowserPage* MainWindow::current()const{return qobject_cast<BrowserPage*>(tabs_->currentWidget());}
void MainWindow::withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>& f){if(current())current()->command(f);}
void MainWindow::newTab(const QString& url) {
  if(closing_)return;auto* page=new BrowserPage(context_,adblock_);pages_.insert(page);page->open(url);
  int index=tabs_->addTab(page,tr("Новая вкладка"));tabs_->setCurrentIndex(index);
  connect(page,&BrowserPage::titleChanged,this,[this,page](const QString& text){int i=tabs_->indexOf(page);if(i>=0){tabs_->setTabText(i,text.left(38));tabs_->setTabToolTip(i,text);}});
  connect(page,&BrowserPage::addressChanged,this,[this,page](const QString& url){if(page==current())address_->setText(url);saveSession();});
  connect(page,&BrowserPage::loadingChanged,this,[this,page](bool loading,bool back,bool forward){if(page!=current())return;back_->setEnabled(back);forward_->setEnabled(forward);status_->setText(loading?tr("Загрузка…"):tr("Готово"));});
  connect(page,&BrowserPage::loadFailed,this,[this,page](const QString& error){if(page==current())status_->setText(tr("Ошибка загрузки: ")+error);});
  connect(page,&BrowserPage::completed,this,[this](const QString& url,const QString& pageTitle){
    const auto u=url.toUtf8().toStdString();const auto title=pageTitle.toUtf8().toStdString();const auto now=QDateTime::currentMSecsSinceEpoch();
    if(!privateMode_)store([=](auto& db){db.recordVisit(u,title,now);});
    const auto testProof=qEnvironmentVariable("SHIELD_TEST_PROOF");
    if(!testProof.isEmpty() && QUrl(url).host()=="127.0.0.1") {
      QSaveFile proof(testProof);
      if(proof.open(QIODevice::WriteOnly)) {
        proof.write(QJsonDocument(QJsonObject{{"url",url},{"title",pageTitle},{"cefLoadCompleted",true}}).toJson());
        proof.commit();
      }
    }
  });
  connect(page,&BrowserPage::popupRequested,this,&MainWindow::newTab);
  connect(page,&BrowserPage::shortcut,this,&MainWindow::key);
  connect(page,&BrowserPage::blockedChanged,this,[this,page](quint64 count){if(page==current())shield_->setToolTip(adblock_->ready()?tr("Заблокировано запросов: %1").arg(count):tr("Защита не активна: нет списков"));});
  connect(page,&BrowserPage::downloadChanged,this,[this,page](unsigned id,const QString& name,qint64 received,qint64 total,bool done,bool cancelled){
    QListWidgetItem* item=nullptr;for(int i=0;i<downloadsList_->count();++i){auto* row=downloadsList_->item(i);if(row->data(Qt::UserRole).toUInt()==id&&row->data(Qt::UserRole+1).value<quintptr>()==reinterpret_cast<quintptr>(page)){item=row;break;}}
    if(!item){item=new QListWidgetItem(downloadsList_);item->setData(Qt::UserRole,id);item->setData(Qt::UserRole+1,QVariant::fromValue(reinterpret_cast<quintptr>(page)));}
    item->setText(QString("%1 — %2 / %3 %4").arg(name).arg(received).arg(total).arg(done?tr("готово"):cancelled?tr("отменено"):tr("байт")));
    item->setData(Qt::UserRole+2,name);item->setData(Qt::UserRole+3,done);
  });
  connect(page,&BrowserPage::closed,this,[this,page]{int i=tabs_->indexOf(page);if(i>=0)tabs_->removeTab(i);pages_.erase(page);page->deleteLater();if(closing_&&pages_.empty())QTimer::singleShot(0,this,&QWidget::close);});
  saveSession();
}
void MainWindow::navigate(){auto text=address_->text();
  auto result=core::classifyNavigation(text.toUtf8().toStdString());
  if(!result.allowed()||(result.kind!=core::NavigationKind::Web&&result.kind!=core::NavigationKind::Search&&result.url!="about:blank")){
    status_->setText(tr("Адрес отклонён: ")+QString::fromStdString(result.reason));return;}
  if(current())current()->open(QString::fromStdString(result.url));
}
void MainWindow::closeTab(int index){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(index));if(!p)return;closedTabs_.push_back(p->url());tabs_->removeTab(index);p->hide();p->shutdown();if(tabs_->count()==0&&!closing_)newTab();saveSession();}
void MainWindow::saveSession(bool clean){if(privateMode_||closing_)return;core::SessionSnapshot s;s.clean_shutdown=clean;s.active_index=std::size_t(std::max(tabs_->currentIndex(),0));for(int i=0;i<tabs_->count();++i){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));s.tabs.push_back({p->url().toStdString(),tabs_->tabText(i).toStdString(),false});}store([s](auto& db){db.saveSession(s);});}
void MainWindow::closeEvent(QCloseEvent* e){if(pages_.empty()){if(!privateMode_)store([](auto& db){db.markSessionClean(true);});e->accept();return;}e->ignore();if(closing_)return;
  saveSession(false);closing_=true;setEnabled(false);auto pages=pages_;for(auto* p:pages)p->shutdown();}
void MainWindow::key(int key,int mods){const bool shift=mods&int(Qt::ShiftModifier);const bool alt=mods&int(Qt::AltModifier);
  if(alt){if(key==VK_LEFT)withCurrent([](auto b){b->GoBack();});if(key==VK_RIGHT)withCurrent([](auto b){b->GoForward();});return;}
  switch(key){
    case 'T':if(shift&&!closedTabs_.empty())newTab(closedTabs_.takeLast());else newTab();break;
    case 'W':closeTab(tabs_->currentIndex());break;case 'L':address_->setFocus();address_->selectAll();break;
    case 'R':withCurrent([](auto b){b->Reload();});break;case 'D':addBookmark();break;case 'H':showHistory();break;case 'J':showDownloads();break;
    case 'N':if(shift){CefRequestContextSettings settings;auto context=CefRequestContext::CreateContext(settings,nullptr);auto* w=new MainWindow(context,profile_,true);w->show();}break;
    case 'F':{bool ok=false;auto text=QInputDialog::getText(this,tr("Поиск по странице"),tr("Текст:"),QLineEdit::Normal,{},&ok);if(ok)withCurrent([s=text.toStdWString()](auto b){b->GetHost()->Find(s,true,false,false);});break;}
    case VK_OEM_PLUS:withCurrent([](auto b){b->GetHost()->SetZoomLevel(std::min(5.0,b->GetHost()->GetZoomLevel()+0.5));});break;
    case VK_OEM_MINUS:withCurrent([](auto b){b->GetHost()->SetZoomLevel(std::max(-5.0,b->GetHost()->GetZoomLevel()-0.5));});break;
    case '0':withCurrent([](auto b){b->GetHost()->SetZoomLevel(0);});break;
  }
}
void MainWindow::addBookmark(){if(!current())return;auto u=current()->url().toStdString();auto t=tabs_->tabText(tabs_->currentIndex()).toStdString();auto now=QDateTime::currentMSecsSinceEpoch();store([=](auto& db){db.addBookmark(u,t,now);});}
void MainWindow::showDownloads(){downloadsDialog_->show();downloadsDialog_->raise();}
void MainWindow::showHistory(){QPointer<MainWindow> guard=this;store([guard](auto& db){auto rows=db.history(500);QMetaObject::invokeMethod(qApp,[guard,rows]{if(!guard)return;auto* dialog=new QDialog(guard);dialog->setAttribute(Qt::WA_DeleteOnClose);dialog->setWindowTitle(tr("История (последние 500 посещений)"));dialog->resize(800,500);auto* layout=new QVBoxLayout(dialog);auto* list=new QListWidget;layout->addWidget(list);for(const auto& row:rows){auto* item=new QListWidgetItem(QString::fromStdString(row.title+" — "+row.url),list);item->setData(Qt::UserRole,QString::fromStdString(row.url));}connect(list,&QListWidget::itemDoubleClicked,guard,[guard](auto* item){if(guard)guard->newTab(item->data(Qt::UserRole).toString());});auto* clear=new QPushButton(tr("Очистить всю историю"));layout->addWidget(clear);connect(clear,&QPushButton::clicked,guard,[guard,list]{if(guard){guard->store([](auto& db){db.clearHistory();});list->clear();}});dialog->show();},Qt::QueuedConnection);});}
void MainWindow::showBookmarks(){QPointer<MainWindow> guard=this;store([guard](auto& db){auto rows=db.bookmarks();QMetaObject::invokeMethod(qApp,[guard,rows]{if(!guard)return;auto* dialog=new QDialog(guard);dialog->setAttribute(Qt::WA_DeleteOnClose);dialog->setWindowTitle(tr("Закладки"));dialog->resize(800,500);auto* layout=new QVBoxLayout(dialog);auto* list=new QListWidget;layout->addWidget(list);for(const auto& row:rows){auto* item=new QListWidgetItem(QString::fromStdString(row.title+" — "+row.url),list);item->setData(Qt::UserRole,QString::fromStdString(row.url));item->setData(Qt::UserRole+1,qlonglong(row.id));}connect(list,&QListWidget::itemDoubleClicked,guard,[guard](auto* item){if(guard)guard->newTab(item->data(Qt::UserRole).toString());});auto* remove=new QPushButton(tr("Удалить выбранную"));layout->addWidget(remove);connect(remove,&QPushButton::clicked,guard,[guard,list]{auto* item=list->currentItem();if(!guard||!item)return;auto id=item->data(Qt::UserRole+1).toLongLong();guard->store([id](auto& db){db.removeBookmark(id);});delete item;});dialog->show();},Qt::QueuedConnection);});}
void MainWindow::privacy(){
  auto answer=QMessageBox::question(this,tr("Приватность"),tr("Удалить cookies и HTTP-кэш текущего контекста?\nЭто не полная очистка localStorage, service workers и других данных сайтов. История очищается отдельно.\nКамера, микрофон, геолокация и уведомления всегда запрещены в этой сборке."));
  if(answer!=QMessageBox::Yes)return;auto ctx=context_;onCefUi([ctx]{ctx->GetCookieManager(nullptr)->DeleteCookies(CefString(),CefString(),nullptr);ctx->ClearHttpCache(nullptr);});
  status_->setText(tr("Очистка cookies и HTTP-кэша запрошена (асинхронно)"));
}
} // namespace shield
namespace shield {
void MainWindow::updateFilters(){
  if(property("filterUpdateBusy").toBool())return;setProperty("filterUpdateBusy",true);
  status_->setText(tr("Загрузка EasyList + EasyPrivacy по HTTPS…"));
  auto* manager=new QNetworkAccessManager(this);
  struct State{QByteArray combined;int index=0;bool failed=false;};auto state=std::make_shared<State>();
  auto next=std::make_shared<std::function<void()>>();std::weak_ptr<std::function<void()>> weakNext=next;
  *next=[this,manager,state,weakNext]{
    const QStringList urls={"https://easylist.to/easylist/easylist.txt","https://easylist.to/easylist/easyprivacy.txt"};
    if(state->index==urls.size()) {
      setProperty("filterUpdateBusy",false);manager->deleteLater();
      compileRules(state->combined,true);return;
    }
    const QUrl url(urls[state->index]);QNetworkRequest request(url);
    request.setAttribute(QNetworkRequest::RedirectPolicyAttribute,QNetworkRequest::ManualRedirectPolicy);
    request.setTransferTimeout(30000);auto* reply=manager->get(request);
    auto buffer=std::make_shared<QByteArray>();auto keepNext=weakNext.lock();
    connect(reply,&QNetworkReply::readyRead,this,[reply,buffer,state]{
      if(buffer->size()+reply->bytesAvailable()+state->combined.size()>16*1024*1024){state->failed=true;reply->abort();return;}*buffer+=reply->readAll();
    });
    connect(reply,&QNetworkReply::finished,this,[this,reply,buffer,state,manager,url,keepNext]{
      *buffer+=reply->readAll();
      const bool valid=!state->failed&&reply->error()==QNetworkReply::NoError&&reply->url()==url&&
       reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt()==200&&buffer->startsWith("[Adblock Plus")&&
       !buffer->contains('\0')&&state->combined.size()+buffer->size()<=16*1024*1024;
      reply->deleteLater();
      if(!valid){status_->setText(tr("Обновление отклонено; предыдущий рабочий список сохранён"));setProperty("filterUpdateBusy",false);manager->deleteLater();return;}
      state->combined+=*buffer;state->combined+='\n';++state->index;if(keepNext)(*keepNext)();
    });
  };
  (*next)();
}
void MainWindow::compileRules(const QByteArray& data,bool save){
  if(compilingRules_){status_->setText(tr("Компиляция правил уже выполняется. Повторите загрузку после её завершения."));return;}
  compilingRules_=true;
  auto service=adblock_;QPointer<MainWindow> guard=this;
  auto path=QDir(profile_).filePath("network-filters.txt");bool persist=save&&!privateMode_;
  auto* thread=QThread::create([service,data,guard,path,persist]{
    bool ok=service->replace(data.toStdString());bool cached=!persist;
    if(ok&&persist){QSaveFile file(path);cached=file.open(QIODevice::WriteOnly)&&file.write(data)==data.size()&&file.commit();}
    QMetaObject::invokeMethod(qApp,[guard,ok,cached]{if(guard){guard->status_->setText(ok?(cached?tr("Сетевые правила активированы; косметические правила не применяются"):tr("Правила активны, но не сохранены на диск")):tr("Ошибка компиляции правил; прежняя защита сохранена"));}},Qt::QueuedConnection);
  });
  filterWorkers_.insert(thread);connect(thread,&QThread::finished,this,[this,thread]{filterWorkers_.erase(thread);compilingRules_=false;thread->deleteLater();});thread->start();
}
}
