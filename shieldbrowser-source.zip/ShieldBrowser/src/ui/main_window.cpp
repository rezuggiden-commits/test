#include <windows.h>
#include <algorithm>
#include <QApplication>
#include <QCloseEvent>
#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMenu>
#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPushButton>
#include <QSaveFile>
#include <QShortcut>
#include <QStatusBar>
#include <QToolBar>
#include <QToolButton>
#include <QUrl>
#include <QVBoxLayout>
#include <QTimer>
#include <QPointer>
#include <QSettings>
#include <QCompleter>
#include <QStringListModel>
#include <QCheckBox>
#include <QScreen>
#include <QWindow>
#include <QKeyEvent>
#include <QStyle>
#include <QProgressBar>
#include <QJsonArray>
#include <QUrlQuery>
#include <QMouseEvent>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include "include/cef_cookie.h"
#include "include/cef_request_context_handler.h"
#include "shield/main_window.h"
#include "shield/browser_tabs.h"
#include "include/cef_values.h"
#include "shield/core/navigation.h"
#include "shield/brand.h"
#include "shield/cef_task.h"
#include "shield/internal_pages.h"
namespace shield {
namespace {
const QString homeUrl="shield://newtab/";
bool home(const QString& url){return url.startsWith("shield://newtab")||url=="about:blank";}
QIcon icon(const QString& name){return QIcon(":/icons/"+name+(qApp->property("lightTheme").toBool()?"-dark":"")+".svg");}
QToolButton* tool(QToolBar* bar,const QString& label,const QString& name){
 auto* b=new QToolButton;b->setProperty("iconName",name);b->setIcon(icon(name));b->setIconSize(QSize(19,19));b->setToolTip(label);b->setAccessibleName(label);b->setFixedHeight(36);bar->addWidget(b);return b;
}
class PanelDialog final:public QDialog {
 public:explicit PanelDialog(QWidget* p):QDialog(p,Qt::Dialog|Qt::FramelessWindowHint){setWindowModality(Qt::WindowModal);}
 protected:void showEvent(QShowEvent* e) override {QDialog::showEvent(e);if(!qApp->property("reduceMotion").toBool()){setWindowOpacity(0);auto* fade=new QPropertyAnimation(this,"windowOpacity",this);fade->setDuration(140);fade->setStartValue(0.);fade->setEndValue(1.);fade->start(QAbstractAnimation::DeleteWhenStopped);}}
 void mousePressEvent(QMouseEvent* e) override {if(e->button()==Qt::LeftButton&&e->position().y()<72&&windowHandle())windowHandle()->startSystemMove();else QDialog::mousePressEvent(e);}
};
QDialog* dialog(QWidget* parent,const QString& title,const QString& subtitle,QVBoxLayout*& layout){
 auto* d=new PanelDialog(parent);d->setAttribute(Qt::WA_DeleteOnClose);d->setWindowTitle(title+" — Aster");d->resize(680,520);
 layout=new QVBoxLayout(d);layout->setContentsMargins(28,22,28,24);layout->setSpacing(16);
 auto* row=new QHBoxLayout;auto* h=new QLabel(title);h->setObjectName("dialogTitle");h->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);row->addWidget(h,1);auto* close=makeCloseButton(d);close->setToolTip(QString::fromUtf8("Закрыть"));row->addWidget(close);QObject::connect(close,&QToolButton::clicked,d,&QDialog::close);layout->addLayout(row);
 if(!subtitle.isEmpty()){auto* p=new QLabel(subtitle);p->setObjectName("dialogSubtitle");p->setWordWrap(true);p->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Fixed);layout->addWidget(p);}
 return d;
}
void darkTitle(QWidget* w){
 auto lib=LoadLibraryW(L"dwmapi.dll");if(!lib)return;
 using SetAttribute=HRESULT(WINAPI*)(HWND,DWORD,LPCVOID,DWORD);
 auto fn=reinterpret_cast<SetAttribute>(GetProcAddress(lib,"DwmSetWindowAttribute"));
 if(fn){BOOL dark=!qApp->property("lightTheme").toBool();fn(reinterpret_cast<HWND>(w->winId()),20,&dark,sizeof(dark));}
 FreeLibrary(lib);
}
QString displayAddress(const QString& u){if(QUrl(u).scheme()=="shield"&&QUrl(u).host()=="error")return QUrlQuery(QUrl(u)).queryItemValue("url");return home(u)?QString{}:u;}
}
MainWindow::MainWindow(CefRefPtr<CefRequestContext> context,QString profile,bool privateMode)
 :context_(context),adblock_(std::make_shared<AdBlockService>()),privateMode_(privateMode),profile_(std::move(profile)),
 storageWorker_(new QObject),storage_(std::make_shared<std::unique_ptr<core::Storage>>()) {
 setWindowFlags(Qt::Window|Qt::FramelessWindowHint|Qt::WindowMinMaxButtonsHint);
 setAttribute(Qt::WA_DeleteOnClose);resize(1280,850);setMinimumSize(760,480);
 if(!(qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST"))&&screen()){auto a=screen()->availableGeometry();resize(std::min(1280,a.width()),std::min(850,a.height()));move(a.topLeft());}setWindowTitle("Aster");
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);
 const QString theme=prefs.value("theme","dark").toString();
 const auto proxy=prefs.value("proxy").toString();if(!proxy.isEmpty()){auto ctx=context_;onCefUi([ctx,proxy]{auto d=CefDictionaryValue::Create();d->SetString("mode","fixed_servers");d->SetString("server",proxy.toStdString());auto v=CefValue::Create();v->SetDictionary(d);CefString error;ctx->SetPreference("proxy",v,error);});}
 storageWorker_->moveToThread(&storageThread_);connect(&storageThread_,&QThread::finished,storageWorker_,&QObject::deleteLater);storageThread_.start();
 auto holder=storage_;const auto path=privateMode_?QString(":memory:"):QDir(profile_).filePath("browser.sqlite");
 QMetaObject::invokeMethod(storageWorker_,[holder,path]{try{*holder=std::make_unique<core::Storage>(path.toUtf8().toStdString());}catch(...){}},Qt::QueuedConnection);
 tabs_=new BrowserTabs(this,privateMode_);setCentralWidget(tabs_);
 auto* bar=new QToolBar;bar->setObjectName("navigation");bar->setMovable(false);tabs_->setNavigation(bar);
 back_=tool(bar,tr("Назад · Alt+←"),"back");forward_=tool(bar,tr("Вперёд · Alt+→"),"forward");reload_=tool(bar,tr("Обновить · Ctrl+R"),"reload");auto* homeButton=tool(bar,tr("Стартовая страница"),"home");
 address_=new QLineEdit;address_->setObjectName("address");address_->setAccessibleName(tr("Адрес или поисковый запрос"));address_->setPlaceholderText(tr("Поиск или адрес сайта"));address_->setMinimumWidth(200);address_->installEventFilter(this);bar->addWidget(address_);
 suggestions_=new QStringListModel(this);auto* completer=new QCompleter(suggestions_,this);completer->setCaseSensitivity(Qt::CaseInsensitive);completer->setFilterMode(Qt::MatchContains);completer->setMaxVisibleItems(7);address_->setCompleter(completer);
 shield_=tool(bar,tr("Защита сайта"),"shield");shield_->setObjectName("shieldButton");shield_->setToolButtonStyle(Qt::ToolButtonIconOnly);
 bookmark_=tool(bar,tr("Сохранить в закладки · Ctrl+D"),"bookmark");auto* downloads=tool(bar,tr("Загрузки · Ctrl+J"),"download");
 menuButton_=tool(bar,tr("Меню браузера"),"menu");menu_=new QMenu(this);menuButton_->setMenu(menu_);menuButton_->setPopupMode(QToolButton::InstantPopup);
 auto action=[this](const QString& label,const std::function<void()>& f){return menu_->addAction(label,this,f);};
 action(tr("Новая вкладка"),[this]{newTab();});action(tr("Приватное окно"),[this]{key('N',int(Qt::ControlModifier|Qt::ShiftModifier));});action(tr("Вернуть закрытую вкладку"),[this]{key('T',int(Qt::ControlModifier|Qt::ShiftModifier));});menu_->addSeparator();
 action(tr("История"),[this]{showHistory();});action(tr("Закладки"),[this]{showBookmarks();});action(tr("Загрузки"),[this]{showDownloads();});menu_->addSeparator();
 action(tr("Найти на странице"),[this]{showFind();});auto* zoom=menu_->addMenu(tr("Масштаб"));zoom->addAction(tr("Увеличить"),this,[this]{key(VK_OEM_PLUS,int(Qt::ControlModifier));});zoom->addAction(tr("Уменьшить"),this,[this]{key(VK_OEM_MINUS,int(Qt::ControlModifier));});zoom->addAction(tr("Сбросить до 100%"),this,[this]{key('0',int(Qt::ControlModifier));});
 action(tr("На весь экран"),[this]{key(VK_F11,0);});menu_->addSeparator();
 action(tr("Настройки"),[this]{showSettings();}); menu_->addSeparator();action(tr("О браузере"),[this]{QMessageBox::about(this,tr("О Aster"),tr("Aster %1\nQt %2 · CEF 152\n\nТестовая версия без автообновлений.\nСетевая блокировка: Brave adblock, EasyList и EasyPrivacy.\nКосметическая фильтрация не реализована. Разрешения камеры, микрофона и местоположения пока отклоняются.").arg(SHIELD_VERSION,qVersion()));});action(tr("Закрыть окно"),[this]{close();});
 status_=new QLabel(tr("Новая вкладка"));statusBar()->setSizeGripEnabled(false);statusBar()->addWidget(status_,1);statusBar()->hide();
 findBar_=new QWidget;findBar_->setObjectName("findBar");auto* findLayout=new QHBoxLayout(findBar_);findLayout->setContentsMargins(16,6,16,6);findLayout->addStretch();find_=new QLineEdit;find_->setPlaceholderText(tr("Найти на странице"));find_->setMinimumWidth(260);find_->installEventFilter(this);findLayout->addWidget(find_);findCount_=new QLabel;findCount_->setMinimumWidth(90);findLayout->addWidget(findCount_);
 auto findButton=[&](const QString& name,const QString& label){auto* b=new QToolButton;b->setProperty("iconName",name);b->setIcon(icon(name));b->setToolTip(label);findLayout->addWidget(b);return b;};
 auto* previous=findButton("arrow-up",tr("Предыдущее совпадение"));auto* next=findButton("arrow-down",tr("Следующее совпадение"));auto* dismiss=findButton("close",tr("Закрыть поиск · Esc"));
 tabs_->setFindBar(findBar_);findBar_->hide();connect(find_,&QLineEdit::textEdited,this,[this]{findNext();});connect(find_,&QLineEdit::returnPressed,this,[this]{findNext();});connect(next,&QToolButton::clicked,this,[this]{findNext();});connect(previous,&QToolButton::clicked,this,[this]{findNext(false);});connect(dismiss,&QToolButton::clicked,this,[this]{findBar_->hide();withCurrent([](auto b){b->GetHost()->StopFinding(true);});if(current())current()->setFocus();});
 QVBoxLayout* dl;downloadsDialog_=dialog(this,tr("Загрузки"),tr("Файлы, которые вы сохраняете из интернета."),dl);downloadsDialog_->setAttribute(Qt::WA_DeleteOnClose,false);
 downloadsEmpty_=new QLabel(tr("Здесь пока пусто\nСкачанные файлы появятся в этом списке."));downloadsEmpty_->setObjectName("emptyState");downloadsEmpty_->setAlignment(Qt::AlignCenter);dl->addWidget(downloadsEmpty_,1);
 downloadsList_=new QListWidget;dl->addWidget(downloadsList_,1);downloadsList_->hide();auto* downloadDone=new QPushButton(tr("Готово"));downloadDone->setObjectName("primaryButton");dl->addWidget(downloadDone,0,Qt::AlignRight);connect(downloadDone,&QPushButton::clicked,downloadsDialog_,&QDialog::hide);
 connect(address_,&QLineEdit::textEdited,this,[this]{editingAddress_=true;});
 connect(address_,&QLineEdit::returnPressed,this,&MainWindow::navigate);connect(back_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoBack();});});connect(forward_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->GoForward();});});connect(reload_,&QToolButton::clicked,this,[this]{withCurrent([](auto b){b->IsLoading()?b->StopLoad():b->Reload();});});connect(homeButton,&QToolButton::clicked,this,[this]{if(current())current()->open(homeUrl);});connect(bookmark_,&QToolButton::clicked,this,&MainWindow::addBookmark);connect(downloads,&QToolButton::clicked,this,&MainWindow::showDownloads);connect(shield_,&QToolButton::clicked,this,&MainWindow::showProtection);
 connect(tabs_,&BrowserTabs::tabCloseRequested,this,&MainWindow::closeTab);connect(tabs_,&BrowserTabs::newTabRequested,this,[this]{newTab();});connect(tabs_,&BrowserTabs::currentChanged,this,[this](int){editingAddress_=false;refreshChrome();saveSession();});
 QStringList sequences={"Ctrl+T","Ctrl+W","Ctrl+Shift+T","Ctrl+L","Ctrl+R","Alt+Left","Alt+Right","Ctrl+D","Ctrl+H","Ctrl+J","Ctrl+F","Ctrl+Shift+N","Ctrl++","Ctrl+-","Ctrl+0","Ctrl+Tab","Ctrl+Shift+Tab","F11"};
 for(int i=1;i<=9;++i)sequences<<QString("Ctrl+%1").arg(i);
 for(const auto& s:sequences){auto* shortcut=new QShortcut(QKeySequence(s),this);connect(shortcut,&QShortcut::activated,this,[this,s]{if(s=="Ctrl++")key(VK_OEM_PLUS,int(Qt::ControlModifier));else if(s=="Ctrl+-")key(VK_OEM_MINUS,int(Qt::ControlModifier));else{auto c=QKeySequence(s)[0];int k=int(c.key());if(k==Qt::Key_Left)k=VK_LEFT;if(k==Qt::Key_Right)k=VK_RIGHT;if(k==Qt::Key_Tab)k=VK_TAB;if(k==Qt::Key_F11)k=VK_F11;key(k,int(c.keyboardModifiers()));}});}
 applyTheme(theme);
 QFile rules(QDir(profile_).filePath("network-filters.txt"));const bool cached=rules.open(QIODevice::ReadOnly)&&rules.size()<=16*1024*1024;if(cached)compileRules(rules.readAll());
 else if(!privateMode_ && (qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST")))QTimer::singleShot(1500,this,&MainWindow::updateFilters);
 if(!privateMode_ && prefs.value("restoreSession",true).toBool() && (qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST"))){
  QPointer<MainWindow> guard=this;store([guard](auto& db){auto s=db.loadSession();if(s.tabs.empty())return;QMetaObject::invokeMethod(qApp,[guard,s]{if(!guard||guard->closing_)return;auto* initial=guard->current();int opened=0;for(const auto& tab:s.tabs){auto u=QString::fromStdString(tab.url);if(home(u))continue;auto r=core::classifyNavigation(tab.url);if(r.kind==core::NavigationKind::Web){guard->newTab(u);++opened;}}if(opened&&initial){int i=guard->tabs_->indexOf(initial);if(i>=0)guard->closeTab(i);}if(opened)guard->tabs_->setCurrentIndex(std::min(int(s.active_index),guard->tabs_->count()-1));},Qt::QueuedConnection);});
 }
 newTab(qEnvironmentVariable("SHIELD_START_URL",homeUrl));refreshSuggestions();if(!qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST"))runExternalChecks();
}
MainWindow::~MainWindow(){for(auto* w:filterWorkers_)w->wait();auto holder=storage_;QMetaObject::invokeMethod(storageWorker_,[holder]{holder->reset();},Qt::BlockingQueuedConnection);storageThread_.quit();storageThread_.wait();}
void MainWindow::store(std::function<void(core::Storage&)> f){auto h=storage_;QPointer<MainWindow> g=this;QMetaObject::invokeMethod(storageWorker_,[h,f=std::move(f),g]{try{if(!*h)throw std::runtime_error("storage unavailable");f(**h);}catch(...){QMetaObject::invokeMethod(qApp,[g]{if(g)g->status_->setText(tr("Не удалось сохранить данные. Проверьте доступ к профилю."));},Qt::QueuedConnection);}},Qt::QueuedConnection);}
BrowserPage* MainWindow::current()const{return qobject_cast<BrowserPage*>(tabs_->currentWidget());}
void MainWindow::withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>& f){if(current())current()->command(f);}
void MainWindow::refreshChrome(){
 auto* p=current();if(!p)return;
 if(!editingAddress_||!address_->hasFocus())address_->setText(displayAddress(p->url()));
 back_->setEnabled(p->canGoBack());forward_->setEnabled(p->canGoForward());reload_->setProperty("iconName",p->loading()?"stop":"reload");reload_->setIcon(icon(p->loading()?"stop":"reload"));reload_->setToolTip(p->loading()?tr("Остановить загрузку"):tr("Обновить · Ctrl+R"));tabs_->setLoading(p->loading());
 int i=tabs_->currentIndex();setWindowTitle(tabs_->tabText(i)+" — Aster"+(privateMode_?tr(" · Приватно"):QString{}));
 bookmark_->setEnabled(QUrl(p->url()).scheme()=="http"||QUrl(p->url()).scheme()=="https");bookmark_->setProperty("iconName","bookmark");bookmark_->setIcon(icon("bookmark"));
}
void MainWindow::newTab(const QString& requested){
 if(closing_)return;QString url=home(requested)||requested.isEmpty()?homeUrl:requested;auto* p=new BrowserPage(context_,adblock_);pages_.insert(p);p->open(url);
 connect(p,&BrowserPage::contentFocused,this,[this,p]{if(p==current()){editingAddress_=false;address_->clearFocus();refreshChrome();}});
 connect(p,&BrowserPage::findResult,this,[this,p](int count,int active){if(p!=current())return;findCount_->setProperty("matches",count);findCount_->setText(count?tr("%1 из %2").arg(active).arg(count):tr("Не найдено"));});
 connect(p,&BrowserPage::titleChanged,this,[this,p](const QString& text){int i=tabs_->indexOf(p);if(i>=0){tabs_->setTabText(i,text.isEmpty()?tr("Новая вкладка"):text.left(40));tabs_->setTabToolTip(i,text);if(p==current())refreshChrome();}});
 connect(p,&BrowserPage::addressChanged,this,[this,p](const QString&){if(p==current())refreshChrome();saveSession();});
 connect(p,&BrowserPage::loadingChanged,this,[this,p](bool loading,bool,bool){if(p==current()){refreshChrome();status_->setText(loading?tr("Загрузка…"):home(p->url())?tr("Новая вкладка"):tr("Готово"));}});
 connect(p,&BrowserPage::loadFailed,this,[this,p](const QString& error){if(p==current())status_->setText(tr("Не удалось загрузить страницу: ")+error);});
 connect(p,&BrowserPage::completed,this,[this,p](const QString& url,const QString& title){p->setProperty("completedUrl",url);
  if(!privateMode_&&(url.startsWith("http://")||url.startsWith("https://"))){auto u=url.toUtf8().toStdString(),t=title.toUtf8().toStdString();auto now=QDateTime::currentMSecsSinceEpoch();store([=](auto& db){db.recordVisit(u,t,now);});refreshSuggestions();}
  const auto proof=qEnvironmentVariable("SHIELD_TEST_PROOF");if(!proof.isEmpty()&&QUrl(url).host()=="127.0.0.1"){QSaveFile f(proof);if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(QJsonObject{{"url",url},{"title",title},{"cefLoadCompleted",true}}).toJson());f.commit();}}
  if(!qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&QUrl(url).host()=="127.0.0.1"&&!property("downloadFixtureStarted").toBool()){
   setProperty("downloadFixtureStarted",true);const auto downloadUrl=qEnvironmentVariable("SHIELD_DOWNLOAD_TEST_URL");p->command([downloadUrl](auto b){b->GetHost()->StartDownload(downloadUrl.toStdWString());});
   QTimer::singleShot(1800,this,[this,p]{if(pages_.contains(p))p->open(homeUrl);});
  }
  if(home(url)&&!(qEnvironmentVariableIsEmpty("SHIELD_UI_AUTOMATION")&&qEnvironmentVariableIsEmpty("SHIELD_EXTERNAL_TEST")))runUiChecks();
 });
 connect(p,&BrowserPage::popupRequested,this,&MainWindow::newTab);connect(p,&BrowserPage::shortcut,this,&MainWindow::key);
 connect(p,&BrowserPage::blockedChanged,this,[this,p](quint64 n){if(p!=current())return;shield_->setProperty("ready",adblock_->ready());shield_->setToolTip(adblock_->ready()?tr("Отфильтровано сетевых запросов: %1. Нажмите, чтобы посмотреть домены.").arg(n):tr("Защита: фильтры ещё не загружены"));});
 connect(p,&BrowserPage::downloadChanged,this,[this,p](unsigned id,const QString& name,qint64 received,qint64 total,bool done,bool cancelled,int interrupted){
  downloadsEmpty_->hide();downloadsList_->show();QListWidgetItem* item=nullptr;for(int i=0;i<downloadsList_->count();++i){auto* x=downloadsList_->item(i);if(x->data(Qt::UserRole).toUInt()==id&&x->data(Qt::UserRole+1).value<quintptr>()==reinterpret_cast<quintptr>(p)){item=x;break;}}
  if(!item){item=new QListWidgetItem(downloadsList_);item->setData(Qt::UserRole,id);item->setData(Qt::UserRole+1,QVariant::fromValue(reinterpret_cast<quintptr>(p)));}
  auto size=[this](qint64 n){return n<1024?tr("%1 Б").arg(n):n<1048576?tr("%1 КБ").arg(n/1024.0,0,'f',1):tr("%1 МБ").arg(n/1048576.0,0,'f',1);};
  QString state=interrupted?tr("Загрузка прервана · код %1").arg(interrupted):done?tr("Завершено"):cancelled?tr("Отменено"):total>0?size(received)+" / "+size(total):tr("Получено %1").arg(size(received));
  item->setSizeHint(QSize(0,108));auto* card=downloadsList_->itemWidget(item);
  if(!card){card=new QWidget;auto* box=new QHBoxLayout(card);box->setContentsMargins(16,12,16,12);auto* image=new QLabel;image->setPixmap(icon("download").pixmap(28,28));box->addWidget(image);auto* col=new QVBoxLayout;auto* title=new QLabel;title->setObjectName("fileTitle");title->setWordWrap(true);auto* sub=new QLabel;sub->setObjectName("fileState");auto* progress=new QProgressBar;progress->setObjectName("fileProgress");progress->setTextVisible(false);progress->setFixedHeight(4);col->addWidget(title);col->addWidget(sub);col->addWidget(progress);box->addLayout(col,1);auto* button=new QPushButton(tr("Отменить"));button->setObjectName("fileAction");box->addWidget(button);connect(button,&QPushButton::clicked,this,[this,p,id,item]{if(item->data(Qt::UserRole+3).toBool())QDesktopServices::openUrl(QUrl::fromLocalFile(QFileInfo(item->data(Qt::UserRole+2).toString()).absolutePath()));else if(pages_.contains(p))p->cancelDownload(id);});downloadsList_->setItemWidget(item,card);}
  card->findChild<QLabel*>("fileTitle")->setText(QFileInfo(name).fileName());card->findChild<QLabel*>("fileState")->setText(state);auto* progress=card->findChild<QProgressBar*>("fileProgress");progress->setRange(0,total>0?100:0);if(total>0)progress->setValue(int(received*100/total));progress->setVisible(!done&&!cancelled&&!interrupted);auto* button=card->findChild<QPushButton*>("fileAction");button->setText(interrupted?tr("Прервано"):done?tr("Показать в папке"):tr("Отменить"));button->setEnabled(!cancelled&&!interrupted);item->setToolTip(name);item->setData(Qt::UserRole+2,name);item->setData(Qt::UserRole+3,done);
 });
 connect(p,&BrowserPage::closed,this,[this,p]{int i=tabs_->indexOf(p);if(i>=0)tabs_->removeTab(i);pages_.erase(p);p->deleteLater();if(closing_&&pages_.empty())QTimer::singleShot(0,this,&QWidget::close);});
 int i=tabs_->addTab(p,home(url)?tr("Новая вкладка"):QUrl(url).host());tabs_->setCurrentIndex(i);refreshChrome();saveSession();
 if(home(url))QTimer::singleShot(80,this,[this,p]{if(p==current()){address_->clear();address_->setFocus();}});
}
void MainWindow::navigate(){
 editingAddress_=false;auto text=address_->text().trimmed();if(text.isEmpty())return;
 if(!text.contains(' ')&&!text.startsWith("shield:")&&!text.startsWith("about:")&&(text.contains('.')||text.contains("://"))){QUrl u(text.contains("://")?text:"https://"+text);if(!u.host().isEmpty())text=QString::fromLatin1(u.toEncoded(QUrl::FullyEncoded));}
 auto result=core::classifyNavigation(text.toUtf8().toStdString());
 if(result.kind==core::NavigationKind::Internal){QString u=QString::fromStdString(result.url);if(u=="shield://history"){showHistory();return;}if(u=="shield://bookmarks"){showBookmarks();return;}if(u=="shield://settings"){showSettings();return;}if(current())current()->open(homeUrl);}
 else if(result.kind==core::NavigationKind::Web||result.kind==core::NavigationKind::Search){if(current())current()->open(QString::fromStdString(result.url));}
 else{status_->setText(tr("Адрес отклонён: поддерживаются HTTP(S)-сайты и поиск."));return;}
 if(current())current()->setFocus();address_->clearFocus();
}
void MainWindow::closeTab(int i){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));if(!p)return;closedTabs_.push_back(p->url());if(closedTabs_.size()>30)closedTabs_.removeFirst();tabs_->removeTab(i);p->hide();p->shutdown();if(!tabs_->count()&&!closing_)newTab();saveSession();}
void MainWindow::saveSession(bool clean){if(privateMode_||closing_)return;core::SessionSnapshot s;s.clean_shutdown=clean;s.active_index=std::size_t(std::max(tabs_->currentIndex(),0));for(int i=0;i<tabs_->count();++i){auto* p=qobject_cast<BrowserPage*>(tabs_->widget(i));s.tabs.push_back({p->url().toStdString(),tabs_->tabText(i).toStdString(),false});}store([s](auto& db){db.saveSession(s);});}
void MainWindow::closeEvent(QCloseEvent* e){if(pages_.empty()){if(!privateMode_)store([](auto& db){db.markSessionClean(true);});e->accept();return;}e->ignore();if(closing_)return;saveSession(false);closing_=true;setEnabled(false);auto all=pages_;for(auto* p:all)p->shutdown();}
void MainWindow::key(int key,int mods){bool shift=mods&int(Qt::ShiftModifier),alt=mods&int(Qt::AltModifier);if(key==VK_F11){isFullScreen()?showNormal():showFullScreen();return;}
 if(alt){if(key==VK_LEFT)withCurrent([](auto b){b->GoBack();});if(key==VK_RIGHT)withCurrent([](auto b){b->GoForward();});return;}
 if(key>='1'&&key<='9'){if(tabs_->count())tabs_->setCurrentIndex(key=='9'?tabs_->count()-1:std::min(key-'1',tabs_->count()-1));return;}
 switch(key){
 case VK_TAB:if(tabs_->count())tabs_->setCurrentIndex((tabs_->currentIndex()+tabs_->count()+(shift?-1:1))%tabs_->count());break;
 case 'T':if(shift){if(!closedTabs_.empty())newTab(closedTabs_.takeLast());}else newTab();break;
 case 'W':closeTab(tabs_->currentIndex());break;case 'L':address_->setFocus();address_->selectAll();break;case 'R':withCurrent([](auto b){b->Reload();});break;
 case 'D':addBookmark();break;case 'H':showHistory();break;case 'J':showDownloads();break;case 'F':showFind();break;
 case 'N':if(shift){CefRequestContextSettings s;auto c=CefRequestContext::CreateContext(s,nullptr);auto* w=new MainWindow(c,profile_,true);w->show();}break;
 case VK_OEM_PLUS:if(current())current()->zoomBy(1);break;case VK_OEM_MINUS:if(current())current()->zoomBy(-1);break;case '0':if(current())current()->resetZoom();break;
 }
 if(current()&&(key==VK_OEM_PLUS||key==VK_OEM_MINUS||key=='0'))status_->setText(tr("Масштаб: %1%").arg(current()->zoomPercent()));
}
void MainWindow::showFind(){findBar_->show();find_->setFocus();find_->selectAll();}
void MainWindow::findNext(bool forward){if(find_->text().isEmpty()){withCurrent([](auto b){b->GetHost()->StopFinding(true);});return;}withCurrent([s=find_->text().toStdWString(),forward](auto b){b->GetHost()->Find(s,forward,false,true);});}
bool MainWindow::eventFilter(QObject* o,QEvent* e){if(e->type()==QEvent::KeyPress){auto* k=static_cast<QKeyEvent*>(e);if(k->key()==Qt::Key_Escape){editingAddress_=false;if(o==find_){findBar_->hide();withCurrent([](auto b){b->GetHost()->StopFinding(true);});}if(o==address_)address_->setText(current()?displayAddress(current()->url()):QString{});if(current())current()->setFocus();return true;}}return QMainWindow::eventFilter(o,e);}
bool MainWindow::nativeEvent(const QByteArray& type,void* message,qintptr* result){
 auto* m=static_cast<MSG*>(message);
 if(m->message==WM_GETMINMAXINFO){MONITORINFO info{sizeof(info)};if(GetMonitorInfo(MonitorFromWindow(m->hwnd,MONITOR_DEFAULTTONEAREST),&info)){auto* mm=reinterpret_cast<MINMAXINFO*>(m->lParam);mm->ptMaxPosition={info.rcWork.left-info.rcMonitor.left,info.rcWork.top-info.rcMonitor.top};mm->ptMaxSize={info.rcWork.right-info.rcWork.left,info.rcWork.bottom-info.rcWork.top};mm->ptMinTrackSize={LONG(minimumWidth()*devicePixelRatioF()),LONG(minimumHeight()*devicePixelRatioF())};*result=0;return true;}}
 if(m->message==WM_NCHITTEST&&!isMaximized()&&!isFullScreen()){RECT r;GetWindowRect(m->hwnd,&r);int x=int(static_cast<short>(LOWORD(m->lParam))),y=int(static_cast<short>(HIWORD(m->lParam))),b=int(6*devicePixelRatioF());bool l=x<r.left+b,rr=x>=r.right-b,t=y<r.top+b,bb=y>=r.bottom-b;int h=t?(l?HTTOPLEFT:rr?HTTOPRIGHT:HTTOP):bb?(l?HTBOTTOMLEFT:rr?HTBOTTOMRIGHT:HTBOTTOM):l?HTLEFT:rr?HTRIGHT:0;if(h){*result=h;return true;}}
 return QMainWindow::nativeEvent(type,message,result);
}
void MainWindow::refreshSuggestions(){if(privateMode_)return;QPointer<MainWindow> g=this;store([g](auto& db){auto rows=db.history(100);QStringList urls;for(const auto& r:rows){auto u=QString::fromStdString(r.url);if(!urls.contains(u))urls<<u;}QMetaObject::invokeMethod(qApp,[g,urls]{if(g)g->suggestions_->setStringList(urls);},Qt::QueuedConnection);});}
void MainWindow::addBookmark(){if(!current()||!bookmark_->isEnabled())return;auto u=current()->url().toStdString(),t=tabs_->tabText(tabs_->currentIndex()).toStdString();auto now=QDateTime::currentMSecsSinceEpoch();QPointer<MainWindow> g=this;store([=](auto& db){db.addBookmark(u,t,now);QMetaObject::invokeMethod(qApp,[g]{if(g){g->status_->setText(tr("Сохранено в закладки · Меню → Закладки"));g->bookmark_->setProperty("iconName","star-filled");g->bookmark_->setIcon(icon("star-filled"));}},Qt::QueuedConnection);});}
void MainWindow::showHistory(){showLibrary(false);}void MainWindow::showBookmarks(){showLibrary(true);}
void MainWindow::showLibrary(bool bookmarks){
 QVBoxLayout* layout;auto* d=dialog(this,bookmarks?tr("Закладки"):tr("История"),bookmarks?tr("Ваши сохранённые страницы. Двойной щелчок — открыть."):tr("Последние 500 посещений. Приватные окна сюда не попадают."),layout);
 auto* search=new QLineEdit;search->setPlaceholderText(bookmarks?tr("Найти закладку…"):tr("Поиск в истории…"));layout->addWidget(search);
 auto* empty=new QLabel(bookmarks?tr("Сохраните то, что важно\nОткройте сайт и нажмите на звёздочку или Ctrl+D."):tr("Здесь будет история посещений\nОткрывайте сайты — и сможете быстро вернуться к ним."));empty->setObjectName("emptyState");empty->setAlignment(Qt::AlignCenter);empty->setWordWrap(true);layout->addWidget(empty,1);
 auto* list=new QListWidget;layout->addWidget(list,1);list->hide();
 auto* row=new QHBoxLayout;auto* remove=new QPushButton(bookmarks?tr("Удалить выбранную"):tr("Очистить историю"));row->addWidget(remove);remove->setEnabled(false);connect(list,&QListWidget::itemSelectionChanged,d,[list,remove,bookmarks]{remove->setEnabled(bookmarks?list->currentItem()!=nullptr:list->count()>0);});connect(list->model(),&QAbstractItemModel::rowsInserted,d,[list,remove,bookmarks]{if(!bookmarks)remove->setEnabled(list->count()>0);});connect(list->model(),&QAbstractItemModel::rowsRemoved,d,[list,remove,bookmarks]{remove->setEnabled(bookmarks?list->currentItem()!=nullptr:list->count()>0);});row->addStretch();auto* closeButton=new QPushButton(tr("Готово"));closeButton->setObjectName("primaryButton");row->addWidget(closeButton);layout->addLayout(row);connect(closeButton,&QPushButton::clicked,d,&QDialog::close);
 connect(search,&QLineEdit::textChanged,d,[list,empty](const QString& text){int visible=0;for(int i=0;i<list->count();++i){auto* x=list->item(i);bool show=x->text().contains(text,Qt::CaseInsensitive);x->setHidden(!show);if(show)++visible;}if(list->count()){list->setVisible(visible>0);empty->setText(tr("Ничего не найдено. Попробуйте другой запрос."));empty->setVisible(!visible);}});
 connect(list,&QListWidget::itemActivated,this,[this,d](auto* item){newTab(item->data(Qt::UserRole).toString());d->close();});
 connect(remove,&QPushButton::clicked,d,[this,d,list,empty,bookmarks]{if(bookmarks){auto* i=list->currentItem();if(!i)return;auto id=i->data(Qt::UserRole+1).toLongLong();store([id](auto& db){db.removeBookmark(id);});delete i;if(!list->count()){list->hide();empty->setText(tr("Пока нет закладок. Добавьте сайт с помощью Ctrl+D."));empty->show();}}
 else if(QMessageBox::question(d,tr("Очистить историю?"),tr("Все записи истории будут удалены. Закладки и cookies сохранятся."))==QMessageBox::Yes){store([](auto& db){db.clearHistory();});list->clear();list->hide();empty->setText(tr("История очищена"));empty->show();suggestions_->setStringList({});}});
 QPointer<QListWidget> safeList=list;QPointer<QLabel> safeEmpty=empty;
 store([safeList,safeEmpty,bookmarks](auto& db){struct Row{QString url,title;qint64 id;};QVector<Row> data;if(bookmarks){for(const auto& r:db.bookmarks())data.push_back({QString::fromStdString(r.url),QString::fromStdString(r.title),r.id});}else{for(const auto& r:db.history(500))data.push_back({QString::fromStdString(r.url),QString::fromStdString(r.title),0});}
 QMetaObject::invokeMethod(qApp,[safeList,safeEmpty,data]{if(!safeList||!safeEmpty)return;for(const auto& r:data){auto* x=new QListWidgetItem((r.title.isEmpty()?QUrl(r.url).host():r.title)+"\n"+r.url,safeList);x->setData(Qt::UserRole,r.url);x->setData(Qt::UserRole+1,r.id);x->setToolTip(r.url);}safeList->setVisible(!data.empty());safeEmpty->setVisible(data.empty());},Qt::QueuedConnection);});
 d->show();darkTitle(d);
}
void MainWindow::showDownloads(){downloadsDialog_->show();downloadsDialog_->raise();downloadsDialog_->activateWindow();darkTitle(downloadsDialog_);}
void MainWindow::privacy(){auto answer=QMessageBox::question(this,tr("Очистить данные сайтов?"),tr("Удалить cookies и HTTP-кэш этого окна?\n\nЭто не удаляет localStorage, service workers, историю и закладки."));if(answer!=QMessageBox::Yes)return;auto ctx=context_;onCefUi([ctx]{ctx->GetCookieManager(nullptr)->DeleteCookies(CefString(),CefString(),nullptr);ctx->ClearHttpCache(nullptr);});status_->setText(tr("Запрошена очистка cookies и HTTP-кэша"));}
void MainWindow::showProtection(){QVBoxLayout* l;auto* d=dialog(this,tr("Защита сайта"),tr("Это сетевые запросы, не найденные вирусы и не количество угроз."),l);QString host=current()?QUrl(current()->url()).host():QString{};auto* state=new QLabel(adblock_->ready()?tr("Фильтры EasyList и EasyPrivacy включены"):tr("Списки ещё не загружены"));l->addWidget(state);auto* info=new QLabel(tr("Один сайт обращается к десяткам серверов. Рекламные и аналитические запросы могут блокироваться даже на Google. Счётчик относится к текущей загрузке страницы."));info->setWordWrap(true);l->addWidget(info);auto* rows=new QListWidget;if(current())rows->addItems(current()->blockedSummary());if(!rows->count())rows->addItem(tr("На этой странице пока нет отфильтрованных запросов"));l->addWidget(rows,1);auto* toggle=new QCheckBox(tr("Блокировать рекламные и аналитические запросы"));toggle->setChecked(adblock_->enabled(host.toStdString()));toggle->setEnabled(current()&&QUrl(current()->url()).scheme().startsWith("http"));l->addWidget(toggle);connect(toggle,&QCheckBox::toggled,this,[this,host](bool v){adblock_->setEnabled(host.toStdString(),v);withCurrent([](auto b){b->Reload();});});auto* done=new QPushButton(tr("Готово"));l->addWidget(done,0,Qt::AlignRight);connect(done,&QPushButton::clicked,d,&QDialog::close);d->show();}
void MainWindow::showSettings(){
 QVBoxLayout* layout;auto* d=dialog(this,tr("Настройки"),tr("Внешний вид, запуск и данные. Без лишних переключателей."),layout);
 auto* label=new QLabel(tr("Оформление"));layout->addWidget(label);auto* row=new QHBoxLayout;auto* dark=new QPushButton(tr("Тёмная тема"));auto* light=new QPushButton(tr("Светлая тема"));row->addWidget(dark);row->addWidget(light);layout->addLayout(row);connect(dark,&QPushButton::clicked,this,[this]{applyTheme("dark");});connect(light,&QPushButton::clicked,this,[this]{applyTheme("light");});
 QSettings settings(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);auto* restore=new QCheckBox(tr("Восстанавливать открытые сайты при запуске"));restore->setChecked(settings.value("restoreSession",true).toBool());layout->addWidget(restore);connect(restore,&QCheckBox::toggled,this,[this](bool value){QSettings s(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);s.setValue("restoreSession",value);});
 auto* rules=new QPushButton(tr("Обновить фильтры блокировки"));layout->addWidget(rules);connect(rules,&QPushButton::clicked,this,&MainWindow::updateFilters);
 auto* data=new QPushButton(tr("Очистить cookies и HTTP-кэш…"));layout->addWidget(data);connect(data,&QPushButton::clicked,this,&MainWindow::privacy);
 auto* proxy=new QPushButton(tr("Соединение и свой прокси…"));layout->addWidget(proxy);connect(proxy,&QPushButton::clicked,this,&MainWindow::showProxy);
 auto* privacySignals=new QLabel(tr("По умолчанию: DNT и Global Privacy Control в HTTP(S)-запросах; WebRTC не использует прямой UDP вне прокси. Сайты могут игнорировать DNT/GPC. IP-адрес не скрывается без отдельного сетевого маршрута."));privacySignals->setWordWrap(true);privacySignals->setObjectName("dialogSubtitle");layout->addWidget(privacySignals);
 auto* info=new QLabel(tr("Приватное окно не сохраняет историю и сессию. Оно не скрывает IP-адрес; скачанные файлы остаются на диске.\n\nКамера, микрофон, геолокация и уведомления в этой версии запрещены. Автоматических обновлений пока нет."));info->setWordWrap(true);info->setObjectName("dialogSubtitle");layout->addWidget(info);layout->addStretch();auto* done=new QPushButton(tr("Готово"));done->setObjectName("primaryButton");layout->addWidget(done,0,Qt::AlignRight);connect(done,&QPushButton::clicked,d,&QDialog::close);d->show();darkTitle(d);
}
void MainWindow::applyTheme(const QString& value){
 bool light=value=="light";qApp->setProperty("lightTheme",light);QFile css(light?":/styles/light.qss":":/styles/dark.qss");if(css.open(QIODevice::ReadOnly))qApp->setStyleSheet(QString::fromUtf8(css.readAll()));setInternalTheme(light);
 QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);prefs.setValue("theme",light?"light":"dark");
 for(auto* w:QApplication::topLevelWidgets()){
  for(auto* b:w->findChildren<QToolButton*>()){auto name=b->property("iconName").toString();if(!name.isEmpty())b->setIcon(icon(name));}
  if(auto* mw=qobject_cast<MainWindow*>(w)){mw->tabs_->applyTheme();for(auto* p:mw->pages_)if(home(p->url())&&!p->isClosing())p->command([](auto b){b->Reload();});}
  if(w->isWindow()&&w->isVisible())darkTitle(w);
 }
}
void MainWindow::showProxy(){QVBoxLayout* l;auto* d=dialog(this,tr("Соединение"),tr("По умолчанию Aster использует настройки сети Windows."),l);auto* info=new QLabel(tr("Если сайт недоступен в вашей сети, нужен ваш рабочий прокси или другой доступный маршрут. Aster не содержит VPN/Tor и сам по себе не скрывает IP. Прокси видит ваш адрес; его надёжность важна."));info->setWordWrap(true);l->addWidget(info);auto* input=new QLineEdit;input->setPlaceholderText("socks5://127.0.0.1:1080");QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);input->setText(prefs.value("proxy").toString());l->addWidget(input);auto* error=new QLabel;error->setWordWrap(true);l->addWidget(error);auto* apply=new QPushButton(tr("Применить"));apply->setObjectName("primaryButton");l->addWidget(apply);auto* system=new QPushButton(tr("Использовать настройки Windows"));l->addWidget(system);l->addStretch();auto save=[this,input,error](bool reset){auto text=reset?QString{}:input->text().trimmed();QUrl url(text);if(!text.isEmpty()&&((url.scheme()!="http"&&url.scheme()!="socks5")||url.host().isEmpty()||url.port()<=0||!url.userInfo().isEmpty()||!url.query().isEmpty()||!url.fragment().isEmpty()||(!url.path().isEmpty()&&url.path()!="/"))){error->setText(tr("Нужен адрес http://host:port или socks5://host:port, без пароля и пути."));return;}QSettings prefs(QDir(profile_).filePath("appearance.ini"),QSettings::IniFormat);prefs.setValue("proxy",text);auto ctx=context_;QPointer<QLabel> e=error;onCefUi([ctx,text,e]{auto v=CefDictionaryValue::Create();v->SetString("mode",text.isEmpty()?"system":"fixed_servers");if(!text.isEmpty())v->SetString("server",text.toStdString());auto value=CefValue::Create();value->SetDictionary(v);CefString why;bool ok=ctx->SetPreference("proxy",value,why);QMetaObject::invokeMethod(qApp,[e,ok]{if(e)e->setText(ok?QString::fromUtf8("Применено. Перезагрузите сайт."):QString::fromUtf8("Движок не принял настройку. Используйте системные настройки Windows."));},Qt::QueuedConnection);});};connect(apply,&QPushButton::clicked,d,[save]{save(false);});connect(system,&QPushButton::clicked,d,[save,input]{input->clear();save(true);});d->show();}
void MainWindow::runExternalChecks(){
 const auto dir=qEnvironmentVariable("SHIELD_EXTERNAL_TEST");if(dir.isEmpty())return;QDir().mkpath(dir);QFile::remove(QDir(dir).filePath("external.jsonl"));
 auto* timer=new QTimer(this);timer->setInterval(600);auto ticks=std::make_shared<int>(0);auto stage=std::make_shared<int>(0);auto checks=std::make_shared<QJsonObject>();
 connect(timer,&QTimer::timeout,this,[this,timer,dir,ticks,stage,checks]{++*ticks;if(*ticks>260){(*checks)["timeout"]=true;QSaveFile f(QDir(dir).filePath("external-result.json"));if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(*checks).toJson());f.commit();}timer->stop();close();return;}
 auto* p=current();if(!p)return;auto capture=[this,dir](const QString& n){if(screen())screen()->grabWindow(0,frameGeometry().x(),frameGeometry().y(),width(),height()).save(QDir(dir).filePath(n));};
 QFile file(QDir(dir).filePath("external.jsonl"));QList<QJsonObject> proofs;if(file.open(QIODevice::ReadOnly)){for(const auto& line:file.readAll().split('\n')){auto j=QJsonDocument::fromJson(line);if(j.isObject())proofs<<j.object();}}
 auto seen=[&proofs](const QString& host){for(const auto& j:proofs){auto h=QUrl(j["url"].toString()).host();if((h==host||h.endsWith("."+host))&&j["text"].toInt()>100)return true;}return false;};
 if(*stage==0&&home(p->property("completedUrl").toString())&&adblock_->ready()){*stage=1;(*checks)["filtersReady"]=true;p->command([](auto b){b->GetMainFrame()->ExecuteJavaScript("document.querySelector('.tile>a[href=\"https://www.youtube.com/\"]').click()","shield://newtab/",0);});}
 else if(*stage==1&&seen("youtube.com")){(*checks)["youtubeShortcut"]=true;(*checks)["youtubeAddress"]=address_->text().contains("youtube.com");capture("youtube-real.png");*stage=2;address_->setText("https://www.google.com/");navigate();}
 else if(*stage==2&&seen("google.com")){(*checks)["googleAddressNavigation"]=true;capture("google-real.png");*stage=3;address_->setText("https://example.org/");navigate();}
 else if(*stage==3&&seen("example.org")){(*checks)["exampleAddressNavigation"]=true;*stage=4;address_->setText("http://127.0.0.1:1/");navigate();}
 else if(*stage==4&&QUrl(p->property("completedUrl").toString()).host()=="error"){(*checks)["networkErrorPage"]=true;(*checks)["failedAddressVisible"]=address_->text().contains("127.0.0.1:1");capture("network-error.png");QSaveFile f(QDir(dir).filePath("external-result.json"));if(f.open(QIODevice::WriteOnly)){f.write(QJsonDocument(*checks).toJson());f.commit();}timer->stop();close();}
 });timer->start();
}

void MainWindow::runUiChecks(){
 // Fixed local CI tour; never accepts arbitrary remote commands.
 const auto dir=qEnvironmentVariable("SHIELD_UI_AUTOMATION");if(dir.isEmpty())return;
 auto capture=[this,dir](const QString& name){QDir().mkpath(dir);if(screen())screen()->grabWindow(0,frameGeometry().x(),frameGeometry().y(),width(),height()).save(QDir(dir).filePath(name));};
 int stage=property("uiTestStage").toInt();
 if(stage==0){
  setProperty("uiTestStage",1);

  QTimer::singleShot(1200,this,[this,capture]{
   capture("newtab-dark.png");menu_->popup(menuButton_->mapToGlobal(QPoint(0,menuButton_->height()+5)));
   QTimer::singleShot(350,this,[this,capture]{capture("menu-dark.png");menu_->hide();showDownloads();QTimer::singleShot(350,this,[this,capture]{capture("downloads-dark.png");downloadsDialog_->hide();showProtection();QTimer::singleShot(350,this,[this,capture]{capture("protection-dark.png");for(auto* w:QApplication::topLevelWidgets())if(w!=this&&w!=downloadsDialog_&&qobject_cast<QDialog*>(w))w->close();applyTheme("light");});});});
  });
 }else if(stage==1){
  setProperty("uiTestStage",2);
  QTimer::singleShot(900,this,[this,capture,dir]{
   capture("newtab-light.png");showBookmarks();
   QTimer::singleShot(500,this,[this,capture,dir]{
    capture("bookmarks-light.png");
    for(auto* w:QApplication::topLevelWidgets())if(w!=this&&w!=downloadsDialog_&&qobject_cast<QDialog*>(w))w->close();
    showFind();find_->setText(tr("Хороший"));findNext();
    QTimer::singleShot(800,this,[this,capture,dir]{
     capture("find-light.png");bool found=findCount_->property("matches").toInt()>0;findBar_->hide();
     int before=tabs_->count();newTab();bool added=tabs_->count()==before+1;tabs_->setCurrentIndex(0);key(VK_TAB,int(Qt::ControlModifier));bool switched=tabs_->currentIndex()==1;closeTab(tabs_->count()-1);bool closed=tabs_->count()==before;
     key('T',int(Qt::ControlModifier|Qt::ShiftModifier));bool reopened=tabs_->count()==before+1;closeTab(tabs_->count()-1);
     if(current()){current()->zoomBy(1);current()->resetZoom();}
     key('L',int(Qt::ControlModifier));bool focused=address_->hasFocus();
     QSaveFile f(QDir(dir).filePath("ui-result.json"));if(f.open(QIODevice::WriteOnly)){
      f.write(QJsonDocument(QJsonObject{{"downloadCompleted",downloadsList_->count()>0&&downloadsList_->item(0)->data(Qt::UserRole+3).toBool()},{"home",current()&&home(current()->url())},{"addressShortcut",focused},{"tabAddClose",added&&closed},{"tabSwitch",switched},{"tabReopen",reopened},{"findMatches",found},{"zoomReset",current()&&current()->zoomPercent()==100},{"tabs",tabs_->count()},{"lightTheme",qApp->property("lightTheme").toBool()}}).toJson());f.commit();
     }
     QTimer::singleShot(700,this,&QWidget::close);
    });
   });
  });
 }
}
} // namespace shield
namespace shield {
void MainWindow::updateFilters(){
  if(property("filterUpdateBusy").toBool())return;setProperty("filterUpdateBusy",true);
  status_->setText(tr("Загрузка EasyList + EasyPrivacy по HTTPS…"));
  auto* manager=new QNetworkAccessManager(this);
  struct State{QByteArray combined;int index=0;bool failed=false;};auto state=std::make_shared<State>();
  auto next=std::make_shared<std::function<void()>>();std::weak_ptr<std::function<void()>> weakNext=next;
  *next=[this,manager,state,weakNext]{
    const QStringList urls={"https://easylist.to/easylist/easylist.txt","https://easylist.to/easylist/easyprivacy.txt"};
    if(state->index==urls.size()) {
      setProperty("filterUpdateBusy",false);manager->deleteLater();
      compileRules(state->combined,true);return;
    }
    const QUrl url(urls[state->index]);QNetworkRequest request(url);
    request.setAttribute(QNetworkRequest::RedirectPolicyAttribute,QNetworkRequest::ManualRedirectPolicy);
    request.setTransferTimeout(30000);auto* reply=manager->get(request);
    auto buffer=std::make_shared<QByteArray>();auto keepNext=weakNext.lock();
    connect(reply,&QNetworkReply::readyRead,this,[reply,buffer,state]{
      if(buffer->size()+reply->bytesAvailable()+state->combined.size()>16*1024*1024){state->failed=true;reply->abort();return;}*buffer+=reply->readAll();
    });
    connect(reply,&QNetworkReply::finished,this,[this,reply,buffer,state,manager,url,keepNext]{
      *buffer+=reply->readAll();
      const bool valid=!state->failed&&reply->error()==QNetworkReply::NoError&&reply->url()==url&&
       reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt()==200&&buffer->startsWith("[Adblock Plus")&&
       !buffer->contains('\0')&&state->combined.size()+buffer->size()<=16*1024*1024;
      reply->deleteLater();
      if(!valid){status_->setText(tr("Обновление отклонено; предыдущий рабочий список сохранён"));setProperty("filterUpdateBusy",false);manager->deleteLater();return;}
      state->combined+=*buffer;state->combined+='\n';++state->index;if(keepNext)(*keepNext)();
    });
  };
  (*next)();
}
void MainWindow::compileRules(const QByteArray& data,bool save){
  if(compilingRules_){status_->setText(tr("Компиляция правил уже выполняется. Повторите загрузку после её завершения."));return;}
  compilingRules_=true;
  auto service=adblock_;QPointer<MainWindow> guard=this;
  auto path=QDir(profile_).filePath("network-filters.txt");bool persist=save&&!privateMode_;
  auto* thread=QThread::create([service,data,guard,path,persist]{
    bool ok=service->replace(data.toStdString());bool cached=!persist;
    if(ok&&persist){QSaveFile file(path);cached=file.open(QIODevice::WriteOnly)&&file.write(data)==data.size()&&file.commit();}
    QMetaObject::invokeMethod(qApp,[guard,ok,cached]{if(guard){guard->status_->setText(ok?(cached?tr("Сетевые правила активированы; косметические правила не применяются"):tr("Правила активны, но не сохранены на диск")):tr("Ошибка компиляции правил; прежняя защита сохранена"));}},Qt::QueuedConnection);
  });
  filterWorkers_.insert(thread);connect(thread,&QThread::finished,this,[this,thread]{filterWorkers_.erase(thread);compilingRules_=false;thread->deleteLater();});thread->start();
}
}
