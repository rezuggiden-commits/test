#include <windows.h>
#include <QApplication>
#include <QDir>
#include <QFile>
#include <QLockFile>
#include <QMessageBox>
#include <QStandardPaths>
#include "include/cef_app.h"
#include "include/cef_sandbox_win.h"
#include "include/cef_version.h"
#include "shield/main_window.h"
#include "shield/brand.h"
#include "shield/internal_pages.h"
#include <QIcon>
#include <QFont>

// Called only by the CEF-supplied bootstrap executable. It creates sandbox_info
// in the EXE as required by Chromium; this DLL must never fabricate that object.
CEF_BOOTSTRAP_EXPORT int RunWinMain(HINSTANCE instance,LPWSTR,int,void* sandbox_info,cef_version_info_t*) {
  if(!sandbox_info)return 70; // No insecure fallback.
  CefMainArgs args(instance);
  auto cefApp=shield::createApp();
  int subprocess=CefExecuteProcess(args,cefApp,sandbox_info);
  if(subprocess>=0)return subprocess;
  int argc=1;char name[]="Aster";char* argv[]={name,nullptr};
  QApplication app(argc,argv);BOOL motion=TRUE;SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION,0,&motion,0);app.setProperty("reduceMotion",!motion);app.setEffectEnabled(Qt::UI_AnimateMenu,motion);app.setEffectEnabled(Qt::UI_FadeMenu,motion);app.setApplicationName(QString::fromUtf8(SHIELD_NAME));
  app.setWindowIcon(QIcon(":/icons/app.svg"));app.setFont(QFont("Segoe UI",10));
  app.setOrganizationName(QString::fromUtf8(SHIELD_ORGANIZATION));app.setApplicationVersion(SHIELD_VERSION);
  // Keep installation read-only. No cookies or history beside the binaries.
  const auto local=qEnvironmentVariable("LOCALAPPDATA");
  if(local.isEmpty())return 71;
  const auto profile=QDir(local).filePath(QString::fromUtf8(SHIELD_PROFILE_FOLDER)+"/User Data");
  if(!QDir().mkpath(profile))return 72;
  QLockFile profileLock(QDir(profile).filePath("shield.lock"));
  profileLock.setStaleLockTime(0);
  if(!profileLock.tryLock()){QMessageBox::warning(nullptr,QString::fromUtf8(SHIELD_NAME),QString::fromUtf8("Профиль уже используется другим процессом."));return 73;}
  CefSettings settings;
  settings.multi_threaded_message_loop=true;
  settings.no_sandbox=false;
  settings.command_line_args_disabled=true;
  settings.persist_session_cookies=false;
  settings.log_severity=LOGSEVERITY_DISABLE; // No browsing URLs or secrets in disk logs.
  CefString(&settings.root_cache_path)=profile.toStdWString();
  CefString(&settings.cache_path)=QDir(profile).filePath("Default").toStdWString();
  // No browser_subprocess_path: sandbox requires the same bootstrap EXE.
  if(!CefInitialize(args,settings,cefApp,sandbox_info))return CefGetExitCode();
  if(!shield::registerInternalPages()){CefShutdown();return 74;}
  auto* window=new shield::MainWindow(CefRequestContext::GetGlobalContext(),profile);
  window->show();
  const int result=app.exec();
  // A MainWindow accepts close only after every tab received OnBeforeClose.
  // Drain Qt deferred deletes so all CefRefPtrs/contexts die before shutdown.
  QCoreApplication::sendPostedEvents(nullptr,QEvent::DeferredDelete);
  CefShutdown();
  return result;
}
