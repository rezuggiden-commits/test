#include "shield/core/storage.h"
#include "shield/core/navigation.h"
#include "sqlite3.h"
#include <algorithm>
#include <limits>
#include <mutex>
#include <utility>

namespace shield::core {
namespace {
constexpr int kApplicationId=0x53484C44; // SHLD
[[noreturn]] void fail(sqlite3* db, const char* operation) {
    throw StorageError(std::string(operation)+": "+sqlite3_errmsg(db));
}
void exec(sqlite3* db,const char* sql) {
    if(sqlite3_exec(db,sql,nullptr,nullptr,nullptr)!=SQLITE_OK) fail(db,"SQLite operation failed");
}
class Statement {
    sqlite3* db_; sqlite3_stmt* stmt_=nullptr;
public:
    Statement(sqlite3* db,const char* sql):db_(db) {
        if(sqlite3_prepare_v2(db,sql,-1,&stmt_,nullptr)!=SQLITE_OK) fail(db,"Prepare failed");
    }
    ~Statement(){sqlite3_finalize(stmt_);}
    Statement(const Statement&)=delete; Statement& operator=(const Statement&)=delete;
    void text(int i,std::string_view text) {
        if(sqlite3_bind_text(stmt_,i,text.empty()?"":text.data(),static_cast<int>(text.size()),SQLITE_TRANSIENT)!=SQLITE_OK) fail(db_,"Bind failed");
    }
    void number(int i,std::int64_t n) {if(sqlite3_bind_int64(stmt_,i,n)!=SQLITE_OK) fail(db_,"Bind failed");}
    bool row() {
        auto rc=sqlite3_step(stmt_); if(rc==SQLITE_ROW) return true;
        if(rc!=SQLITE_DONE) fail(db_,"Step failed");
        return false;
    }
    void run(){if(row()) throw StorageError("Unexpected query row");}
    std::string text(int i) const {
        auto* p=sqlite3_column_text(stmt_,i); if(!p) return {};
        return {reinterpret_cast<const char*>(p),static_cast<std::size_t>(sqlite3_column_bytes(stmt_,i))};
    }
    std::int64_t number(int i) const {return sqlite3_column_int64(stmt_,i);}
};
class Transaction {
    sqlite3* db_; bool done_=false;
public:
    explicit Transaction(sqlite3* db):db_(db){exec(db_,"BEGIN IMMEDIATE");}
    ~Transaction(){if(!done_) sqlite3_exec(db_,"ROLLBACK",nullptr,nullptr,nullptr);}
    void commit(){exec(db_,"COMMIT"); done_=true;}
};
void validText(std::string_view s,std::size_t max,const char* label,bool allow_empty=true) {
    if((!allow_empty && s.empty()) || s.size()>max || s.find('\0')!=std::string_view::npos)
        throw std::invalid_argument(std::string("Invalid ")+label);
}
void validTime(std::int64_t time) {if(time<0) throw std::invalid_argument("Timestamp must be nonnegative Unix milliseconds");}
std::string canonical(std::string_view url) {
    validText(url,8192,"URL",false);
    if(!isPersistableUrl(url)) throw std::invalid_argument("URL is not eligible for persistence");
    return classifyNavigation(url).url;
}
void validKey(std::string_view key) {
    validText(key,128,"setting key",false);
    for(unsigned char c:key) if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.'))
        throw std::invalid_argument("Setting keys accept ASCII letters, digits, dot, underscore and dash");
}
} // namespace
struct Storage::Impl {
    sqlite3* db=nullptr;
    mutable std::mutex mutex;
    ~Impl(){if(db) sqlite3_close_v2(db);}
};
Storage::Storage(const std::string& path):impl_(std::make_unique<Impl>()) {
    validText(path,32768,"database path",false);
    if(sqlite3_open_v2(path.c_str(),&impl_->db,SQLITE_OPEN_READWRITE|SQLITE_OPEN_CREATE|SQLITE_OPEN_FULLMUTEX,nullptr)!=SQLITE_OK)
        fail(impl_->db,"Open failed");
    auto* db=impl_->db;
    sqlite3_extended_result_codes(db,1);
    if(sqlite3_busy_timeout(db,3000)!=SQLITE_OK) fail(db,"Busy timeout failed");
    exec(db,"PRAGMA foreign_keys=ON; PRAGMA trusted_schema=OFF;");
    int version=0, app=0;
    {Statement q(db,"PRAGMA application_id"); if(q.row()) app=static_cast<int>(q.number(0));}
    {Statement q(db,"PRAGMA user_version"); if(q.row()) version=static_cast<int>(q.number(0));}
    if(app!=0 && app!=kApplicationId) throw StorageError("Database belongs to a different application");
    if(version>1) throw StorageError("Database schema is newer than this application");
    if(version==0) {
        // Refuse to adopt an unrelated existing database, even if application_id=0.
        Statement tables(db,"SELECT count(*) FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'");
        if(tables.row() && tables.number(0)!=0) throw StorageError("Refusing to initialize a nonempty unrecognized database");
    } else if(app!=kApplicationId) throw StorageError("Missing Shield database application identifier");
    exec(db,"PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA secure_delete=ON;");
    if(version==0) {
        Transaction tx(db);
        exec(db,
            "CREATE TABLE history(id INTEGER PRIMARY KEY,url TEXT NOT NULL UNIQUE,title TEXT NOT NULL,last_visit_ms INTEGER NOT NULL CHECK(last_visit_ms>=0),visit_count INTEGER NOT NULL CHECK(visit_count>0));"
            "CREATE INDEX history_recent ON history(last_visit_ms DESC,id DESC);"
            "CREATE TABLE bookmarks(id INTEGER PRIMARY KEY,url TEXT NOT NULL UNIQUE,title TEXT NOT NULL,created_ms INTEGER NOT NULL CHECK(created_ms>=0));"
            "CREATE TABLE settings(key TEXT PRIMARY KEY NOT NULL,value TEXT NOT NULL);"
            "CREATE TABLE session_tabs(position INTEGER PRIMARY KEY CHECK(position>=0),url TEXT NOT NULL,title TEXT NOT NULL);"
            "CREATE TABLE session_state(singleton INTEGER PRIMARY KEY CHECK(singleton=1),active_index INTEGER NOT NULL CHECK(active_index>=0),clean_shutdown INTEGER NOT NULL CHECK(clean_shutdown IN(0,1)));"
            "INSERT INTO session_state VALUES(1,0,1);"
            "PRAGMA application_id=1397247044; PRAGMA user_version=1;");
        tx.commit();
    }
    int ignored=0;
    if(sqlite3_db_config(db,SQLITE_DBCONFIG_DEFENSIVE,1,&ignored)!=SQLITE_OK) fail(db,"Defensive mode failed");
}
Storage::~Storage()=default;
bool Storage::recordVisit(std::string_view url,std::string_view title,std::int64_t time,PrivacyFlags privacy) {
    if(privacy.private_mode || !privacy.record_history) return false;
    auto address=canonical(url);
    if(classifyNavigation(address).kind!=NavigationKind::Web) return false;
    validText(title,4096,"title"); validTime(time);
    std::lock_guard lock(impl_->mutex);
    Statement q(impl_->db,"INSERT INTO history(url,title,last_visit_ms,visit_count) VALUES(?,?,?,1) ON CONFLICT(url) DO UPDATE SET title=CASE WHEN excluded.last_visit_ms>=history.last_visit_ms THEN excluded.title ELSE history.title END,last_visit_ms=max(history.last_visit_ms,excluded.last_visit_ms),visit_count=history.visit_count+1");
    q.text(1,address);q.text(2,title);q.number(3,time);q.run(); return true;
}
std::vector<HistoryEntry> Storage::history(std::size_t limit,std::size_t offset) const {
    if(limit>10000 || offset>static_cast<std::size_t>(std::numeric_limits<std::int64_t>::max())) throw std::invalid_argument("Invalid history pagination");
    std::lock_guard lock(impl_->mutex);
    Statement q(impl_->db,"SELECT id,url,title,last_visit_ms,visit_count FROM history ORDER BY last_visit_ms DESC,id DESC LIMIT ? OFFSET ?");
    q.number(1,static_cast<std::int64_t>(limit));q.number(2,static_cast<std::int64_t>(offset));
    std::vector<HistoryEntry> result;
    while(q.row()) result.push_back({q.number(0),q.text(1),q.text(2),q.number(3),q.number(4)});
    return result;
}
void Storage::clearHistory(){std::lock_guard lock(impl_->mutex);exec(impl_->db,"DELETE FROM history");}
void Storage::pruneHistoryBefore(std::int64_t cutoff) {
    validTime(cutoff);std::lock_guard lock(impl_->mutex);
    Statement q(impl_->db,"DELETE FROM history WHERE last_visit_ms<?");q.number(1,cutoff);q.run();
}
std::int64_t Storage::addBookmark(std::string_view url,std::string_view title,std::int64_t time) {
    auto address=canonical(url);validText(title,4096,"title");validTime(time);
    std::lock_guard lock(impl_->mutex); Transaction tx(impl_->db);
    Statement q(impl_->db,"INSERT INTO bookmarks(url,title,created_ms) VALUES(?,?,?) ON CONFLICT(url) DO UPDATE SET title=excluded.title");
    q.text(1,address);q.text(2,title);q.number(3,time);q.run();
    Statement id(impl_->db,"SELECT id FROM bookmarks WHERE url=?");id.text(1,address);
    if(!id.row()) throw StorageError("Bookmark insert returned no row");
    auto result=id.number(0); // Finish SELECT before COMMIT.
    if(id.row()) throw StorageError("Duplicate bookmark URL");
    tx.commit();return result;
}
bool Storage::removeBookmark(std::int64_t id) {
    if(id<=0) return false;
    std::lock_guard lock(impl_->mutex);Statement q(impl_->db,"DELETE FROM bookmarks WHERE id=?");q.number(1,id);q.run();return sqlite3_changes(impl_->db)>0;
}
std::vector<Bookmark> Storage::bookmarks() const {
    std::lock_guard lock(impl_->mutex); Statement q(impl_->db,"SELECT id,url,title,created_ms FROM bookmarks ORDER BY created_ms DESC,id DESC");
    std::vector<Bookmark> result;while(q.row()) result.push_back({q.number(0),q.text(1),q.text(2),q.number(3)});return result;
}
void Storage::setSetting(std::string_view key,std::string_view value) {
    validKey(key);validText(value,65536,"setting value");std::lock_guard lock(impl_->mutex);
    Statement q(impl_->db,"INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");q.text(1,key);q.text(2,value);q.run();
}
std::optional<std::string> Storage::setting(std::string_view key) const {
    validKey(key);std::lock_guard lock(impl_->mutex);Statement q(impl_->db,"SELECT value FROM settings WHERE key=?");q.text(1,key);
    if(q.row()) return q.text(0);
    return std::nullopt;
}
bool Storage::removeSetting(std::string_view key) {
    validKey(key);std::lock_guard lock(impl_->mutex);Statement q(impl_->db,"DELETE FROM settings WHERE key=?");q.text(1,key);q.run();return sqlite3_changes(impl_->db)>0;
}
bool Storage::saveSession(const SessionSnapshot& session,PrivacyFlags privacy) {
    if(privacy.private_mode || !privacy.persist_session) return false;
    if(session.tabs.size()>200 || (!session.tabs.empty() && session.active_index>=session.tabs.size()) || (session.tabs.empty() && session.active_index!=0))
        throw std::invalid_argument("Invalid session size or active index");
    std::vector<SessionTab> tabs;std::size_t active=0;
    for(std::size_t i=0;i<session.tabs.size();++i) {
        const auto& tab=session.tabs[i];if(tab.private_mode) continue;
        auto url=canonical(tab.url);validText(tab.title,4096,"tab title");
        if(i==session.active_index) active=tabs.size();
        tabs.push_back({std::move(url),tab.title,false});
    }
    std::lock_guard lock(impl_->mutex);Transaction tx(impl_->db);
    exec(impl_->db,"DELETE FROM session_tabs");
    for(std::size_t i=0;i<tabs.size();++i) {
        Statement q(impl_->db,"INSERT INTO session_tabs(position,url,title) VALUES(?,?,?)");
        q.number(1,static_cast<std::int64_t>(i));q.text(2,tabs[i].url);q.text(3,tabs[i].title);q.run();
    }
    Statement state(impl_->db,"UPDATE session_state SET active_index=?,clean_shutdown=? WHERE singleton=1");
    state.number(1,static_cast<std::int64_t>(active));state.number(2,session.clean_shutdown?1:0);state.run();tx.commit();return true;
}
SessionSnapshot Storage::loadSession() const {
    std::lock_guard lock(impl_->mutex);SessionSnapshot result;
    // One read transaction ensures snapshot consistency with other connections.
    exec(impl_->db,"BEGIN");
    try {
        Statement state(impl_->db,"SELECT active_index,clean_shutdown FROM session_state WHERE singleton=1");
        if(!state.row()) throw StorageError("Missing session state");
        auto active=state.number(0);result.clean_shutdown=state.number(1)!=0;
        Statement tabs(impl_->db,"SELECT position,url,title FROM session_tabs ORDER BY position");
        while(tabs.row()) {
            if(result.tabs.size()>=200 || tabs.number(0)!=static_cast<std::int64_t>(result.tabs.size())) throw StorageError("Invalid stored session positions");
            auto url=tabs.text(1);if(!isPersistableUrl(url)) throw StorageError("Unsafe stored session URL");
            result.tabs.push_back({std::move(url),tabs.text(2),false});
        }
        if(active<0 || (result.tabs.empty()?active!=0:static_cast<std::size_t>(active)>=result.tabs.size())) throw StorageError("Invalid stored active tab");
        result.active_index=static_cast<std::size_t>(active);
        exec(impl_->db,"COMMIT");return result;
    } catch(...) {sqlite3_exec(impl_->db,"ROLLBACK",nullptr,nullptr,nullptr);throw;}
}
void Storage::markSessionClean(bool clean) {
    std::lock_guard lock(impl_->mutex);Statement q(impl_->db,"UPDATE session_state SET clean_shutdown=? WHERE singleton=1");q.number(1,clean?1:0);q.run();
}
void Storage::clearSession() {
    std::lock_guard lock(impl_->mutex);Transaction tx(impl_->db);
    exec(impl_->db,"DELETE FROM session_tabs; UPDATE session_state SET active_index=0,clean_shutdown=1 WHERE singleton=1");tx.commit();
}
void Storage::clearBrowsingData(bool include_bookmarks) {
    std::lock_guard lock(impl_->mutex);Transaction tx(impl_->db);
    exec(impl_->db,"DELETE FROM history; DELETE FROM settings; DELETE FROM session_tabs; UPDATE session_state SET active_index=0,clean_shutdown=1 WHERE singleton=1");
    if(include_bookmarks) exec(impl_->db,"DELETE FROM bookmarks");
    tx.commit();
}
std::string Storage::integrityCheck() const {
    std::lock_guard lock(impl_->mutex);Statement q(impl_->db,"PRAGMA integrity_check");std::string result;
    while(q.row()){if(!result.empty()) result+='\n';result+=q.text(0);}return result;
}
} // namespace shield::core
