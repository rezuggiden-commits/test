# Cross-platform source/helper checks. NOT a Windows build/GUI/installer test.
[CmdletBinding()]
param()
. "$PSScriptRoot/../common.ps1"
$failures=0
Get-ChildItem -LiteralPath (Join-Path $Root 'tools') -Filter '*.ps1' -File -Recurse | ForEach-Object {
    $tokens=$null; $errors=$null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors) | Out-Null
    if ($errors) { $errors | Write-Output; $script:failures++ }
}
if ($failures) { throw "$failures syntax failures" }
$originalRoot=$Root
$temp=Join-Path ([IO.Path]::GetTempPath()) ('shield-guards-'+[Guid]::NewGuid().ToString('N'))
function Must-Fail([scriptblock]$Action) {
    $failed=$false
    try { & $Action | Out-Null } catch { $failed=$true }
    if (-not $failed) { throw 'Expected fail-closed behavior did not occur.' }
}
try {
    New-Item -ItemType Directory -Path (Join-Path $temp 'build/bin/Release') -Force | Out-Null
    $script:Root=$temp
    Must-Fail { Test-Evidence }
    $dll=Join-Path $temp 'build/bin/Release/ShieldBrowser.dll'
    'fake fixture, not a DLL' | Set-Content $dll
    $marker=Join-Path $temp 'build/tests-passed.json'
    @{configuration='Release';testCount=0;dllSha256=Hash $dll} | ConvertTo-Json | Set-Content $marker
    Must-Fail { Test-Evidence }
    @{configuration='Release';testCount=1;dllSha256=Hash $dll} | ConvertTo-Json | Set-Content $marker
    Test-Evidence | Out-Null
    Add-Content $dll 'tampered'
    Must-Fail { Test-Evidence }
    $stage=Join-Path $temp 'stage'
    New-Item -ItemType Directory -Path (Join-Path $stage 'nested') -Force | Out-Null
    'root manifest excluded' | Set-Content (Join-Path $stage 'stage-manifest.json')
    'nested manifest must be included' | Set-Content (Join-Path $stage 'nested/stage-manifest.json')
    $files=@(Get-TreeManifest $stage)
    if ($files.Count -ne 1 -or $files[0].path -ne 'nested/stage-manifest.json') { throw 'Tree manifest coverage failure.' }
    Write-Host 'PASS syntax, missing/empty/stale test-evidence guards, and manifest coverage.'
} finally {
    $script:Root=$originalRoot
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
