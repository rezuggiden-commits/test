Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:Root = Split-Path $PSScriptRoot -Parent
$script:Lock = Get-Content (Join-Path $Root 'dependencies.lock.json') -Raw | ConvertFrom-Json
function Assert-Windows {
    if ([Environment]::OSVersion.Platform -ne 'Win32NT') { throw 'Windows x64 is required.' }
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'A 64-bit OS is required.' }
}
function Require-File([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Required file missing: $Path" }
}
function Run([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Program failed with exit code $LASTEXITCODE" }
}
function Hash([string]$Path) { Require-File $Path; (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Build-Dir { Join-Path $Root 'build' }
function Stage-Dir { Join-Path $Root 'dist/stage' }
function Get-QtRoot {
    if ($env:Qt6_DIR) { $p = [IO.Path]::GetFullPath((Join-Path $env:Qt6_DIR '../../..')); if (Test-Path (Join-Path $p 'bin/qmake.exe')) { return $p } }
    foreach ($p in ($env:CMAKE_PREFIX_PATH -split ';')) {
        if ($p -and (Test-Path (Join-Path $p 'bin/qmake.exe'))) { return [IO.Path]::GetFullPath($p) }
    }
    throw 'Set Qt6_DIR to <Qt kit>/lib/cmake/Qt6 or CMAKE_PREFIX_PATH to the Qt MSVC2022 x64 kit.'
}
function Test-Evidence {
    $path = Join-Path (Build-Dir) 'tests-passed.json'
    Require-File $path
    $e = Get-Content $path -Raw | ConvertFrom-Json
    if ($e.configuration -ne 'Release' -or $e.testCount -lt 1) { throw 'No successful Release CTest evidence.' }
    $dll = Join-Path (Build-Dir) 'bin/Release/Aster.dll'
    if ((Hash $dll) -ne $e.dllSha256) { throw 'DLL changed since tests; run test.ps1 again.' }
    return $e
}
function Get-TreeManifest([string]$Directory) {
    $base = [IO.Path]::GetFullPath($Directory).TrimEnd('\','/')
    @(Get-ChildItem -LiteralPath $base -File -Recurse | Where-Object { $_.FullName -ne (Join-Path $base 'stage-manifest.json') } | Sort-Object FullName | ForEach-Object {
        [ordered]@{ path = $_.FullName.Substring($base.Length + 1).Replace('\','/'); sha256 = Hash $_.FullName }
    })
}
