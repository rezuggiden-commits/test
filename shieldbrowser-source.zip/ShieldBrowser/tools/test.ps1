[CmdletBinding()]
param()
. "$PSScriptRoot/common.ps1"
Assert-Windows
$evidence = Join-Path (Build-Dir) 'tests-passed.json'
Remove-Item -LiteralPath $evidence -ErrorAction SilentlyContinue
$listing = & ctest.exe --test-dir (Build-Dir) -C Release --show-only=json-v1
if ($LASTEXITCODE -ne 0) { throw 'CTest discovery failed.' }
$tests = ($listing -join "`n") | ConvertFrom-Json
if (@($tests.tests).Count -lt 1) { throw 'No registered CTest tests; refusing empty test success.' }
Run 'ctest.exe' @('--test-dir',(Build-Dir),'-C','Release','--output-on-failure','--no-tests=error')
@{configuration='Release'; testCount=@($tests.tests).Count; utc=[DateTime]::UtcNow.ToString('o'); dllSha256=Hash (Join-Path (Build-Dir) 'bin/Release/Aster.dll')} | ConvertTo-Json | Set-Content -LiteralPath $evidence -Encoding UTF8
