[CmdletBinding()]
param([string]$DependencyDirectory, [switch]$DownloadInno)
. "$PSScriptRoot/common.ps1"
Assert-Windows
if (-not $DependencyDirectory) { $DependencyDirectory = Join-Path $Root '.deps' }
$DependencyDirectory = [IO.Path]::GetFullPath($DependencyDirectory)
New-Item -ItemType Directory -Force $DependencyDirectory | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Fetch-Verified([string]$Url, [string]$Destination, [string]$Sha256) {
    if (-not $Url.StartsWith('https://')) { throw 'HTTPS is required.' }
    if (-not (Test-Path -LiteralPath $Destination)) {
        $partial = "$Destination.partial"
        try { Write-Host "Downloading verified SDK: $Url"; & curl.exe --fail --location --retry 3 --connect-timeout 30 --max-time 600 --output $partial $Url; if ($LASTEXITCODE -ne 0) { throw "SDK download failed: $LASTEXITCODE" }; if ((Hash $partial) -ne $Sha256) { throw 'Downloaded SHA256 mismatch.' }; Move-Item -LiteralPath $partial -Destination $Destination -Force }
        finally { if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force } }
    }
    if ((Hash $Destination) -ne $Sha256) { throw "SHA256 mismatch: $Destination. Remove the corrupt cached file and retry." }
}
$archive = Join-Path $DependencyDirectory $Lock.cef.archive
Fetch-Verified $Lock.cef.url $archive $Lock.cef.sha256
if ((Get-Item -LiteralPath $archive).Length -ne $Lock.cef.size) { throw 'CEF archive size mismatch.' }
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA1).Hash.ToLowerInvariant() -ne $Lock.cef.sha1) { throw 'CEF official legacy SHA1 mismatch.' }
$folder = $Lock.cef.archive -replace '\.tar\.bz2$', ''
$cef = Join-Path $DependencyDirectory $folder
$sourceMarker = Join-Path $cef '.shield-source-sha256'
if (Test-Path -LiteralPath $cef) {
    Require-File $sourceMarker
    if ((Get-Content -LiteralPath $sourceMarker -Raw).Trim() -ne $Lock.cef.sha256) { throw 'Existing SDK has no matching extraction marker; remove it and rerun setup.' }
} else {
    $unpack = Join-Path $DependencyDirectory ('.extract-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory $unpack | Out-Null
    try {
        Run 'tar.exe' @('-xjf', $archive, '-C', $unpack)
        $extracted = Join-Path $unpack $folder
        foreach ($file in @('Release/bootstrap.exe','Release/libcef.dll','Resources/resources.pak','include/cef_version.h','LICENSE.txt')) { Require-File (Join-Path $extracted $file) }
        $Lock.cef.sha256 | Set-Content -LiteralPath (Join-Path $extracted '.shield-source-sha256') -Encoding ASCII
        Move-Item -LiteralPath $extracted -Destination $cef
    } finally { if (Test-Path -LiteralPath $unpack) { Remove-Item -LiteralPath $unpack -Recurse -Force } }
}
Require-File (Join-Path $cef 'Release/bootstrap.exe')
$env:CEF_ROOT = $cef
Write-Host "CEF_ROOT=$cef (set for this PowerShell session only)"
Write-Host "For a new shell: `$env:CEF_ROOT = '$cef'"
if ($DownloadInno) {
    $inno = Join-Path $DependencyDirectory "innosetup-$($Lock.innoSetup.version).exe"
    Fetch-Verified $Lock.innoSetup.url $inno $Lock.innoSetup.sha256
    $sig = Get-AuthenticodeSignature -LiteralPath $inno
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Pyrsys B\.V\.') { throw 'Inno Setup Authenticode validation failed.' }
    Write-Host "Verified installer: $inno. Run it manually; setup does not silently install software."
}
Write-Host 'Install VS2022 C++ desktop tools + Windows SDK, CMake >=3.25, Rust MSVC stable, and Qt 6.11.2 MSVC2022 x64 manually. Then run check.ps1 in an x64 VS developer shell.'
