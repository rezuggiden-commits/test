$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$root=Split-Path $PSScriptRoot -Parent
Set-Location $root
$vswhere="${env:ProgramFiles(x86)}/Microsoft Visual Studio/Installer/vswhere.exe"
$vs=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$vs){throw 'VS2022 C++ toolchain missing'}
Import-Module "$vs/Common7/Tools/Microsoft.VisualStudio.DevShell.dll"
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64'
$qt=Join-Path $env:RUNNER_TEMP 'ShieldQt/msvc2022_64'
New-Item -ItemType Directory -Path $qt -Force | Out-Null
$archives=Get-Content "$root/config/qt-windows-archives.json" -Raw | ConvertFrom-Json
foreach($archive in $archives){
 $file=Join-Path $env:RUNNER_TEMP $archive.archive
 Invoke-WebRequest -Uri $archive.url -OutFile $file
 if((Get-FileHash $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archive.sha256){throw "Qt SHA256 mismatch: $file"}
 & 7z.exe x -y "-o$qt" $file | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Qt archive extraction failed'}
}
# Qt SDK relocatability: qmake and tools read qt.conf from their bin directory.
@('[Paths]','Prefix=..') | Set-Content "$qt/bin/qt.conf" -Encoding ascii
$env:Qt6_DIR="$qt/lib/cmake/Qt6";$env:PATH="$qt/bin;$env:PATH"
& "$PSScriptRoot/setup.ps1"
& "$PSScriptRoot/check.ps1"
& "$PSScriptRoot/configure.ps1"
& "$PSScriptRoot/build.ps1"
& "$PSScriptRoot/test.ps1"
# The pinned SDK has module license/SPDX metadata; include all supplied license material.
$qtLicenses=Join-Path $env:RUNNER_TEMP 'ShieldQtLicenses'
New-Item -ItemType Directory -Path $qtLicenses -Force | Out-Null
Copy-Item "$root/packaging/licenses/qt/*" -Destination $qtLicenses -Recurse -Force
foreach($folder in @('licenses','LICENSES','sbom')){
 $path=Join-Path $qt $folder
 if(Test-Path $path){Copy-Item $path -Destination $qtLicenses -Recurse -Force}
}
if(@(Get-ChildItem $qtLicenses -File -Recurse).Count -eq 0){throw 'Qt license texts missing in pinned archives; do not package without notices'}
& "$PSScriptRoot/deploy.ps1" -QtLicenseDirectory $qtLicenses
& "$root/tests/integration/windows_smoke.ps1" -Stage "$root/dist/stage"
# Recreate manifest AFTER smoke (profile remains outside installation).
& "$PSScriptRoot/deploy.ps1" -QtLicenseDirectory $qtLicenses
$portable=Join-Path $root 'dist/ShieldBrowser-Windows-x64-portable.zip'
& 7z.exe a -tzip $portable "$root/dist/stage/*" | Out-Null
if($LASTEXITCODE -ne 0){throw 'Portable ZIP creation failed'}
'Extract ALL files into a folder, then run ShieldBrowser.exe. Unsigned development build; keep accompanying DLL/resources.' | Set-Content "$root/dist/START-HERE.txt"
