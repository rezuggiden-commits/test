; Compile ONLY through tools/package.ps1: tests and stage integrity are checked there.
#ifndef StageDir
  #error StageDir is required; run tools/package.ps1
#endif
#ifndef OutputDir
  #error OutputDir is required
#endif
#ifndef AppVersion
  #error AppVersion is required
#endif
[Setup]
AppId={{783F47D4-1BF6-4F56-B29C-AF536D665AC8}
AppName=ShieldBrowser
AppVersion={#AppVersion}
AppPublisher=ShieldBrowser Project
DefaultDirName={localappdata}\Programs\ShieldBrowser
DefaultGroupName=ShieldBrowser
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
OutputDir={#OutputDir}
OutputBaseFilename=ShieldBrowser-{#AppVersion}-windows-x64-unsigned
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\ShieldBrowser.exe
CloseApplications=yes
RestartApplications=no
SetupLogging=yes
VersionInfoDescription=ShieldBrowser unsigned development preview

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\ShieldBrowser"; Filename: "{app}\ShieldBrowser.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\ShieldBrowser"; Filename: "{app}\ShieldBrowser.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\ShieldBrowser.exe"; Description: "Launch ShieldBrowser"; Flags: nowait postinstall skipifsilent

[Code]
// Profile data is deliberately NOT in [UninstallDelete]. Normal/silent uninstall
// preserves it. Only an explicit interactive confirmation deletes the fixed leaf.
function GetFileAttributes(const FileName: String): LongWord;
  external 'GetFileAttributesW@kernel32.dll stdcall';

function HasReparsePoint(const Path: String): Boolean;
var
  Attributes: LongWord;
begin
  Attributes := GetFileAttributes(Path);
  Result := (Attributes <> $FFFFFFFF) and ((Attributes and $400) <> 0);
end;

function TreeIsPlain(const Path: String): Boolean;
var
  Entry: TFindRec;
  Child: String;
begin
  Result := False;
  if HasReparsePoint(Path) then exit;
  if FindFirst(Path + '\*', Entry) then begin
    try
      repeat
        if (Entry.Name <> '.') and (Entry.Name <> '..') then begin
          if (Entry.Attributes and $400) <> 0 then exit;
          if (Entry.Attributes and $10) <> 0 then begin
            Child := Path + '\' + Entry.Name;
            if not TreeIsPlain(Child) then exit;
          end;
        end;
      until not FindNext(Entry);
    finally
      FindClose(Entry);
    end;
  end else exit;
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  ParentPath, ProfilePath: String;
begin
  if (CurUninstallStep <> usPostUninstall) or UninstallSilent then exit;
  ParentPath := ExpandConstant('{localappdata}\ShieldBrowser');
  ProfilePath := ParentPath + '\User Data';
  if not DirExists(ProfilePath) then exit;
  if MsgBox('Keep your browsing profile? Select Yes to KEEP it (recommended). Select No to permanently delete ShieldBrowser history, cookies and settings.', mbConfirmation, MB_YESNO or MB_DEFBUTTON1) = IDYES then exit;
  // Refuse deletion through redirected parent/profile junctions. Never delete
  // localappdata, its ShieldBrowser parent, another app, or a command-line path.
  if HasReparsePoint(ExpandConstant('{localappdata}')) or
     HasReparsePoint(ParentPath) or not TreeIsPlain(ProfilePath) then begin
    MsgBox('Profile deletion refused because the path is redirected. The profile was preserved.', mbInformation, MB_OK);
    exit;
  end;
  if MsgBox('Permanently delete only ' + ProfilePath + '? This cannot be undone.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) <> IDYES then exit;
  if not DelTree(ProfilePath, True, True, True) then
    MsgBox('Some profile files could not be removed. Close ShieldBrowser and remove them manually if desired.', mbInformation, MB_OK);
end;
