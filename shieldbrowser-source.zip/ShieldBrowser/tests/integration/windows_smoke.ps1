[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop'
$root=Resolve-Path "$PSScriptRoot/../.."
$proof=Join-Path $root 'docs/browser-load-proof.json'
$jsProof=Join-Path $root 'docs/browser-js-proof.json'
$portFile=Join-Path $root 'docs/browser-smoke-port.txt'
foreach($file in @($proof,$jsProof,$portFile)){Remove-Item -LiteralPath $file -ErrorAction SilentlyContinue}
$server=Start-Process python -ArgumentList @("$PSScriptRoot/smoke_server.py",'--proof',$jsProof,'--port-file',$portFile) -PassThru -RedirectStandardOutput (Join-Path $root 'docs/smoke-http.log') -RedirectStandardError (Join-Path $root 'docs/smoke-http-errors.log')
$app=$null
try {
 $limit=(Get-Date).AddSeconds(20);while(!(Test-Path $portFile) -and (Get-Date)-lt$limit){Start-Sleep -Milliseconds 200}
 if(!(Test-Path $portFile)){throw 'Smoke fixture failed to start'}
 $port=(Get-Content $portFile -Raw).Trim()
 $profile=Join-Path $env:LOCALAPPDATA 'ShieldBrowser/User Data'
 New-Item -ItemType Directory -Path $profile -Force | Out-Null
 '[Adblock Plus 2.0]', '/blocked-ad.png$image', '@@/allowed.png$image' | Set-Content -LiteralPath (Join-Path $profile 'network-filters.txt') -Encoding UTF8
 $env:SHIELD_START_URL="http://127.0.0.1:$port/";$env:SHIELD_TEST_PROOF=$proof
 $app=Start-Process (Join-Path $Stage 'ShieldBrowser.exe') -WorkingDirectory $Stage -PassThru
 $limit=(Get-Date).AddSeconds(90)
 while((!(Test-Path $proof) -or !(Test-Path $jsProof)) -and (Get-Date)-lt$limit){
  $app.Refresh();if($app.HasExited){throw "Browser exited before rendering fixture: $($app.ExitCode)"};Start-Sleep -Milliseconds 300
 }
 if(!(Test-Path $proof) -or !(Test-Path $jsProof)){throw 'Timed out waiting for real CEF page/JavaScript proofs'}
 $loaded=Get-Content $proof -Raw | ConvertFrom-Json;$js=Get-Content $jsProof -Raw | ConvertFrom-Json
 if(!$loaded.cefLoadCompleted -or $loaded.url -ne $env:SHIELD_START_URL){throw 'Unexpected completed CEF navigation'}
 if($js.allowed -ne 'true' -or $js.blocked -ne 'true' -or $js.dom -ne 'Actual Chromium page'){throw "Rendering/filtering proof failed: $(Get-Content $jsProof -Raw)"}
 $app.Refresh();if($app.MainWindowHandle -eq 0){throw 'Browser has no visible main window'}
 if(!$app.CloseMainWindow()){throw 'CloseMainWindow failed'}
 if(!$app.WaitForExit(30000)){throw 'CEF/Qt shutdown did not complete within 30 seconds'}
 if($app.ExitCode -ne 0){throw "Browser exit code $($app.ExitCode)"}
 $ui=Join-Path $root 'docs/ui-preview'
 New-Item -ItemType Directory -Path $ui -Force | Out-Null
 $env:SHIELD_START_URL='shield://newtab/'
 $env:SHIELD_UI_AUTOMATION=$ui
 $app=Start-Process (Join-Path $Stage 'ShieldBrowser.exe') -WorkingDirectory $Stage -PassThru
 if(!$app.WaitForExit(60000)){throw 'UI tour did not exit within 60 seconds'}
 if($app.ExitCode -ne 0){throw "UI tour exit code $($app.ExitCode)"}
 $dom=Get-Content (Join-Path $ui 'home-dom-proof.json') -Raw | ConvertFrom-Json
 if($dom.formAction -ne 'https://www.google.com/search' -or $dom.shortcutCount -ne 4 -or !$dom.addButton){throw 'New tab DOM/JavaScript failed'}
 $uiResult=Get-Content (Join-Path $ui 'ui-result.json') -Raw | ConvertFrom-Json
 if(!$uiResult.home -or !$uiResult.addressShortcut -or !$uiResult.lightTheme -or !$uiResult.tabAddClose -or !$uiResult.tabSwitch -or !$uiResult.tabReopen -or !$uiResult.findMatches -or !$uiResult.zoomReset){throw 'UI tour assertions failed'}
 foreach($file in @('newtab-dark.png','newtab-light.png','menu-dark.png','bookmarks-light.png','find-light.png')){
  if(!(Test-Path (Join-Path $ui $file))){throw "UI screenshot missing: $file"}
 }
 'PASS: dark/light start page, menu, bookmarks empty state, find bar, Ctrl+L and clean UI shutdown' | Set-Content (Join-Path $ui 'result.txt')
 'PASS: actual CEF HTML/DOM/JavaScript, allowed image, blocked ad request, native main window, clean shutdown' | Tee-Object (Join-Path $root 'docs/windows-browser-smoke-result.txt')
} finally {
 Remove-Item Env:SHIELD_UI_AUTOMATION -ErrorAction SilentlyContinue;Remove-Item Env:SHIELD_START_URL -ErrorAction SilentlyContinue;Remove-Item Env:SHIELD_TEST_PROOF -ErrorAction SilentlyContinue
 if($app -and !$app.HasExited){& taskkill.exe /PID $app.Id /T /F | Out-Null}
 if(!$server.HasExited){Stop-Process -Id $server.Id -Force}
}
