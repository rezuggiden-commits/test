import argparse, base64, json, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--proof',required=True);parser.add_argument('--port-file',required=True);args=parser.parse_args()
image=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aO2kAAAAASUVORK5CYII=')
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  parsed=urlparse(self.path)
  if parsed.path=='/':
   body=b'''<!doctype html><title>ShieldBrowser CEF smoke</title><h1 id="proof">Actual Chromium page</h1><script>
   setTimeout(async()=>{
    const img=(url)=>new Promise(resolve=>{const image=new Image();image.onload=()=>resolve(true);image.onerror=()=>resolve(false);image.src=url;document.body.append(image);});
    const allowed=await img('/allowed.png');const blocked=!(await img('/blocked-ad.png'));
    await fetch('/proof?allowed='+allowed+'&blocked='+blocked+'&dom='+encodeURIComponent(document.getElementById('proof').textContent));
   },3000);</script>''';mime='text/html'
  elif parsed.path=='/proof':
   data={k:v[0] for k,v in parse_qs(parsed.query).items()};Path(args.proof).write_text(json.dumps(data));body=b'ok';mime='text/plain'
  elif parsed.path.endswith('.png'):body=image;mime='image/png'
  else:body=b'not found';mime='text/plain'
  self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,fmt,*args): print(fmt%args,flush=True)
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);Path(args.port_file).write_text(str(server.server_port));server.serve_forever()
