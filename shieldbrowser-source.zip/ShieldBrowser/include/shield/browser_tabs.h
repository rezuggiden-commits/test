#pragma once
#include <QWidget>
#include <QVector>
class QToolButton;
class QTabBar; class QStackedWidget; class QVBoxLayout; class QToolBar; class QProgressBar;
namespace shield {
QToolButton* makeCloseButton(QWidget* parent=nullptr);
// A real tab strip above the navigation bar, with a stable native browser host.
class BrowserTabs final : public QWidget {
 Q_OBJECT
 public:
  explicit BrowserTabs(QWidget* window, bool privateMode=false);
  int addTab(QWidget*, const QString&); void removeTab(int);
  int count() const; int currentIndex() const; QWidget* currentWidget() const;
  QWidget* widget(int) const; int indexOf(QWidget*) const;
  void setCurrentIndex(int); void setTabText(int,const QString&); QString tabText(int) const;
  void setTabToolTip(int,const QString&); QString tabToolTip(int) const;
  void applyTheme(); void setNavigation(QWidget*); void setFindBar(QWidget*); void setLoading(bool);
 signals:
  void currentChanged(int); void tabCloseRequested(int); void newTabRequested();
 private:
  QTabBar* bar_; QStackedWidget* stack_; QVBoxLayout* layout_; QProgressBar* progress_;
  QVector<QWidget*> pages_;
};
}
