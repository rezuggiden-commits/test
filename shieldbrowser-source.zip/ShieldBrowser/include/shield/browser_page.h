#pragma once
#include <QWidget>
#include <QStringList>
#include <atomic>
#include <functional>
#include <memory>
#include "include/cef_browser.h"
#include "include/cef_request_context.h"
#include "shield/adblock_service.h"
class QTimer;
namespace shield {
class BrowserClient;
class BrowserPage final : public QWidget {
  Q_OBJECT
 public:
  BrowserPage(CefRefPtr<CefRequestContext> context, std::shared_ptr<AdBlockService> adblock, QWidget* parent=nullptr);
  ~BrowserPage() override;
  void open(const QString& url);
  void command(const std::function<void(CefRefPtr<CefBrowser>)>& f);
  void shutdown();
  void cancelDownload(unsigned id);
  QString url() const {return url_;}
  bool loading() const{return loading_;}
  bool canGoBack() const{return back_;}
  bool canGoForward() const{return forward_;}
  QStringList blockedSummary() const;
  void showNetworkError(const QString& url,const QString& reason);
  int zoomPercent() const; void zoomBy(int step); void resetZoom();
  bool isClosing() const {return closing_;}
  bool hasBrowser() const {return bool(browser_);}
  void created(CefRefPtr<CefBrowser> browser);
  void beforeClose();
 signals:
  void findResult(int count,int active);
  void titleChanged(const QString& title);
  void addressChanged(const QString& address);
  void loadingChanged(bool loading, bool back, bool forward);
  void loadFailed(const QString& error);
  void completed(const QString& url,const QString& title);
  void popupRequested(const QString& url);
  void closed();
  void shortcut(int key, int modifiers);
  void downloadChanged(unsigned id,const QString& name,qint64 received,qint64 total,bool complete,bool cancelled,int interruptReason);
  void blockedChanged(quint64 count);
  void contentFocused();
 protected:
  void showEvent(QShowEvent*) override;
  void resizeEvent(QResizeEvent*) override;
  void focusInEvent(QFocusEvent*) override;
 private:
  CefRefPtr<CefRequestContext> context_;
  CefRefPtr<CefBrowser> browser_;
  CefRefPtr<CefClient> client_;
  std::shared_ptr<AdBlockService> adblock_;
  QString url_="https://example.org";
  bool started_=false,closing_=false,loading_=false,back_=false,forward_=false;
  QTimer* loadTimer_;
  QString attempted_;
  double zoom_=0;
  void fit();
  friend class BrowserClient;
};
}
