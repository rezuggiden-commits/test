#pragma once
#include <QMainWindow>
#include <QThread>
#include <QPointer>
#include <memory>
#include <set>
#include "shield/browser_page.h"
#include "shield/core/storage.h"
class QLineEdit;class QLabel;class QToolButton;class QListWidget;class QDialog;class QMenu;class QStringListModel;
namespace shield {
class BrowserTabs;
class MainWindow final:public QMainWindow {
 Q_OBJECT
 public:
  MainWindow(CefRefPtr<CefRequestContext>,QString profile,bool privateMode=false);
  ~MainWindow() override;
  void newTab(const QString& url="shield://newtab/");
 protected:
  void closeEvent(QCloseEvent*) override;
  bool nativeEvent(const QByteArray&,void*,qintptr*) override;
  bool eventFilter(QObject*,QEvent*) override;
 private:
  BrowserTabs* tabs_;QLineEdit* address_;QLabel* status_;QToolButton *back_,*forward_,*reload_,*shield_,*bookmark_,*menuButton_;
  QMenu* menu_;QDialog* downloadsDialog_;QListWidget* downloadsList_;QLabel* downloadsEmpty_;
  QWidget* findBar_;QLineEdit* find_;QLabel* findCount_;QStringListModel* suggestions_;
  CefRefPtr<CefRequestContext> context_;std::shared_ptr<AdBlockService> adblock_;
  bool editingAddress_=false;
  bool privateMode_,closing_=false;QString profile_;QStringList closedTabs_;
  std::set<BrowserPage*> pages_;std::set<QThread*> filterWorkers_;bool compilingRules_=false;
  QThread storageThread_;QObject* storageWorker_;std::shared_ptr<std::unique_ptr<core::Storage>> storage_;
  BrowserPage* current()const;void navigate();void closeTab(int);void key(int,int);void refreshChrome();void showFind();void findNext(bool forward=true);
  void store(std::function<void(core::Storage&)>);void saveSession(bool clean=false);void refreshSuggestions();
  void showHistory();void showBookmarks();void showLibrary(bool bookmarks);void addBookmark();void updateFilters();void compileRules(const QByteArray&,bool save=false);
  void showDownloads();void privacy();void showSettings();void showProtection();void applyTheme(const QString&);void runUiChecks();void runExternalChecks();void showProxy();
  void withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>&);
};
}
