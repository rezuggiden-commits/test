#pragma once
#include <QMainWindow>
#include <QThread>
#include <QPointer>
#include <memory>
#include <set>
#include "shield/browser_page.h"
#include "shield/core/storage.h"
class QTabWidget;class QLineEdit;class QLabel;class QToolButton;class QListWidget;class QDialog;
namespace shield {
class MainWindow final:public QMainWindow {
  Q_OBJECT
 public:
  MainWindow(CefRefPtr<CefRequestContext> context,QString profile,bool privateMode=false);
  ~MainWindow() override;
  void newTab(const QString& url="about:blank");
 protected:
  void closeEvent(QCloseEvent*) override;
 private:
  QTabWidget* tabs_;QLineEdit* address_;QLabel* status_;QToolButton *back_,*forward_,*reload_,*shield_;
  QDialog* downloadsDialog_;QListWidget* downloadsList_;
  CefRefPtr<CefRequestContext> context_;
  std::shared_ptr<AdBlockService> adblock_;
  bool privateMode_,closing_=false;
  QString profile_;QStringList closedTabs_;
  std::set<BrowserPage*> pages_;
  std::set<QThread*> filterWorkers_;
  bool compilingRules_=false;
  void compileRules(const QByteArray& data,bool save=false);
  QThread storageThread_;QObject* storageWorker_;
  std::shared_ptr<std::unique_ptr<core::Storage>> storage_;
  BrowserPage* current() const;
  void navigate();void closeTab(int index);void key(int key,int modifiers);
  void store(std::function<void(core::Storage&)> f);
  void saveSession(bool clean=false);
  void showHistory();void showBookmarks();void addBookmark();void updateFilters();
  void showDownloads();void privacy();
  void withCurrent(const std::function<void(CefRefPtr<CefBrowser>)>& f);
};
}
