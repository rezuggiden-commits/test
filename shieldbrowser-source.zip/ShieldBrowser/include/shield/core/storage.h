#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace shield::core {
class StorageError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
struct PrivacyFlags {
    bool private_mode = false;
    bool record_history = true;
    bool persist_session = true;
};
struct HistoryEntry {
    std::int64_t id = 0;
    std::string url, title;
    std::int64_t last_visit_ms = 0, visit_count = 0;
};
struct Bookmark {
    std::int64_t id = 0;
    std::string url, title;
    std::int64_t created_ms = 0;
};
struct SessionTab { std::string url, title; bool private_mode = false; };
struct SessionSnapshot {
    std::vector<SessionTab> tabs;
    std::size_t active_index = 0;
    bool clean_shutdown = true;
};
// SQLite backed, synchronous and mutex-protected. Instantiate on a worker thread
// for UI use. Errors throw StorageError; invalid inputs throw invalid_argument.
// Opens UTF-8 paths; pass ":memory:" for a non-persistent profile. No encryption is
// provided: callers must protect the profile directory with OS access controls.
class Storage {
public:
    explicit Storage(const std::string& utf8_path);
    ~Storage();
    Storage(const Storage&) = delete;
    Storage& operator=(const Storage&) = delete;
    bool recordVisit(std::string_view url, std::string_view title, std::int64_t timestamp_ms,
                     PrivacyFlags privacy = {});
    [[nodiscard]] std::vector<HistoryEntry> history(std::size_t limit = 100, std::size_t offset = 0) const;
    void clearHistory();
    void pruneHistoryBefore(std::int64_t cutoff_ms);
    std::int64_t addBookmark(std::string_view url, std::string_view title, std::int64_t timestamp_ms);
    bool removeBookmark(std::int64_t id);
    [[nodiscard]] std::vector<Bookmark> bookmarks() const;
    void setSetting(std::string_view key, std::string_view value);
    [[nodiscard]] std::optional<std::string> setting(std::string_view key) const;
    bool removeSetting(std::string_view key);
    // Replaces snapshot atomically. Private tabs are omitted, active index remapped.
    // Privacy opt-out is a no-op (does not overwrite an existing normal session).
    bool saveSession(const SessionSnapshot& session, PrivacyFlags privacy = {});
    [[nodiscard]] SessionSnapshot loadSession() const;
    void markSessionClean(bool clean);
    void clearSession();
    // Atomically removes history, settings and session; bookmarks optional.
    void clearBrowsingData(bool include_bookmarks = false);
    [[nodiscard]] std::string integrityCheck() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
} // namespace shield::core
