#pragma once
#include "include/cef_app.h"
namespace shield {
CefRefPtr<CefApp> createApp();
bool registerInternalPages();
void setInternalTheme(bool light);
}
