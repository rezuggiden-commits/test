# ShieldBrowser — незавершённая разработка

**Это не готовый Windows-браузер. Windows EXE, portable-дистрибутив и установщик не собраны.**
Проект создан по ТЗ из `docs/ORIGINAL_REQUIREMENTS_RU.txt`. В доступной Linux-среде
реально собраны и проверены переносимое C++-ядро и Rust-блокировщик. Qt/CEF-приложение
написано, но не компилировалось и не запускалось под Windows. Не используйте его
как основной браузер или коммерческий релиз до завершения проверок.

## Состав

- `src/app/` — DLL-точка входа штатного CEF bootstrap; sandbox обязателен.
- `src/browser/` — нативные CEF-вкладки, события, сетевой перехват, адаптер фильтрации.
- `src/ui/` — Qt Widgets: адресная строка, вкладки, навигация, история, закладки,
  текущие загрузки, приватное окно, очистка cookies/HTTP-кэша, загрузка списков.
- `src/core/` — переносимые разбор адреса/поиска и SQLite-хранилище.
- `rust/adblock/` — настоящий Brave adblock-rust через C ABI, не подмена доменным списком.
- `resources/` — тёмная тема и собственные SVG-иконки без стороннего icon pack.
- `tools/`, `packaging/` — PowerShell-конвейер и исходник Inno Setup, не готовый Setup EXE.
- `tests/` — исполненные тесты ядра и ABI; GUI-интеграционные тесты ещё отсутствуют.

Состояние требований и точные ограничения: **`docs/STATUS_RU.md`**.
Результаты: `docs/CORE_TEST_RESULTS.md`, `docs/ADBLOCK.md`, `docs/TEST_REPORT_RU.md`.

## Проверенная локальная сборка ядра (Linux)

Требуются CMake 3.25+, Ninja, компилятор C/C++20 и pthreads. SQLite включён в исходники.

```sh
cmake --preset core
cmake --build --preset core
ctest --preset core --output-on-failure
# При установленном Rust/rustup:
bash tests/adblock/run.sh
```

18 C++-сценариев / 182 проверки и 10 Rust-тестов прошли. Это НЕ доказывает работу
вкладок, сайтов, sandbox, загрузок и приватного контекста под Windows.

## Сборка Windows с нуля — следующий обязательный этап

1. Установить Visual Studio 2022: Desktop development with C++, Windows SDK,
   MSVC x64; CMake 3.25+; Rust MSVC x64/rustup; Qt **6.11.2 msvc2022_64**.
2. Открыть **VS2022 x64 developer PowerShell** в корне проекта.
3. Выполнить:

```powershell
.\tools\setup.ps1 -DownloadInno
$env:CEF_ROOT = "$PWD\.deps\cef_binary_152.0.14+g8a0b5b9+chromium-152.0.7977.167_windows64"
$env:Qt6_DIR = 'C:\Qt\6.11.2\msvc2022_64\lib\cmake\Qt6'
.\tools\check.ps1
.\tools\configure.ps1
.\tools\build.ps1
.\tools\test.ps1
.\tools\deploy.ps1 -QtLicenseDirectory 'C:\Qt\Licenses'
# Установить вручную проверенный setup-компилятор Inno 6.7.3, затем:
.\tools\package.ps1 -Iscc 'C:\Program Files (x86)\Inno Setup 6\ISCC.exe'
```

Эти команды подготовлены, но их полный Windows-прогон здесь НЕ выполнялся.
Подробности, проверка CRT и чистой машины: `docs/BUILD_WINDOWS.md`.
Debug/Release-профили: `cmake --preset windows`, затем
`cmake --build --preset debug` / `cmake --build --preset release`.
PowerShell-скрипты используют `build/`, presets Windows — `build/windows/`:
не смешивайте два варианта конвейера в одном прогоне.

**Ожидаемые пути после успешной будущей сборки:** `build/bin/Release/ShieldBrowser.dll`,
рядом `ShieldBrowser.exe` (штатный CEF bootstrap); пакет в `dist/`.
Сейчас этих готовых продуктов нет. Нельзя распространять один EXE без CEF/Qt ресурсов.

## Безопасность и приватность

- Никаких `--no-sandbox`, игнорирования TLS-ошибок или автоматического запуска загрузок.
- Камера, микрофон и остальные разрешения всегда отклоняются: интерфейс выдачи разрешений
  ещё не реализован. Это безопасное ограничение, а не готовый PermissionController.
- Приватное окно создаёт CEF request context с пустым cache_path; SQLite — `:memory:`.
  Фактическое отсутствие всех приватных файлов на диске нужно проверить на Windows.
- Приватное окно не скрывает IP и не удаляет скачанные файлы.
- URL/история обычного профиля хранятся SQLite **без шифрования**; своего менеджера паролей,
  секретных настроек и сбора телеметрии в коде приложения нет. DPAPI-интеграция не создана.
- Профиль: `%LOCALAPPDATA%\ShieldBrowser\User Data`, отдельно от установки.
- Нет автоматического обновления приложения: нет подписанного манифеста, ключей,
  исполняемого updater или опасного механизма скачивания и запуска EXE.

## Реклама и списки

Защита не считается активной до успешной загрузки/компиляции списка. Меню позволяет
загрузить EasyList + EasyPrivacy по HTTPS или собственный локальный UTF-8-файл.
В CEF IO callback нет сетевой загрузки; движок использует сменяемый снимок правил.
Обновления HTTPS имеют ограничение размера/времени, проверку статуса/заголовка,
не разрешают редиректы; ошибка не заменяет прежний активный движок. Это НЕ проверка
цифровой подписи списков. Исключения текущего сайта пока действуют только в окне/сессии.
Косметика, scriptlets, redirect-ресурсы, региональные подписки и полная совместимость
с uBlock Origin не реализованы. Списки не включены в архив и не скачиваются при старте.

## Лицензии

Оригинальные C++/SVG/скрипты — MIT; Rust-обёртка и adblock-rust — MPL-2.0.
Qt: применимая LGPLv3/GPL/commercial лицензия; CEF/Chromium: upstream notices;
SQLite: public domain. EasyList/EasyPrivacy имеют собственные условия.
`THIRD_PARTY_NOTICES.md` — начальный инвентарь, НЕ завершённый юридический аудит;
полный комплект transitive notices/source offers ещё нужно собрать перед продажей.
