# Third-party notices — development distribution

This inventory is not a legal opinion or a completed license-compliance audit. Review
all transitive dependencies and the actual shipped binary set before redistribution.
No installer or executable is currently signed. No production-readiness claim is made.

| Component | Pin / source | License / distribution notes |
| --- | --- | --- |
| Chromium Embedded Framework / Chromium | CEF 152.0.14+g8a0b5b9, Chromium 152.0.7977.167; https://cef-builds.spotifycdn.com/ | CEF BSD-style license, Chromium and bundled third-party notices. The exact distribution's `LICENSE.txt` is copied to `licenses/CEF-LICENSE.txt`. Preserve all notices in the upstream runtime. |
| Qt | 6.11.2 MSVC2022 x64; https://download.qt.io/official_releases/qt/6.11/6.11.2/ | Qt modules have LGPL/GPL/commercial alternatives and exceptions. Use eligible dynamically linked modules or a valid commercial license; supply relevant license texts, source/relinking instructions and notices as required. Do not assume every Qt module is LGPL. |
| adblock-rust | Exact resolved versions in `rust/adblock/Cargo.lock`; https://github.com/brave/adblock-rust | MPL-2.0 for adblock, with separate licenses on transitive crates. Preserve `rust/adblock/LICENSE-MPL-2.0`; inspect Cargo.lock and crate source notices. Modified MPL-covered sources must remain available as required. |
| SQLite | Vendored source identifies its exact version; https://sqlite.org/copyright.html | Public domain dedication; jurisdictions and bundled extensions may require separate review. |
| Microsoft Visual C++ runtime | Redistributables selected by `windeployqt --compiler-runtime` | Microsoft redistribution terms apply. Requires licensed Visual Studio/toolchain rights. |
| Inno Setup | 6.7.3; https://jrsoftware.org/ | Installer compiler is a build tool. Review current Inno licensing, including commercial-use terms. The dependency lock pins the official installer digest. |

## Distribution checklist

- Ship the project license and every applicable upstream license/notice in `licenses/`.
- Collect Qt license texts for the actual installed kit; pass their directory to deploy.
- Audit Rust transitive license texts (not merely Cargo.lock); prepare required source offers.
- Review Chromium codecs/patents, filter-list terms and any trademark use separately.
- Do not describe legacy SHA1 checks as publisher authentication. HTTPS + pinned SHA256
  provide transport/integrity checks, not a code-signing or supply-chain audit.
- No filter subscription downloaded at runtime is licensed by this document.

## Runtime filter subscriptions (not bundled)

The UI explicitly downloads EasyList and EasyPrivacy from easylist.to only when
requested. The EasyList authors (https://easylist.to/) license their repository
under GPL-3.0-or-later OR CC-BY-SA-3.0-or-later unless otherwise noted:
https://easylist.to/pages/licence.html . Review attribution/share-alike obligations
before bundling modified lists. This repository does not bundle their rule data.
Original SVG paths in resources/icons are project-authored and covered by LICENSE.
SQLite's exact vendored version is 3.50.4; see third_party/sqlite/README.md.

A Cargo-derived 61-crate license inventory and copied upstream license texts are
provided in rust/adblock/THIRD_PARTY_NOTICES.md and packaging/licenses/rust/.
Seahash's exact historical VCS license URL was unavailable; its current upstream
MIT notice is included and historical confirmation remains outstanding. This is
one reason the bundled development library is not a commercially cleared package.
